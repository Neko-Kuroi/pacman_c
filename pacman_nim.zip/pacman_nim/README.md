# pacman.c — Nim port

A port of floooh/pacman.c (a Pac-Man clone written in C99 on top of the
sokol headers) to the Nim programming language, using the author's official
sokol-nim bindings. The behaviour and specification follow the C original;
the code layout follows the section division of the C implementation
(state / time triggers / geometry / ghost AI / rules / rendering / sound).

## Build

Requirements: Nim 2.2.14 (pinned for this project) and a C compiler
(Nim compiles through C). The sokol-nim bindings are vendored under
`vendor/sokol-nim-src/`, no nimble and no network access are needed.

```
make pacman     # release build, produces ./pacman
make debug      # debug build
make check      # foundation checks + headless game-logic verification
```

## Run

```
./pacman
```

Any key starts the game. Arrow keys or WASD steer Pac-Man, F toggles
fullscreen, closing the window quits.

## Layout

| file | contents | pacman.c lines |
|---|---|---|
| `src/pacstate.nim` | constants, types, the global state, data tables | 142–678 |
| `src/timing.nim` | time-trigger vocabulary, xorshift RNG, input | 826–943 |
| `src/geom.nim` | geometry and playfield queries | 988–991, 1230–1361 |
| `src/ghost.nim` | ghost speed, state machine, targets, steering | 1750–2087 |
| `src/rules.nim` | playfield/round setup, actor updates, game & intro ticks | 1377–1583, 1733–1748, 2089–2403 |
| `src/render.nim` | video-RAM writes, sprite animation, sokol-gfx renderer | 993–1229, 1584–1732, 2404–3124 |
| `src/sound.nim` | Namco sound emulation and sound effects | 638–678, 3125–3388 |
| `src/pacman.nim` | sokol-app entry point and callbacks | 716–825 |
| `src/romdata.nim` | ROM dumps, extracted mechanically from pacman.c | 3389–4303 |
| `src/shaders.nim` | shader sources, extracted mechanically from pacman.c | 2438–2640 |

`romdata.nim` and `shaders.nim` are generated files (see REPORT.md);
everything else is hand-written Nim.
