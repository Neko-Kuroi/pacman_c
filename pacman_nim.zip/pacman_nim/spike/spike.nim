# Phase 0 spike: window + gfx clear + letterbox calc + audio push, auto-quit.
import sokol/log as slog
import sokol/app as sapp
import sokol/gfx as sg
import sokol/audio as saudio
import sokol/glue as sglue
import sokol/letterbox as slbx
import std/math

var passAction = PassAction()
passAction.colors[0] = ColorAttachmentAction(loadAction: loadActionClear,
                                              clearValue: (0, 0, 0, 1))
var frames = 0
var pushed = 0
var samples: array[4096, float32]
var phase = 0.0f

proc init() {.cdecl.} =
  sg.setup(sg.Desc(environment: sglue.environment(),
                   logger: sg.Logger(fn: slog.fn)))
  saudio.setup(saudio.Desc(logger: saudio.Logger(fn: slog.fn)))
  let vp = slbx.letterbox(sapp.width().int32, sapp.height().int32,
                          LetterboxDesc(contentAspectRatio: 448.0f / 576.0f))
  echo "letterbox viewport: ", vp.x, " ", vp.y, " ", vp.width, " ", vp.height
  echo "audio valid: ", saudio.isvalid(), " sample rate: ", saudio.sampleRate()

proc frame() {.cdecl.} =
  let numFrames = saudio.expect()
  if numFrames > 0:
    let n = min(numFrames, 4096)
    for i in 0..<n:
      samples[i] = 0.1f * sin(phase)
      phase += 0.05f
    discard saudio.push(addr(samples[0]), n)
    pushed += n
  passAction.colors[0].clearValue.b = (frames mod 60).float32 / 60.0f
  sg.beginPass(Pass(action: passAction, swapchain: sglue.swapchain()))
  sg.endPass()
  sg.commit()
  frames += 1
  if frames >= 180:
    sapp.requestQuit()

proc cleanup() {.cdecl.} =
  echo "SPIKE OK frames=", frames, " pushed=", pushed
  saudio.shutdown()
  sg.shutdown()

sapp.run(sapp.Desc(
  initCb: init, frameCb: frame, cleanupCb: cleanup,
  windowTitle: "pacman-nim spike",
  width: 448, height: 576,
  icon: IconDesc(sokolDefault: true),
  logger: sapp.Logger(fn: slog.fn)))
