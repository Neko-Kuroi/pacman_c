import ../src/pacstate
import ../src/geom
import ../src/sound
# geometry spot checks against C semantics
echo "cmod(-1,8)=", cmod(-1, 8), " distmid(-1,116)=", distToTileMid(i2(-1, 116)).x
echo "clamp(30,40)=", clampedTilePos(i2(30, 40)).x, ",", clampedTilePos(i2(30, 40)).y
state.timing.tick = 0
sndStart(2, sndEatdot1)
for i in 1..8: sndTick()
echo "eatdot done, slot2 fn nil: ", state.audio.sound[2].fn == nil
sndStart(0, sndPrelude)
echo "prelude ticks: ", state.audio.sound[0].numTicks, " stride: ", state.audio.sound[0].stride
