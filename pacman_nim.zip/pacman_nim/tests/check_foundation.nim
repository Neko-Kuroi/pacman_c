import ../src/pacstate
import ../src/timing

state.game.xorshift = 0x12345678'u32
for i in 1..5:
  echo "xor ", i, ": ", xorshift32()
echo "spec0: ", levelspec(0).bonusFruit, " ", levelspec(0).bonusScore, " ", levelspec(0).frightTicks
echo "spec25: ", levelspec(25).bonusFruit, " ", levelspec(25).frightTicks
state.timing.tick = 100
var t = disabledTimer()
start(t)
echo "now at 101: ", (state.timing.tick = 101; now(t)), " since: ", since(t)
echo "between 0..5: ", between(t, 0, 5), " after 1: ", after(t, 1)
echo "scatter[2]: ", ghostScatterTargets[2].x, ",", ghostScatterTargets[2].y
