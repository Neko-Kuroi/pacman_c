# audit_probes.nim -- targeted behavioural probes for the re-audit:
# speeds, phase timing, house dot counters, frightened duration,
# ghost-eaten scores and event timing, all against the C original's rules.
import std/deques
import ../src/pacstate
import ../src/timing
import ../src/geom
import ../src/rules
import ../src/render
import ../src/sound

proc resetAll() =
  state = State()
  start(state.intro.started)

proc tick() =
  state.timing.tick += 1
  sndTick()
  if now(state.intro.started):
    state.gamestate = GAMESTATE_INTRO
  if now(state.game.started):
    state.gamestate = GAMESTATE_GAME
  case state.gamestate
  of GAMESTATE_INTRO: introTick()
  of GAMESTATE_GAME: gameTick()

proc pressAnyKey() =
  state.input.anykey = true
  tick()
  state.input.anykey = false

proc steerDir(): Dir =
  let startT = pixelToTilePos(state.game.pacman.actor.pos)
  var visited: array[DISPLAY_TILES_Y, array[DISPLAY_TILES_X, bool]]
  var firstStep: array[DISPLAY_TILES_Y, array[DISPLAY_TILES_X, Dir]]
  var q = initDeque[Int2]()
  visited[startT.y][startT.x] = true
  q.addLast(startT)
  const dirs = [DIR_UP, DIR_LEFT, DIR_DOWN, DIR_RIGHT]
  while q.len > 0:
    let cur = q.popFirst()
    if (cur != startT) and (isDot(cur) or isPill(cur)):
      return firstStep[cur.y][cur.x]
    for d in dirs:
      let n = cur + dirToVec(d)
      if n.x >= 0 and n.x < DISPLAY_TILES_X and n.y >= 0 and
         n.y < DISPLAY_TILES_Y and not visited[n.y][n.x] and
         not isBlockingTile(n):
        visited[n.y][n.x] = true
        firstStep[n.y][n.x] = if cur == startT: d else: firstStep[cur.y][cur.x]
        q.addLast(n)
  state.game.pacman.actor.dir

proc setInput(d: Dir) =
  state.input.up = d == DIR_UP
  state.input.down = d == DIR_DOWN
  state.input.left = d == DIR_LEFT
  state.input.right = d == DIR_RIGHT

proc toGameplay() =
  resetAll()
  for i in 1..100: tick()
  pressAnyKey()
  for i in 1..2000:
    tick()
    if state.gamestate == GAMESTATE_GAME and state.game.freeze.len == 0:
      return
  doAssert false, "never reached gameplay"

var failures = 0
proc check(name: string, ok: bool, detail: string) =
  echo (if ok: "PASS " else: "FAIL "), name, " ", detail
  if not ok: failures += 1

# --- event timing: prelude 120, ready->round 130 ---
toGameplay()
let dtReady = state.game.readyStarted.tick.int - state.game.started.tick.int
let dtRound = state.game.roundStarted.tick.int - state.game.readyStarted.tick.int
check("prelude timing", dtReady == 120, "started->readyStarted=" & $dtReady)
check("ready timing", dtRound == 130, "readyStarted->roundStarted=" & $dtRound)

# --- scatter -> chase switch at +420 ticks from round start ---
let base = state.game.roundStarted.tick.int
while state.timing.tick.int < base + 419: tick()
let s419 = state.game.ghost[ord(GHOSTTYPE_BLINKY)].state
tick()
let s420 = state.game.ghost[ord(GHOSTTYPE_BLINKY)].state
check("scatter@419", s419 == GHOSTSTATE_SCATTER, $s419)
check("chase@420", s420 == GHOSTSTATE_CHASE, $s420)

# --- pacman speed: empty corridor (row 17, wraps through the tunnel) ---
toGameplay()
for x in 0..<DISPLAY_TILES_X:
  if state.gfx.videoRam[17][x] == TILE_DOT:
    state.gfx.videoRam[17][x] = TILE_SPACE  # row 17 has dots at tiles 6 and 21
state.game.pacman.actor.pos = i2(60, 17 * 8 + 4)
state.game.pacman.actor.dir = DIR_LEFT
setInput(DIR_LEFT)
var movedClear = 0
var prevX = state.game.pacman.actor.pos.x
for i in 1..112:
  tick()
  let x = state.game.pacman.actor.pos.x
  var d = prevX - x
  if d < -100: d += DISPLAY_PIXELS_X  # wrapped
  movedClear += d
  prevX = x
check("pacman clear speed", movedClear == 98,
      "moved=" & $movedClear & " expected 98 (112 ticks * 7/8)")

# --- pacman speed while eating (row 23 left segment, 11 dots) ---
toGameplay()
state.game.pacman.actor.pos = i2(12 * 8 + 4, 23 * 8 + 4)
state.game.pacman.actor.dir = DIR_LEFT
setInput(DIR_LEFT)
var ticksEat = 0
while state.game.pacman.actor.pos.x > 12 and ticksEat < 300:
  tick()
  ticksEat += 1
let ratio = 88.0 / ticksEat.float
check("pacman eating speed", ratio > 0.77 and ratio < 0.83,
      "ticks for 88px=" & $ticksEat & " ratio=" & $ratio)

# --- ghost normal speed 6/7 (Blinky, scatter/chase, outside tunnel) ---
toGameplay()
var gTicks, gMoved = 0
var prevPos = state.game.ghost[0].actor.pos
for i in 1..3000:
  tick()
  let g = state.game.ghost[0]
  let d = abs(g.actor.pos.x - prevPos.x) + abs(g.actor.pos.y - prevPos.y)
  if (g.state == GHOSTSTATE_SCATTER or g.state == GHOSTSTATE_CHASE) and
     not isTunnel(pixelToTilePos(g.actor.pos)) and
     state.game.freeze.len == 0:
    gTicks += 1
    gMoved += d.int
  prevPos = g.actor.pos
let gRatio = gMoved.float / gTicks.float
check("ghost speed 6/7", gRatio > 0.83 and gRatio < 0.88,
      "ratio=" & $gRatio & " over " & $gTicks & " ticks")

# --- house dot counters: Inky at 30 dots, Clyde at 90 (no death) ---
toGameplay()
var inkyAt, clydeAt = -1
var pills = 0
var lastPillTick = DISABLED_TICKS
let lives0 = state.game.numLives
while state.game.numDotsEaten.int < 120 and
      state.game.numLives == lives0:
  tick()
  if state.game.pillEaten.tick != DISABLED_TICKS and
     state.game.pillEaten.tick != lastPillTick:
    lastPillTick = state.game.pillEaten.tick
    pills += 1
  # pin the two roaming ghosts so Pacman survives long enough; this does
  # not touch the dot-counter mechanism under test
  state.game.ghost[0].actor.pos = ghostStartingPos[0]
  if state.game.ghost[1].state != GHOSTSTATE_HOUSE:
    state.game.ghost[1].actor.pos = ghostStartingPos[1]
  if state.game.freeze.len == 0:
    setInput(steerDir())
  if inkyAt < 0 and state.game.ghost[ord(GHOSTTYPE_INKY)].state != GHOSTSTATE_HOUSE:
    inkyAt = state.game.numDotsEaten.int
  if clydeAt < 0 and state.game.ghost[ord(GHOSTTYPE_CLYDE)].state != GHOSTSTATE_HOUSE:
    clydeAt = state.game.numDotsEaten.int
check("inky leaves at 30 dots", inkyAt == 30, "inkyAt=" & $inkyAt)
if clydeAt >= 0:
  # pills raise numDotsEaten but do not advance the house counters
  # (the C pill branch never calls the counter update), so Clyde's
  # exit shifts by the number of pills eaten
  check("clyde leaves at 90+pills", clydeAt == 90 + pills,
        "clydeAt=" & $clydeAt & " pills=" & $pills)
else:
  echo "SKIP clyde (death or 120 dots first) dots=",
       state.game.numDotsEaten.int

# --- global dot counter after a death: Pinky 7, Inky 17, Clyde 32 ---
toGameplay()
# stage a death: put Blinky (chase) onto Pacman's tile
state.game.ghost[0].state = GHOSTSTATE_CHASE
state.game.ghost[0].actor.pos = state.game.pacman.actor.pos
let deathTick0 = state.timing.tick
tick()
check("death sets pacmanEaten", state.game.pacmanEaten.tick != DISABLED_TICKS,
      "")
# start() stores tick+1 while startAfter() stores tick+N, so the stored
# trigger values differ by 209 even though the delay is 210 ticks (the C
# code has the same arithmetic)
let dtDeath = state.game.readyStarted.tick.int -
              state.game.pacmanEaten.tick.int
check("death->ready timing", dtDeath == 209, "delta=" & $dtDeath)
# wait for the new round to run, then eat dots and watch the global counter
for i in 1..2000:
  tick()
  if state.game.freeze.len == 0 and state.game.globalDotCounterActive:
    break
var gPinky, gInky, gClyde = -1
var guard = 0
while gClyde < 0 and guard < 30000:
  tick()
  guard += 1
  if state.game.freeze.len == 0:
    setInput(steerDir())
  if gPinky < 0 and state.game.ghost[ord(GHOSTTYPE_PINKY)].state != GHOSTSTATE_HOUSE:
    gPinky = state.game.globalDotCounter.int
  if gInky < 0 and state.game.ghost[ord(GHOSTTYPE_INKY)].state != GHOSTSTATE_HOUSE:
    gInky = state.game.globalDotCounter.int
  if gClyde < 0 and state.game.ghost[ord(GHOSTTYPE_CLYDE)].state != GHOSTSTATE_HOUSE:
    gClyde = state.game.globalDotCounter.int
check("global pinky@7", gPinky == 7, "at=" & $gPinky)
check("global inky@17", gInky == 17, "at=" & $gInky)
check("global clyde@32", gClyde == 32, "at=" & $gClyde)

# --- frightened duration: 360 ticks on round 1 ---
toGameplay()
state.game.pacman.actor.pos = i2(1 * 8 + 4, 6 * 8 + 4)  # on the pill tile
setInput(DIR_LEFT)
var frightStart = -1
for i in 1..60:
  tick()
  if state.game.ghost[0].state == GHOSTSTATE_FRIGHTENED:
    frightStart = state.timing.tick.int
    break
check("pill frightens blinky", frightStart > 0, "start=" & $frightStart)
if frightStart > 0:
  # park Pacman far away in the bottom right corner area
  state.game.pacman.actor.pos = i2(26 * 8 + 4, 32 * 8 + 4)
  var leftAt = -1
  for i in 1..500:
    tick()
    let st = state.game.ghost[0].state
    if st != GHOSTSTATE_FRIGHTENED:
      leftAt = state.timing.tick.int - frightStart
      break
  check("frightened lasts 360", leftAt == 360, "leftAt=" & $leftAt)

# --- ghost-eaten scores: 20, 40, 80, 160 (10-point units) ---
toGameplay()
state.game.pacman.actor.pos = i2(1 * 8 + 4, 6 * 8 + 4)
setInput(DIR_LEFT)
for i in 1..60:
  tick()
  if state.game.ghost[0].frightened.tick != DISABLED_TICKS and
     before(state.game.ghost[0].frightened, 10):
    break
var deltas: seq[int] = @[]
for gi in 0..<4:
  var g = addr state.game.ghost[gi]
  if g.state == GHOSTSTATE_EYES or g.state == GHOSTSTATE_ENTERHOUSE:
    continue
  g.state = GHOSTSTATE_FRIGHTENED
  start(g.frightened)
  g.actor.pos = state.game.pacman.actor.pos
  let s0 = state.game.score.int
  for i in 1..30:
    tick()
    if FREEZETYPE_EAT_GHOST in state.game.freeze:
      break
  deltas.add(state.game.score.int - s0)
  # wait out the eat-ghost freeze
  for i in 1..80:
    tick()
    if FREEZETYPE_EAT_GHOST notin state.game.freeze:
      break
check("ghost scores 20/40/80/160", deltas == @[20, 40, 80, 160],
      "deltas=" & $deltas)

echo (if failures == 0: "AUDIT PROBES ALL PASS" else: "FAILURES: " & $failures)
