# headless.nim -- drives the game logic tick by tick without graphics or
# audio output (the frame loop's tick part, replicated from pacman.nim).
import std/deques
import ../src/pacstate
import ../src/timing
import ../src/geom
import ../src/rules
import ../src/render
import ../src/sound

proc resetAll() =
  state = State()
  start(state.intro.started)  # what init() does (DBG_SKIP_INTRO off)

proc tick() =
  state.timing.tick += 1
  sndTick()
  if now(state.intro.started):
    state.gamestate = GAMESTATE_INTRO
  if now(state.game.started):
    state.gamestate = GAMESTATE_GAME
  case state.gamestate
  of GAMESTATE_INTRO: introTick()
  of GAMESTATE_GAME: gameTick()

proc pressAnyKey() =
  state.input.anykey = true
  tick()
  state.input.anykey = false

proc countDots(): int =
  for y in 0..<DISPLAY_TILES_Y:
    for x in 0..<DISPLAY_TILES_X:
      if state.gfx.videoRam[y][x] == TILE_DOT or
         state.gfx.videoRam[y][x] == TILE_PILL:
        result += 1

# BFS over non-blocking tiles to the nearest dot/pill; returns first step dir
proc steerDir(): Dir =
  let startT = pixelToTilePos(state.game.pacman.actor.pos)
  var visited: array[DISPLAY_TILES_Y, array[DISPLAY_TILES_X, bool]]
  var firstStep: array[DISPLAY_TILES_Y, array[DISPLAY_TILES_X, Dir]]
  var q = initDeque[Int2]()
  visited[startT.y][startT.x] = true
  q.addLast(startT)
  const dirs = [DIR_UP, DIR_LEFT, DIR_DOWN, DIR_RIGHT]
  while q.len > 0:
    let cur = q.popFirst()
    if (cur != startT) and (isDot(cur) or isPill(cur)):
      return firstStep[cur.y][cur.x]
    for d in dirs:
      let n = cur + dirToVec(d)
      if n.x >= 0 and n.x < DISPLAY_TILES_X and n.y >= 0 and
         n.y < DISPLAY_TILES_Y and not visited[n.y][n.x] and
         not isBlockingTile(n):
        visited[n.y][n.x] = true
        firstStep[n.y][n.x] = if cur == startT: d else: firstStep[cur.y][cur.x]
        q.addLast(n)
  state.game.pacman.actor.dir

proc setInput(d: Dir) =
  state.input.up = d == DIR_UP
  state.input.down = d == DIR_DOWN
  state.input.left = d == DIR_LEFT
  state.input.right = d == DIR_RIGHT

# --- scenario 1: boot, start a game, play autonomously ---
resetAll()
for i in 1..100: tick()
doAssert state.gamestate == GAMESTATE_INTRO
pressAnyKey()
var sawGame = false
var inkyLeftHouse = false
var maxGhostsOut = 0
for i in 1..60000:
  tick()
  if state.gamestate == GAMESTATE_GAME:
    if not sawGame:
      sawGame = true
      doAssert countDots() == 244, "playfield must start with 244 dots/pills"
    if state.game.freeze.len == 0:
      setInput(steerDir())
    var outCount = 0
    for g in state.game.ghost:
      if g.state != GHOSTSTATE_HOUSE: outCount += 1
    maxGhostsOut = max(maxGhostsOut, outCount)
    if state.game.ghost[ord(GHOSTTYPE_INKY)].state != GHOSTSTATE_HOUSE:
      inkyLeftHouse = true
doAssert sawGame
echo "scenario1: score=", state.game.score, " dotsEaten=", state.game.numDotsEaten.int,
     " lives=", state.game.numLives.int, " round=", state.game.round.int,
     " gamestate=", state.gamestate, " maxGhostsOut=", maxGhostsOut,
     " inkyLeft=", inkyLeftHouse
doAssert state.game.score > 0
doAssert maxGhostsOut >= 3

# --- scenario 2: determinism (same seed and inputs, same outcome) ---
proc runShort(): tuple[score: uint32, dots: uint8, px, py: int16, gx, gy: int16] =
  resetAll()
  for i in 1..100: tick()
  pressAnyKey()
  for i in 1..20000:
    tick()
    if state.gamestate == GAMESTATE_GAME and state.game.freeze.len == 0:
      setInput(steerDir())
  (state.game.score, state.game.numDotsEaten,
   state.game.pacman.actor.pos.x, state.game.pacman.actor.pos.y,
   state.game.ghost[0].actor.pos.x, state.game.ghost[0].actor.pos.y)

let r1 = runShort()
let r2 = runShort()
echo "determinism: ", r1, " vs ", r2
doAssert r1 == r2

# --- scenario 3: eating the last dot wins the round ---
resetAll()
for i in 1..100: tick()
pressAnyKey()
# advance until the round is running
for i in 1..1000:
  tick()
  if state.gamestate == GAMESTATE_GAME and
     FREEZETYPE_READY notin state.game.freeze and
     FREEZETYPE_PRELUDE notin state.game.freeze:
    break
# remove all dots except the one at (1,4) and pretend 243 were eaten
for y in 0..<DISPLAY_TILES_Y:
  for x in 0..<DISPLAY_TILES_X:
    if state.gfx.videoRam[y][x] == TILE_DOT or
       state.gfx.videoRam[y][x] == TILE_PILL:
      state.gfx.videoRam[y][x] = TILE_SPACE
state.gfx.videoRam[4][1] = TILE_DOT
state.game.numDotsEaten = 243
# place Pacman just right of the dot, heading left
state.game.pacman.actor.pos = i2(2 * 8 + 4, 4 * 8 + 4)
state.game.pacman.actor.dir = DIR_LEFT
setInput(DIR_LEFT)
var won = false
for i in 1..2000:
  tick()
  if FREEZETYPE_WON in state.game.freeze:
    won = true
  if won and state.game.round == 1 and countDots() == 244:
    break
echo "scenario3: won=", won, " round=", state.game.round.int,
     " dots=", countDots(), " globalActive=", state.game.globalDotCounterActive
doAssert won
doAssert state.game.round == 1
doAssert countDots() == 244
doAssert not state.game.globalDotCounterActive

echo "HEADLESS ALL OK"
