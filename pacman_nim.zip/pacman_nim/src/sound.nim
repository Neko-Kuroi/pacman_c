# sound.nim -- the Namco sound-board emulation and sound effects.
# Corresponds to pacman.c lines 638-678 (descriptions) and 3125-3388 (logic).

import sokol/log as slog
import sokol/audio as saudio
import pacstate
import romdata

proc sndInit*() =
  saudio.setup(saudio.Desc(logger: saudio.Logger(fn: slog.fn)))
  let samplesPerSec = saudio.sampleRate()
  state.audio.sampleDurationNs = 1_000_000_000 div samplesPerSec
  # number of 96kHz ticks per sample tick, times 1000 for precision
  state.audio.voiceTickPeriod = 96_000_000 div samplesPerSec

proc sndShutdown*() =
  saudio.shutdown()

# updates the Namco sound generator, must be called with 96 kHz
proc sndVoiceTick() =
  for i in 0..<NUM_VOICES:
    var voice = addr state.audio.voice[i]
    voice.counter += voice.frequency
    let waveIndex = ((uint32(voice.waveform) shl 5) or
                     ((voice.counter shr 15) and 0x1F)) and 0xFF
    let sample = (int(romWavetable[waveIndex] and 0xF) - 8) * int(voice.volume)
    voice.sampleAcc += sample.float32
    voice.sampleDiv += 128.0f

# must be called with the sample frequency (e.g. 44.1 kHz)
proc sndSampleTick() =
  var sm = 0.0f
  for i in 0..<NUM_VOICES:
    var voice = addr state.audio.voice[i]
    if voice.sampleDiv > 0.0f:
      sm += voice.sampleAcc / voice.sampleDiv
      voice.sampleAcc = 0.0f
      voice.sampleDiv = 0.0f
  state.audio.sampleBuffer[state.audio.numSamples] = sm * 0.333333f * AUDIO_VOLUME
  state.audio.numSamples += 1
  if state.audio.numSamples == NUM_SAMPLES:
    discard saudio.push(addr state.audio.sampleBuffer[0],
                        state.audio.numSamples.int32)
    state.audio.numSamples = 0

# the sound subsystem's per-frame function
proc sndFrame*(frameTimeNs: int32) =
  state.audio.sampleAccum -= frameTimeNs
  while state.audio.sampleAccum < 0:
    state.audio.sampleAccum += state.audio.sampleDurationNs
    state.audio.voiceTickAccum -= state.audio.voiceTickPeriod
    while state.audio.voiceTickAccum < 0:
      state.audio.voiceTickAccum += 1000
      sndVoiceTick()
    sndSampleTick()

# clear all active sound effects and start outputting silence
proc sndClear*() =
  for i in 0..<NUM_VOICES:
    state.audio.voice[i] = Voice()
  for i in 0..<NUM_SOUNDS:
    state.audio.sound[i] = Sound()

# stop a sound effect
proc sndStop*(slot: int32) =
  assert(slot >= 0 and slot < NUM_SOUNDS)
  for i in 0..<NUM_VOICES:
    if SoundFlag(i) in state.audio.sound[slot].flags:
      state.audio.voice[i] = Voice()
  state.audio.sound[slot] = Sound()

# start a sound effect
proc sndStart*(slot: int32, desc: SoundDesc) =
  assert(slot >= 0 and slot < NUM_SOUNDS)
  assert((desc.data != nil and desc.size != 0) or desc.fn != nil)
  var snd = addr state.audio.sound[slot]
  snd[] = Sound()
  var numVoices = 0
  for i in 0..<NUM_VOICES:
    if desc.voice[i]:
      snd.flags.incl(SoundFlag(i))
      numVoices += 1
  if desc.fn != nil:
    snd.fn = desc.fn
  else:
    assert(numVoices > 0)
    assert(desc.size mod (numVoices * 4).uint32 == 0)
    snd.stride = numVoices.uint32
    snd.numTicks = desc.size div (snd.stride * 4)
    snd.data = desc.data

# --- procedural sound effects (pacman.c 3281-3388) ---
proc sndFuncEatdot1(slot: int32) {.nimcall.} =
  assert(slot >= 0 and slot < NUM_SOUNDS)
  let snd = addr state.audio.sound[slot]
  var voice = addr state.audio.voice[2]
  if snd.curTick == 0:
    voice.volume = 12
    voice.waveform = 2
    voice.frequency = 0x1500
  elif snd.curTick == 5:
    sndStop(slot)
  else:
    voice.frequency -= 0x0300

proc sndFuncEatdot2(slot: int32) {.nimcall.} =
  assert(slot >= 0 and slot < NUM_SOUNDS)
  let snd = addr state.audio.sound[slot]
  var voice = addr state.audio.voice[2]
  if snd.curTick == 0:
    voice.volume = 12
    voice.waveform = 2
    voice.frequency = 0x0700
  elif snd.curTick == 5:
    sndStop(slot)
  else:
    voice.frequency += 0x300

proc sndFuncEatghost(slot: int32) {.nimcall.} =
  assert(slot >= 0 and slot < NUM_SOUNDS)
  let snd = addr state.audio.sound[slot]
  var voice = addr state.audio.voice[2]
  if snd.curTick == 0:
    voice.volume = 12
    voice.waveform = 5
    voice.frequency = 0
  elif snd.curTick == 32:
    sndStop(slot)
  else:
    voice.frequency += 0x20

proc sndFuncEatfruit(slot: int32) {.nimcall.} =
  assert(slot >= 0 and slot < NUM_SOUNDS)
  let snd = addr state.audio.sound[slot]
  var voice = addr state.audio.voice[2]
  if snd.curTick == 0:
    voice.volume = 15
    voice.waveform = 6
    voice.frequency = 0x1600
  elif snd.curTick == 23:
    sndStop(slot)
  elif snd.curTick < 11:
    voice.frequency -= 0x200
  else:
    voice.frequency += 0x0200

proc sndFuncWeeooh(slot: int32) {.nimcall.} =
  assert(slot >= 0 and slot < NUM_SOUNDS)
  let snd = addr state.audio.sound[slot]
  var voice = addr state.audio.voice[1]
  if snd.curTick == 0:
    voice.volume = 6
    voice.waveform = 6
    voice.frequency = 0x1000
  elif (snd.curTick mod 24) < 12:
    voice.frequency += 0x0200
  else:
    voice.frequency -= 0x0200

proc sndFuncFrightened(slot: int32) {.nimcall.} =
  assert(slot >= 0 and slot < NUM_SOUNDS)
  let snd = addr state.audio.sound[slot]
  var voice = addr state.audio.voice[1]
  if snd.curTick == 0:
    voice.volume = 10
    voice.waveform = 4
    voice.frequency = 0x0180
  elif (snd.curTick mod 8) == 0:
    voice.frequency = 0x0180
  else:
    voice.frequency += 0x180

# --- sound effect descriptions (pacman.c 638-678) ---
let sndPrelude* = SoundDesc(
  data: cast[ptr UncheckedArray[uint32]](unsafeAddr sndDumpPrelude[0]),
  size: sizeof(sndDumpPrelude).uint32,
  voice: [true, true, false])
let sndDead* = SoundDesc(
  data: cast[ptr UncheckedArray[uint32]](unsafeAddr sndDumpDead[0]),
  size: sizeof(sndDumpDead).uint32,
  voice: [false, false, true])
let sndEatdot1* = SoundDesc(fn: sndFuncEatdot1, voice: [false, false, true])
let sndEatdot2* = SoundDesc(fn: sndFuncEatdot2, voice: [false, false, true])
let sndEatghost* = SoundDesc(fn: sndFuncEatghost, voice: [false, false, true])
let sndEatfruit* = SoundDesc(fn: sndFuncEatfruit, voice: [false, false, true])
let sndWeeooh* = SoundDesc(fn: sndFuncWeeooh, voice: [false, true, false])
let sndFrightened* = SoundDesc(fn: sndFuncFrightened, voice: [false, true, false])

# the sound system's 60 Hz tick function (called from the game tick)
proc sndTick*() =
  for slot in 0..<NUM_SOUNDS:
    var snd = addr state.audio.sound[slot]
    var skipIncrement = false
    if snd.fn != nil:
      snd.fn(slot.int32)
    elif snd.flags * SOUNDFLAG_ALL_VOICES != {}:
      assert(snd.data != nil)
      if snd.curTick == snd.numTicks:
        sndStop(slot.int32)
        skipIncrement = true
      else:
        var idx = (snd.curTick * snd.stride).int
        for i in 0..<NUM_VOICES:
          if SoundFlag(i) in snd.flags:
            var voice = addr state.audio.voice[i]
            let val = snd.data[idx]
            idx += 1
            voice.frequency = val and ((1 shl 20) - 1)
            voice.waveform = ((val shr 24) and 7).uint8
            voice.volume = ((val shr 28) and 0xF).uint8
    if not skipIncrement:
      snd.curTick += 1
