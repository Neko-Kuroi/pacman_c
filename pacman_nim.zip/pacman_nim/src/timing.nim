# timing.nim -- the time-trigger vocabulary and input helpers.
# Corresponds to pacman.c lines 826-943 (xorshift, triggers, input).

import pacstate

# xorshift random number generator (pacman.c 827-833)
proc xorshift32*(): uint32 =
  var x = state.game.xorshift
  x = x xor (x shl 13)
  x = x xor (x shr 17)
  x = x xor (x shl 5)
  state.game.xorshift = x
  x

# set time trigger to the next game tick
proc start*(t: var Trigger) =
  t.tick = state.timing.tick + 1

# set time trigger to a future tick
proc startAfter*(t: var Trigger, ticks: uint32) =
  t.tick = state.timing.tick + ticks

# deactivate a time trigger
proc disable*(t: var Trigger) =
  t.tick = DISABLED_TICKS

# return a disabled time trigger
proc disabledTimer*(): Trigger =
  Trigger(tick: DISABLED_TICKS)

# check if a time trigger is triggered
proc now*(t: Trigger): bool =
  t.tick == state.timing.tick

# return the number of ticks since a time trigger was triggered
proc since*(t: Trigger): uint32 =
  if state.timing.tick >= t.tick:
    state.timing.tick - t.tick
  else:
    DISABLED_TICKS

# check if a time trigger is between begin and end tick
proc between*(t: Trigger, begin, ende: uint32): bool =
  assert(begin < ende)
  if t.tick != DISABLED_TICKS:
    let ticks = since(t)
    ticks >= begin and ticks < ende
  else:
    false

# check if a time trigger was triggered exactly N ticks ago
proc afterOnce*(t: Trigger, ticks: uint32): bool =
  since(t) == ticks

# check if a time trigger was triggered more than N ticks ago
proc after*(t: Trigger, ticks: uint32): bool =
  let s = since(t)
  if s != DISABLED_TICKS:
    s >= ticks
  else:
    false

# same as between(t, 0, ticks)
proc before*(t: Trigger, ticks: uint32): bool =
  let s = since(t)
  if s != DISABLED_TICKS:
    s < ticks
  else:
    false

# clear input state and disable input
proc inputDisable*() =
  state.input = InputState()

# enable input again
proc inputEnable*() =
  state.input.enabled = true

# get the current input as Dir
proc inputDir*(defaultDir: Dir): Dir =
  if state.input.up: DIR_UP
  elif state.input.down: DIR_DOWN
  elif state.input.right: DIR_RIGHT
  elif state.input.left: DIR_LEFT
  else: defaultDir
