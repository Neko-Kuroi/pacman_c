# pacman.nim -- application entry point and sokol-app callbacks.
# Corresponds to pacman.c lines 716-825.

import sokol/log as slog
import sokol/app as sapp
import pacstate
import timing
import rules
import render
import sound

proc init() {.cdecl.} =
  gfxInit()
  sndInit()
  start(state.intro.started)

proc frame() {.cdecl.} =
  # run the game at a fixed tick rate regardless of frame rate
  var frameTimeNs = (sapp.frameDuration() * 1_000_000_000.0).uint32
  if frameTimeNs > 33_333_333:
    frameTimeNs = 33_333_333
  state.timing.tickAccum += frameTimeNs.int32
  while state.timing.tickAccum > -TICK_TOLERANCE_NS.int32:
    state.timing.tickAccum -= TICK_DURATION_NS
    state.timing.tick += 1
    sndTick()
    if now(state.intro.started):
      state.gamestate = GAMESTATE_INTRO
    if now(state.game.started):
      state.gamestate = GAMESTATE_GAME
    case state.gamestate
    of GAMESTATE_INTRO:
      introTick()
    of GAMESTATE_GAME:
      gameTick()
  gfxDraw()
  sndFrame(frameTimeNs.int32)

proc input(ev: ptr sapp.Event) {.cdecl.} =
  if state.input.enabled:
    if ev.type == sapp.eventTypeKeyDown or ev.type == sapp.eventTypeKeyUp:
      let btnDown = ev.type == sapp.eventTypeKeyDown
      case ev.keyCode
      of sapp.keyCodeUp, sapp.keyCodeW:
        state.input.up = btnDown
        state.input.anykey = btnDown
      of sapp.keyCodeDown, sapp.keyCodeS:
        state.input.down = btnDown
        state.input.anykey = btnDown
      of sapp.keyCodeLeft, sapp.keyCodeA:
        state.input.left = btnDown
        state.input.anykey = btnDown
      of sapp.keyCodeRight, sapp.keyCodeD:
        state.input.right = btnDown
        state.input.anykey = btnDown
      of sapp.keyCodeF:
        if btnDown:
          sapp.toggleFullscreen()
      of sapp.keyCodeEscape:
        state.input.esc = btnDown
        state.input.anykey = btnDown
      else:
        state.input.anykey = btnDown

proc cleanup() {.cdecl.} =
  sndShutdown()
  gfxShutdown()

sapp.run(sapp.Desc(
  initCb: init,
  frameCb: frame,
  cleanupCb: cleanup,
  eventCb: input,
  width: DISPLAY_TILES_X * TILE_WIDTH * 2,
  height: DISPLAY_TILES_Y * TILE_HEIGHT * 2,
  depthFormat: sapp.pixelFormatNone,
  windowTitle: "pacman.c",
  icon: sapp.IconDesc(sokolDefault: true),
  logger: sapp.Logger(fn: slog.fn)))
