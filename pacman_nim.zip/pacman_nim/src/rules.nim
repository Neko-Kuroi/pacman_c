# rules.nim -- playfield setup, round setup, actor updates, the game tick
# and the intro tick. Corresponds to pacman.c lines 1377-1583, 1733-1748,
# 2089-2403.

import pacstate
import timing
import geom
import ghost
import render
import sound

# initialize the playfield tiles from the ASCII map (pacman.c 1377-1432)
proc gameInitPlayfield() =
  vidColorPlayfield(COLOR_DOT)
  const tiles =
    "0UUUUUUUUUUUU45UUUUUUUUUUUU1" &
    "L............rl............R" &
    "L.ebbf.ebbbf.rl.ebbbf.ebbf.R" &
    "LPr  l.r   l.rl.r   l.r  lPR" &
    "L.guuh.guuuh.gh.guuuh.guuh.R" &
    "L..........................R" &
    "L.ebbf.ef.ebbbbbbf.ef.ebbf.R" &
    "L.guuh.rl.guuyxuuh.rl.guuh.R" &
    "L......rl....rl....rl......R" &
    "2BBBBf.rzbbf rl ebbwl.eBBBB3" &
    "     L.rxuuh gh guuyl.R     " &
    "     L.rl          rl.R     " &
    "     L.rl mjs--tjn rl.R     " &
    "UUUUUh.gh i      q gh.gUUUUU" &
    "      .   i      q   .      " &
    "BBBBBf.ef i      q ef.eBBBBB" &
    "     L.rl okkkkkkp rl.R     " &
    "     L.rl          rl.R     " &
    "     L.rl ebbbbbbf rl.R     " &
    "0UUUUh.gh guuyxuuh gh.gUUUU1" &
    "L............rl............R" &
    "L.ebbf.ebbbf.rl.ebbbf.ebbf.R" &
    "L.guyl.guuuh.gh.guuuh.rxuh.R" &
    "LP..rl.......  .......rl..PR" &
    "6bf.rl.ef.ebbbbbbf.ef.rl.eb8" &
    "7uh.gh.rl.guuyxuuh.rl.gh.gu9" &
    "L......rl....rl....rl......R" &
    "L.ebbbbwzbbf.rl.ebbwzbbbbf.R" &
    "L.guuuuuuuuh.gh.guuuuuuuuh.R" &
    "L..........................R" &
    "2BBBBBBBBBBBBBBBBBBBBBBBBBB3"
  var t: array[128, uint8]
  for i in 0..<128:
    t[i] = TILE_DOT
  t[ord(' ')] = 0x40; t[ord('0')] = 0xD1; t[ord('1')] = 0xD0
  t[ord('2')] = 0xD5; t[ord('3')] = 0xD4; t[ord('4')] = 0xFB
  t[ord('5')] = 0xFA; t[ord('6')] = 0xD7; t[ord('7')] = 0xD9
  t[ord('8')] = 0xD6; t[ord('9')] = 0xD8; t[ord('U')] = 0xDB
  t[ord('L')] = 0xD3; t[ord('R')] = 0xD2; t[ord('B')] = 0xDC
  t[ord('b')] = 0xDF; t[ord('e')] = 0xE7; t[ord('f')] = 0xE6
  t[ord('g')] = 0xEB; t[ord('h')] = 0xEA; t[ord('l')] = 0xE8
  t[ord('r')] = 0xE9; t[ord('u')] = 0xE5; t[ord('w')] = 0xF5
  t[ord('x')] = 0xF2; t[ord('y')] = 0xF3; t[ord('z')] = 0xF4
  t[ord('m')] = 0xED; t[ord('n')] = 0xEC; t[ord('o')] = 0xEF
  t[ord('p')] = 0xEE; t[ord('j')] = 0xDD; t[ord('i')] = 0xD2
  t[ord('k')] = 0xDB; t[ord('q')] = 0xD3; t[ord('s')] = 0xF1
  t[ord('t')] = 0xF0; t[ord('-')] = TILE_DOOR; t[ord('P')] = TILE_PILL
  var i = 0
  for y in 3..33:
    for x in 0..<28:
      state.gfx.videoRam[y][x] = t[ord(tiles[i]) and 127]
      i += 1
  # ghost house gate colors
  vidColor(i2(13, 15), 0x18)
  vidColor(i2(14, 15), 0x18)

# disable all game loop timers
proc gameDisableTimers() =
  disable(state.game.roundWon)
  disable(state.game.gameOver)
  disable(state.game.dotEaten)
  disable(state.game.pillEaten)
  disable(state.game.ghostEaten)
  disable(state.game.pacmanEaten)
  disable(state.game.fruitEaten)
  disable(state.game.forceLeaveHouse)
  disable(state.game.fruitActive)

# one-time init at start of game state
proc gameInit() =
  inputEnable()
  gameDisableTimers()
  state.game.round = 0
  state.game.freeze = {FREEZETYPE_PRELUDE}
  state.game.numLives = NUM_LIVES
  state.game.globalDotCounterActive = false
  state.game.globalDotCounter = 0
  state.game.numDotsEaten = 0
  state.game.score = 0
  vidClear(TILE_SPACE, COLOR_DOT)
  vidColorText(i2(9, 0), COLOR_DEFAULT, "HIGH SCORE")
  gameInitPlayfield()
  vidColorText(i2(9, 14), 0x5, "PLAYER ONE")
  vidColorText(i2(11, 20), 0x9, "READY!")

# setup state at start of a game round
proc gameRoundInit() =
  sprClear()
  vidColorText(i2(9, 14), 0x10, "          ")
  if state.game.numDotsEaten == NUM_DOTS:
    # round won: redraw the playfield, reset the global dot counter
    state.game.round += 1
    state.game.numDotsEaten = 0
    gameInitPlayfield()
    state.game.globalDotCounterActive = false
  else:
    if state.game.numLives != NUM_LIVES:
      state.game.globalDotCounterActive = true
      state.game.globalDotCounter = 0
    state.game.numLives -= 1
  assert(state.game.numLives >= 0)

  state.game.activeFruit = FRUIT_NONE
  state.game.freeze = {FREEZETYPE_READY}
  state.game.xorshift = 0x12345678  # random-number-generator seed
  state.game.numGhostsEaten = 0
  gameDisableTimers()
  vidColorText(i2(11, 20), 0x9, "READY!")
  start(state.game.forceLeaveHouse)

  state.game.pacman = Pacman(actor: Actor(
    dir: DIR_LEFT, pos: i2(14 * 8, 26 * 8 + 4)))
  state.gfx.sprite[ord(SPRITE_PACMAN)] = Sprite(
    enabled: true, color: COLOR_PACMAN)

  state.game.ghost[ord(GHOSTTYPE_BLINKY)] = Ghost(
    actor: Actor(dir: DIR_LEFT, pos: ghostStartingPos[ord(GHOSTTYPE_BLINKY)]),
    typ: GHOSTTYPE_BLINKY, nextDir: DIR_LEFT, state: GHOSTSTATE_SCATTER,
    frightened: disabledTimer(), eaten: disabledTimer(),
    dotCounter: 0, dotLimit: 0)
  state.gfx.sprite[ord(SPRITE_BLINKY)] = Sprite(
    enabled: true, color: COLOR_BLINKY)

  state.game.ghost[ord(GHOSTTYPE_PINKY)] = Ghost(
    actor: Actor(dir: DIR_DOWN, pos: ghostStartingPos[ord(GHOSTTYPE_PINKY)]),
    typ: GHOSTTYPE_PINKY, nextDir: DIR_DOWN, state: GHOSTSTATE_HOUSE,
    frightened: disabledTimer(), eaten: disabledTimer(),
    dotCounter: 0, dotLimit: 0)
  state.gfx.sprite[ord(SPRITE_PINKY)] = Sprite(
    enabled: true, color: COLOR_PINKY)

  state.game.ghost[ord(GHOSTTYPE_INKY)] = Ghost(
    actor: Actor(dir: DIR_UP, pos: ghostStartingPos[ord(GHOSTTYPE_INKY)]),
    typ: GHOSTTYPE_INKY, nextDir: DIR_UP, state: GHOSTSTATE_HOUSE,
    frightened: disabledTimer(), eaten: disabledTimer(),
    dotCounter: 0, dotLimit: 30)
  state.gfx.sprite[ord(SPRITE_INKY)] = Sprite(
    enabled: true, color: COLOR_INKY)

  state.game.ghost[ord(GHOSTTYPE_CLYDE)] = Ghost(
    actor: Actor(dir: DIR_UP, pos: ghostStartingPos[ord(GHOSTTYPE_CLYDE)]),
    typ: GHOSTTYPE_CLYDE, nextDir: DIR_UP, state: GHOSTSTATE_HOUSE,
    frightened: disabledTimer(), eaten: disabledTimer(),
    dotCounter: 0, dotLimit: 60)
  state.gfx.sprite[ord(SPRITE_CLYDE)] = Sprite(
    enabled: true, color: COLOR_CLYDE)

# return true if Pacman should move in this tick
proc pacmanShouldMove(): bool =
  if now(state.game.dotEaten):
    false  # eating a dot stops Pacman for 1 tick
  elif since(state.game.pillEaten) < 3:
    false  # eating a pill stops Pacman for 3 ticks
  else:
    (state.timing.tick mod 8) != 0

# called when a dot or pill has been eaten
proc gameUpdateDotsEaten() =
  state.game.numDotsEaten += 1
  if state.game.numDotsEaten == NUM_DOTS:
    start(state.game.roundWon)
    sndClear()
  elif state.game.numDotsEaten == 70 or state.game.numDotsEaten == 170:
    start(state.game.fruitActive)
  # alternating crunch sound effect
  if (state.game.numDotsEaten and 1) != 0:
    sndStart(2, sndEatdot1)
  else:
    sndStart(2, sndEatdot2)

# the central Pacman and ghost behaviour function, called once per game tick
proc gameUpdateActors() =
  # Pacman "AI"
  if pacmanShouldMove():
    var actor = addr state.game.pacman.actor
    let wantedDir = inputDir(actor.dir)
    if canMove(actor.pos, wantedDir, true):
      actor.dir = wantedDir
    if canMove(actor.pos, actor.dir, true):
      actor.pos = move(actor.pos, actor.dir, true)
      actor.animTick += 1
    let tilePos = pixelToTilePos(actor.pos)
    if isDot(tilePos):
      vidTile(tilePos, TILE_SPACE)
      state.game.score += 1
      start(state.game.dotEaten)
      start(state.game.forceLeaveHouse)
      gameUpdateDotsEaten()
      updateGhosthouseDotCounters()
    if isPill(tilePos):
      vidTile(tilePos, TILE_SPACE)
      state.game.score += 5
      gameUpdateDotsEaten()
      start(state.game.pillEaten)
      state.game.numGhostsEaten = 0
      for i in 0..<state.game.ghost.len:
        start(state.game.ghost[i].frightened)
      sndStart(1, sndFrightened)
    # check if Pacman eats the bonus fruit
    if state.game.activeFruit != FRUIT_NONE:
      let testPos = pixelToTilePos(actor.pos + i2(TILE_WIDTH div 2, 0))
      if testPos == i2(14, 20):
        start(state.game.fruitEaten)
        state.game.score += levelspec(state.game.round.int).bonusScore.uint32
        vidFruitScore(state.game.activeFruit)
        state.game.activeFruit = FRUIT_NONE
        sndStart(2, sndEatfruit)
    # check if Pacman collides with any ghost
    for i in 0..<state.game.ghost.len:
      var ghost = addr state.game.ghost[i]
      let ghostTilePos = pixelToTilePos(ghost.actor.pos)
      if tilePos == ghostTilePos:
        if ghost.state == GHOSTSTATE_FRIGHTENED:
          ghost.state = GHOSTSTATE_EYES
          start(ghost.eaten)
          start(state.game.ghostEaten)
          state.game.numGhostsEaten += 1
          # increase score by 20, 40, 80, 160 (in 10-point units)
          state.game.score += (10 * (1 shl state.game.numGhostsEaten)).uint32
          state.game.freeze.incl(FREEZETYPE_EAT_GHOST)
          sndStart(2, sndEatghost)
        elif ghost.state == GHOSTSTATE_CHASE or
             ghost.state == GHOSTSTATE_SCATTER:
          sndClear()
          start(state.game.pacmanEaten)
          state.game.freeze.incl(FREEZETYPE_DEAD)
          if state.game.numLives > 0:
            startAfter(state.game.readyStarted,
                       PACMAN_EATEN_TICKS + PACMAN_DEATH_TICKS)
          else:
            startAfter(state.game.gameOver,
                       PACMAN_EATEN_TICKS + PACMAN_DEATH_TICKS)

  # Ghost "AIs"
  for ghostIndex in 0..<state.game.ghost.len:
    var ghost = addr state.game.ghost[ghostIndex]
    updateGhostState(ghost[])
    updateGhostTarget(ghost[])
    let numMoveTicks = ghostSpeed(ghost[])
    for i in 0..<numMoveTicks:
      let forceMove = updateGhostDir(ghost[])
      if forceMove or canMove(ghost.actor.pos, ghost.actor.dir, false):
        ghost.actor.pos = move(ghost.actor.pos, ghost.actor.dir, false)
        ghost.actor.animTick += 1

# the central game tick function, called at 60 Hz
proc gameTick*() =
  if now(state.game.started):
    start(state.gfx.fadein)
    startAfter(state.game.readyStarted, 2 * 60)
    sndStart(0, sndPrelude)
    gameInit()
  if now(state.game.readyStarted):
    gameRoundInit()
    startAfter(state.game.roundStarted, 2 * 60 + 10)
  if now(state.game.roundStarted):
    state.game.freeze.excl(FREEZETYPE_READY)
    vidColorText(i2(11, 20), 0x10, "      ")
    sndStart(1, sndWeeooh)

  # activate/deactivate bonus fruit
  if now(state.game.fruitActive):
    state.game.activeFruit = levelspec(state.game.round.int).bonusFruit
  elif afterOnce(state.game.fruitActive, FRUITACTIVE_TICKS):
    state.game.activeFruit = FRUIT_NONE

  # stop frightened sound and restart the weeooh sound
  if afterOnce(state.game.pillEaten,
               levelspec(state.game.round.int).frightTicks.uint32):
    sndStart(1, sndWeeooh)

  # unfreeze after Pacman ate a ghost
  if FREEZETYPE_EAT_GHOST in state.game.freeze:
    if afterOnce(state.game.ghostEaten, GHOST_EATEN_FREEZE_TICKS):
      state.game.freeze.excl(FREEZETYPE_EAT_GHOST)

  # play the pacman-death sound
  if afterOnce(state.game.pacmanEaten, PACMAN_EATEN_TICKS):
    sndStart(2, sndDead)

  if state.game.freeze.len == 0:
    gameUpdateActors()
  gameUpdateTiles()
  gameUpdateSprites()

  if state.game.score > state.game.hiscore:
    state.game.hiscore = state.game.score

  # check for end-of-round conditions
  if now(state.game.roundWon):
    state.game.freeze.incl(FREEZETYPE_WON)
    startAfter(state.game.readyStarted, ROUNDWON_TICKS)
  if now(state.game.gameOver):
    vidColorText(i2(9, 20), 0x01, "GAME  OVER")
    inputDisable()
    startAfter(state.gfx.fadeout, GAMEOVER_TICKS)
    startAfter(state.intro.started, GAMEOVER_TICKS + FADE_TICKS)

# the intro screen tick function
proc introTick*() =
  if now(state.intro.started):
    sndClear()
    sprClear()
    start(state.gfx.fadein)
    inputEnable()
    vidClear(TILE_SPACE, COLOR_DEFAULT)
    vidText(i2(3, 0), "1UP   HIGH SCORE   2UP")
    vidColorScore(i2(6, 1), COLOR_DEFAULT, 0)
    if state.game.hiscore > 0:
      vidColorScore(i2(16, 1), COLOR_DEFAULT, state.game.hiscore)
    vidText(i2(7, 5), "CHARACTER / NICKNAME")
    vidText(i2(3, 35), "CREDIT  0")

  var delay = 30'u32
  const names = ["-SHADOW", "-SPEEDY", "-BASHFUL", "-POKEY"]
  const nicknames = ["BLINKY", "PINKY", "INKY", "CLYDE"]
  for i in 0..<4:
    let color = (2 * i + 1).uint8
    let y = (3 * i + 6).int16
    delay += 30
    if afterOnce(state.intro.started, delay):
      vidColorTile(i2(4, y + 0), color, TILE_GHOST + 0)
      vidColorTile(i2(5, y + 0), color, TILE_GHOST + 1)
      vidColorTile(i2(4, y + 1), color, TILE_GHOST + 2)
      vidColorTile(i2(5, y + 1), color, TILE_GHOST + 3)
      vidColorTile(i2(4, y + 2), color, TILE_GHOST + 4)
      vidColorTile(i2(5, y + 2), color, TILE_GHOST + 5)
    delay += 60
    if afterOnce(state.intro.started, delay):
      vidColorText(i2(7, y + 1), color, names[i])
    delay += 30
    if afterOnce(state.intro.started, delay):
      vidColorText(i2(17, y + 1), color, nicknames[i])

  delay += 60
  if afterOnce(state.intro.started, delay):
    vidColorTile(i2(10, 24), COLOR_DOT, TILE_DOT)
    vidText(i2(12, 24), "10 \x5D\x5E\x5F")
    vidColorTile(i2(10, 26), COLOR_DOT, TILE_PILL)
    vidText(i2(12, 26), "50 \x5D\x5E\x5F")

  delay += 60
  if after(state.intro.started, delay):
    if (since(state.intro.started) and 0x20) != 0:
      vidColorText(i2(3, 31), 3, "                       ")
    else:
      vidColorText(i2(3, 31), 3, "PRESS ANY KEY TO START!")

  if state.input.anykey:
    inputDisable()
    start(state.gfx.fadeout)
    startAfter(state.game.started, FADE_TICKS)
