# geom.nim -- geometry and playfield queries.
# Corresponds to pacman.c lines 988-991 and 1230-1361.

import pacstate

# C-style remainder (truncates toward zero), spelled out to mirror
# C's `%`; Nim's `mod` truncates identically, so this equals `mod`.
proc cmod*(a, b: int16): int16 =
  a - (a div b) * b

proc distToTileMid*(pos: Int2): Int2 =
  i2(TILE_WIDTH div 2 - cmod(pos.x, TILE_WIDTH),
     TILE_HEIGHT div 2 - cmod(pos.y, TILE_HEIGHT))

proc pixelToTilePos*(pixPos: Int2): Int2 =
  i2(pixPos.x div TILE_WIDTH, pixPos.y div TILE_HEIGHT)

# clamp tile pos to valid playfield coords
proc clampedTilePos*(tilePos: Int2): Int2 =
  result = tilePos
  if result.x < 0:
    result.x = 0
  elif result.x >= DISPLAY_TILES_X:
    result.x = DISPLAY_TILES_X - 1
  if result.y < 3:
    result.y = 3
  elif result.y >= (DISPLAY_TILES_Y - 2):
    result.y = DISPLAY_TILES_Y - 3

const dirMap: array[4, Int2] = [i2(+1, 0), i2(0, +1), i2(-1, 0), i2(0, -1)]

proc dirToVec*(dir: Dir): Int2 =
  assert(dir >= DIR_RIGHT and dir < NUM_DIRS)
  dirMap[ord(dir)]

proc reverseDir*(dir: Dir): Dir =
  case dir
  of DIR_RIGHT: DIR_LEFT
  of DIR_DOWN: DIR_UP
  of DIR_LEFT: DIR_RIGHT
  else: DIR_DOWN

proc tileCodeAt*(tilePos: Int2): uint8 =
  assert(tilePos.x >= 0 and tilePos.x < DISPLAY_TILES_X)
  assert(tilePos.y >= 0 and tilePos.y < DISPLAY_TILES_Y)
  state.gfx.videoRam[tilePos.y][tilePos.x]

proc isBlockingTile*(tilePos: Int2): bool =
  tileCodeAt(tilePos) >= 0xC0

proc isDot*(tilePos: Int2): bool =
  tileCodeAt(tilePos) == TILE_DOT

proc isPill*(tilePos: Int2): bool =
  tileCodeAt(tilePos) == TILE_PILL

proc isTunnel*(tilePos: Int2): bool =
  tilePos.y == 17 and (tilePos.x <= 5 or tilePos.x >= 22)

# positions where upward movement is forbidden for ghosts
proc isRedzone*(tilePos: Int2): bool =
  tilePos.x >= 11 and tilePos.x <= 16 and (tilePos.y == 14 or tilePos.y == 26)

# test if movement from a pixel position in a wanted direction is possible
proc canMove*(pos: Int2, wantedDir: Dir, allowCornering: bool): bool =
  let dirVec = dirToVec(wantedDir)
  let distMid = distToTileMid(pos)
  var moveDistMid, perpDistMid: int16
  if dirVec.y != 0:
    moveDistMid = distMid.y
    perpDistMid = distMid.x
  else:
    moveDistMid = distMid.x
    perpDistMid = distMid.y
  let tilePos = pixelToTilePos(pos)
  let checkPos = clampedTilePos(tilePos + dirVec)
  let isBlocked = isBlockingTile(checkPos)
  not ((not allowCornering and perpDistMid != 0) or
       (isBlocked and moveDistMid == 0))

# compute a new pixel position along a direction (without blocking check)
proc move*(pos: Int2, dir: Dir, allowCornering: bool): Int2 =
  let dirVec = dirToVec(dir)
  result = pos + dirVec
  if allowCornering:
    let distMid = distToTileMid(result)
    if dirVec.x != 0:
      if distMid.y < 0: result.y -= 1
      elif distMid.y > 0: result.y += 1
    elif dirVec.y != 0:
      if distMid.x < 0: result.x -= 1
      elif distMid.x > 0: result.x += 1
  if result.x < 0:
    result.x = DISPLAY_PIXELS_X - 1
  elif result.x >= DISPLAY_PIXELS_X:
    result.x = 0
