# render.nim -- video RAM writes, sprite animation, and the sokol-gfx renderer.
# Corresponds to pacman.c lines 993-1229 (vid/spr), 1584-1732 (tile/sprite
# updates) and 2404-3124 (gfx subsystem).

import sokol/log as slog
import sokol/app as sapp
import sokol/gfx as sg
import sokol/glue as sglue
import sokol/letterbox as slbx
import pacstate
import timing
import romdata
import shaders

# --- vid: writes into the tile/color buffers (pacman.c 993-1133) ---

proc vidClear*(tileCode, colorCode: uint8) =
  for y in 0..<DISPLAY_TILES_Y:
    for x in 0..<DISPLAY_TILES_X:
      state.gfx.videoRam[y][x] = tileCode
      state.gfx.colorRam[y][x] = colorCode

proc vidColorPlayfield*(colorCode: uint8) =
  for y in 3..<(DISPLAY_TILES_Y - 2):
    for x in 0..<DISPLAY_TILES_X:
      state.gfx.colorRam[y][x] = colorCode

proc validTilePos(tilePos: Int2): bool =
  tilePos.x >= 0 and tilePos.x < DISPLAY_TILES_X and
    tilePos.y >= 0 and tilePos.y < DISPLAY_TILES_Y

proc vidColor*(tilePos: Int2, colorCode: uint8) =
  assert(validTilePos(tilePos))
  state.gfx.colorRam[tilePos.y][tilePos.x] = colorCode

proc vidTile*(tilePos: Int2, tileCode: uint8) =
  assert(validTilePos(tilePos))
  state.gfx.videoRam[tilePos.y][tilePos.x] = tileCode

proc vidColorTile*(tilePos: Int2, colorCode, tileCode: uint8) =
  assert(validTilePos(tilePos))
  state.gfx.videoRam[tilePos.y][tilePos.x] = tileCode
  state.gfx.colorRam[tilePos.y][tilePos.x] = colorCode

# translate ASCII char into "NAMCO char"
proc convChar(c: char): uint8 =
  case c
  of ' ': 0x40'u8
  of '/': 58'u8
  of '-': 59'u8
  of '"': 38'u8
  of '!': uint8('Z') + 1
  else: uint8(c)

proc vidColorChar(tilePos: Int2, colorCode: uint8, chr: char) =
  assert(validTilePos(tilePos))
  state.gfx.videoRam[tilePos.y][tilePos.x] = convChar(chr)
  state.gfx.colorRam[tilePos.y][tilePos.x] = colorCode

proc vidChar(tilePos: Int2, chr: char) =
  assert(validTilePos(tilePos))
  state.gfx.videoRam[tilePos.y][tilePos.x] = convChar(chr)

proc vidColorText*(tilePos: Int2, colorCode: uint8, text: string) =
  assert(validTilePos(tilePos))
  var tp = tilePos
  for chr in text:
    if tp.x < DISPLAY_TILES_X:
      vidColorChar(tp, colorCode, chr)
      tp.x += 1
    else:
      break

proc vidText*(tilePos: Int2, text: string) =
  assert(validTilePos(tilePos))
  var tp = tilePos
  for chr in text:
    if tp.x < DISPLAY_TILES_X:
      vidChar(tp, chr)
      tp.x += 1
    else:
      break

# print a score (scores are /10, printed right to left, last digit always 0)
proc vidColorScore*(tilePos: Int2, colorCode: uint8, score: uint32) =
  var tp = tilePos
  var s = score
  vidColorChar(tp, colorCode, '0')
  tp.x -= 1
  for digit in 0..<8:
    let chr = char((s mod 10) + uint32('0'))
    if validTilePos(tp):
      vidColorChar(tp, colorCode, chr)
      tp.x -= 1
      s = s div 10
      if s == 0:
        break

# draw a 2x2 tile quad (used for lives and status fruits)
proc vidDrawTileQuad*(tilePos: Int2, colorCode, tileCode: uint8) =
  for yy in 0..<2:
    for xx in 0..<2:
      let t = tileCode + (yy * 2 + (1 - xx)).uint8
      vidColorTile(i2((xx + tilePos.x).int16, (yy + tilePos.y).int16),
                   colorCode, t)

# draw the fruit bonus score tiles (when Pacman has eaten the bonus fruit)
proc vidFruitScore*(fruitType: Fruit) =
  assert(fruitType >= FRUIT_NONE and fruitType < NUM_FRUITS)
  let colorCode = if fruitType == FRUIT_NONE: COLOR_DOT else: COLOR_FRUIT_SCORE
  for i in 0..<4:
    vidColorTile(i2((12 + i).int16, 20), colorCode,
                 fruitScoreTiles[ord(fruitType)][i])

# --- spr: sprite state and animation (pacman.c 1134-1229) ---

proc sprClear*() =
  for i in 0..<NUM_SPRITES:
    state.gfx.sprite[i] = Sprite()

proc sprPacman*(): ptr Sprite =
  addr state.gfx.sprite[ord(SPRITE_PACMAN)]

proc sprGhost*(typ: GhostType): ptr Sprite =
  assert(typ >= GHOSTTYPE_BLINKY and typ < NUM_GHOSTS)
  addr state.gfx.sprite[ord(SPRITE_BLINKY) + ord(typ)]

proc sprFruit*(): ptr Sprite =
  addr state.gfx.sprite[ord(SPRITE_FRUIT)]

proc sprAnimPacman*(dir: Dir, tick: uint32) =
  const tiles: array[2, array[4, uint8]] = [
    [44'u8, 46, 48, 46],   # horizontal (needs flipx)
    [45'u8, 47, 48, 47]]   # vertical (needs flipy)
  var spr = sprPacman()
  let phase = (tick div 2) and 3
  spr.tile = tiles[ord(dir) and 1][phase]
  spr.color = COLOR_PACMAN
  spr.flipx = dir == DIR_LEFT
  spr.flipy = dir == DIR_UP

proc sprAnimPacmanDeath*(tick: uint32) =
  var spr = sprPacman()
  var tile = 52 + (tick div 8)
  if tile > 63:
    tile = 63
  spr.tile = tile.uint8
  spr.flipx = false
  spr.flipy = false

proc sprAnimGhost*(ghostType: GhostType, dir: Dir, tick: uint32) =
  assert(dir >= DIR_RIGHT and dir < NUM_DIRS)
  const tiles: array[4, array[2, uint8]] = [
    [32'u8, 33], [34'u8, 35], [36'u8, 37], [38'u8, 39]]
  let phase = (tick div 8) and 1
  var spr = sprGhost(ghostType)
  spr.tile = tiles[ord(dir)][phase]
  spr.color = COLOR_BLINKY + (2 * ord(ghostType)).uint8
  spr.flipx = false
  spr.flipy = false

proc sprAnimGhostFrightened*(ghostType: GhostType, tick: uint32) =
  const tiles: array[2, uint8] = [28'u8, 29]
  let phase = (tick div 4) and 1
  var spr = sprGhost(ghostType)
  spr.tile = tiles[phase]
  # towards the end of the frightened period, start blinking (the C code
  # casts the possibly negative difference to uint32, replicated here)
  if tick > (levelspec(state.game.round.int).frightTicks.int32 - 60).uint32:
    spr.color = if (tick and 0x10) != 0: COLOR_FRIGHTENED
                else: COLOR_FRIGHTENED_BLINKING
  else:
    spr.color = COLOR_FRIGHTENED
  spr.flipx = false
  spr.flipy = false

proc sprAnimGhostEyes*(ghostType: GhostType, dir: Dir) =
  assert(dir >= DIR_RIGHT and dir < NUM_DIRS)
  const tiles: array[4, uint8] = [32'u8, 34, 36, 38]
  var spr = sprGhost(ghostType)
  spr.tile = tiles[ord(dir)]
  spr.color = COLOR_EYES
  spr.flipx = false
  spr.flipy = false

# --- dynamic tile and sprite updates (pacman.c 1584-1732) ---

proc gameUpdateTiles*() =
  vidColorScore(i2(6, 1), COLOR_DEFAULT, state.game.score)
  if state.game.hiscore > 0:
    vidColorScore(i2(16, 1), COLOR_DEFAULT, state.game.hiscore)

  const pillPos: array[NUM_PILLS, Int2] = [
    i2(1, 6), i2(26, 6), i2(1, 26), i2(26, 26)]
  for i in 0..<NUM_PILLS:
    if state.game.freeze != {}:
      vidColor(pillPos[i], COLOR_DOT)
    else:
      vidColor(pillPos[i], if (state.timing.tick and 0x8) != 0: 0x10'u8 else: 0'u8)

  if afterOnce(state.game.fruitEaten, 2 * 60):
    vidFruitScore(FRUIT_NONE)

  for i in 0..<NUM_LIVES:
    let color = if i < state.game.numLives.int: COLOR_PACMAN else: 0'u8
    vidDrawTileQuad(i2((2 + 2 * i).int16, 34), color, TILE_LIFE)

  # bonus fruit list in the bottom-right corner
  block:
    var x = 24'i16
    let round = state.game.round.int
    for i in (round - NUM_STATUS_FRUITS + 1)..round:
      if i >= 0:
        let fruit = levelspec(i).bonusFruit
        vidDrawTileQuad(i2(x, 34), fruitTilesColors[ord(fruit)][2],
                        fruitTilesColors[ord(fruit)][0])
        x -= 2

  # if the round was won, blink the whole playfield blue/white
  if after(state.game.roundWon, 1 * 60):
    if (since(state.game.roundWon) and 0x10) != 0:
      vidColorPlayfield(COLOR_DOT)
    else:
      vidColorPlayfield(COLOR_WHITE_BORDER)

proc gameUpdateSprites*() =
  # Pacman sprite
  block:
    var spr = sprPacman()
    if spr.enabled:
      let actor = state.game.pacman.actor
      spr.pos = actorToSpritePos(actor.pos)
      if FREEZETYPE_EAT_GHOST in state.game.freeze:
        spr.tile = SPRITETILE_INVISIBLE
      elif FREEZETYPE_PRELUDE in state.game.freeze or
           FREEZETYPE_READY in state.game.freeze:
        spr.tile = SPRITETILE_PACMAN_CLOSED_MOUTH
      elif FREEZETYPE_DEAD in state.game.freeze:
        if after(state.game.pacmanEaten, PACMAN_EATEN_TICKS):
          sprAnimPacmanDeath(since(state.game.pacmanEaten) - PACMAN_EATEN_TICKS)
      else:
        sprAnimPacman(actor.dir, actor.animTick)

  # ghost sprites
  for i in 0..<state.game.ghost.len:
    var sprite = sprGhost(GhostType(i))
    if sprite.enabled:
      let ghost = state.game.ghost[i]
      sprite.pos = actorToSpritePos(ghost.actor.pos)
      if FREEZETYPE_DEAD in state.game.freeze:
        if after(state.game.pacmanEaten, PACMAN_EATEN_TICKS):
          sprite.tile = SPRITETILE_INVISIBLE
      elif FREEZETYPE_WON in state.game.freeze:
        sprite.tile = SPRITETILE_INVISIBLE
      else:
        case ghost.state
        of GHOSTSTATE_EYES:
          if before(ghost.eaten, GHOST_EATEN_FREEZE_TICKS):
            # show the score number for the just-eaten ghost
            sprite.tile = (SPRITETILE_SCORE_200.int +
                           state.game.numGhostsEaten.int - 1).uint8
            sprite.color = COLOR_GHOST_SCORE
          else:
            sprAnimGhostEyes(GhostType(i), ghost.nextDir)
        of GHOSTSTATE_ENTERHOUSE:
          sprAnimGhostEyes(GhostType(i), ghost.actor.dir)
        of GHOSTSTATE_FRIGHTENED:
          sprAnimGhostFrightened(GhostType(i), since(ghost.frightened))
        else:
          sprAnimGhost(GhostType(i), ghost.nextDir, ghost.actor.animTick)

  # bonus fruit sprite
  if state.game.activeFruit == FRUIT_NONE:
    sprFruit().enabled = false
  else:
    var spr = sprFruit()
    spr.enabled = true
    spr.pos = i2(13 * TILE_WIDTH, 19 * TILE_HEIGHT + TILE_HEIGHT div 2)
    spr.tile = fruitTilesColors[ord(state.game.activeFruit)][1]
    spr.color = fruitTilesColors[ord(state.game.activeFruit)][2]

# --- gfx subsystem (pacman.c 2404-3124) ---

proc gfxDecodeTile8x4(texX, texY: uint32, tileBase: openArray[uint8],
                      tileStride, tileOffset: uint32, tileCode: uint8) =
  for tx in 0..<TILE_WIDTH:
    let ti = tileCode.uint32 * tileStride + tileOffset + (7 - tx).uint32
    for ty in 0..<(TILE_HEIGHT div 2):
      let pHi = (tileBase[ti.int] shr (7 - ty)) and 1
      let pLo = (tileBase[ti.int] shr (3 - ty)) and 1
      let p = (pHi shl 1) or pLo
      state.gfx.tilePixels[texY.int + ty][texX.int + tx] = p

proc gfxDecodeTile(tileCode: uint8) =
  let x = tileCode.uint32 * TILE_WIDTH.uint32
  gfxDecodeTile8x4(x, 0, romTiles, 16, 8, tileCode)
  gfxDecodeTile8x4(x, TILE_HEIGHT div 2, romTiles, 16, 0, tileCode)

proc gfxDecodeSprite(spriteCode: uint8) =
  let x0 = spriteCode.uint32 * SPRITE_WIDTH.uint32
  let x1 = x0 + TILE_WIDTH.uint32
  let y0 = TILE_HEIGHT.uint32
  let y1 = y0 + (TILE_HEIGHT div 2).uint32
  let y2 = y1 + (TILE_HEIGHT div 2).uint32
  let y3 = y2 + (TILE_HEIGHT div 2).uint32
  gfxDecodeTile8x4(x0, y0, romSprites, 64, 40, spriteCode)
  gfxDecodeTile8x4(x1, y0, romSprites, 64, 8, spriteCode)
  gfxDecodeTile8x4(x0, y1, romSprites, 64, 48, spriteCode)
  gfxDecodeTile8x4(x1, y1, romSprites, 64, 16, spriteCode)
  gfxDecodeTile8x4(x0, y2, romSprites, 64, 56, spriteCode)
  gfxDecodeTile8x4(x1, y2, romSprites, 64, 24, spriteCode)
  gfxDecodeTile8x4(x0, y3, romSprites, 64, 32, spriteCode)
  gfxDecodeTile8x4(x1, y3, romSprites, 64, 0, spriteCode)

proc gfxDecodeTiles() =
  for tileCode in 0..<256:
    gfxDecodeTile(tileCode.uint8)
  for spriteCode in 0..<64:
    gfxDecodeSprite(spriteCode.uint8)
  # a special opaque 16x16 block used for the fade effect (sprite tile 64)
  for y in TILE_HEIGHT..<TILE_TEXTURE_HEIGHT:
    for x in (64 * SPRITE_WIDTH)..<(65 * SPRITE_WIDTH):
      state.gfx.tilePixels[y][x] = 1

proc gfxDecodeColorPalette() =
  var hwColors: array[32, uint32]
  for i in 0..<32:
    let rgb = romHwcolors[i]
    let r = ((rgb shr 0) and 1) * 0x21 + ((rgb shr 1) and 1) * 0x47 +
            ((rgb shr 2) and 1) * 0x97
    let g = ((rgb shr 3) and 1) * 0x21 + ((rgb shr 4) and 1) * 0x47 +
            ((rgb shr 5) and 1) * 0x97
    let b = ((rgb shr 6) and 1) * 0x47 + ((rgb shr 7) and 1) * 0x97
    hwColors[i] = 0xFF000000'u32 or (b.uint32 shl 16) or (g.uint32 shl 8) or r.uint32
  for i in 0..<256:
    state.gfx.colorPalette[i] = hwColors[romPalette[i] and 0xF]
    if (i and 3) == 0:
      state.gfx.colorPalette[i] = state.gfx.colorPalette[i] and 0x00FFFFFF'u32

proc gfxCreateResources() =
  var passAction = sg.PassAction()
  passAction.colors[0] = sg.ColorAttachmentAction(
    loadAction: sg.loadActionClear, clearValue: (0.0f, 0.0f, 0.0f, 1.0f))
  state.gfx.offscreenPass.action = passAction
  state.gfx.displayPassAction = passAction

  state.gfx.offscreenVbuf = sg.makeBuffer(sg.BufferDesc(
    usage: sg.BufferUsage(vertexBuffer: true, writeTransient: true),
    size: sizeof(state.gfx.vertices)))

  var quadVerts: array[8, float32] = [0.0f, 0.0f, 1.0f, 0.0f,
                                      0.0f, 1.0f, 1.0f, 1.0f]
  state.gfx.displayQuadVbuf = sg.makeBuffer(sg.BufferDesc(
    data: sg.Range(addr: addr quadVerts[0], size: sizeof(quadVerts))))

  let src = shaderSources(sg.queryBackend())

  # pipeline and shader for rendering into the offscreen render target
  var offShd = sg.ShaderDesc()
  offShd.attrs[0] = sg.ShaderVertexAttr(glslName: "pos", hlslSemName: "POSITION")
  offShd.attrs[1] = sg.ShaderVertexAttr(glslName: "uv_in", hlslSemName: "TEXCOORD", hlslSemIndex: 0)
  offShd.attrs[2] = sg.ShaderVertexAttr(glslName: "data_in", hlslSemName: "TEXCOORD", hlslSemIndex: 1)
  offShd.vertexFunc.source = src.offscreenVs.cstring
  offShd.fragmentFunc.source = src.offscreenFs.cstring
  offShd.views[0].texture = sg.ShaderTextureView(stage: sg.shaderStageFragment, hlslRegisterTN: 0, mslTextureN: 0)
  offShd.views[1].texture = sg.ShaderTextureView(stage: sg.shaderStageFragment, hlslRegisterTN: 1, mslTextureN: 1)
  offShd.samplers[0] = sg.ShaderSampler(stage: sg.shaderStageFragment, hlslRegisterSN: 0, mslSamplerN: 0)
  offShd.samplers[1] = sg.ShaderSampler(stage: sg.shaderStageFragment, hlslRegisterSN: 1, mslSamplerN: 1)
  offShd.textureSamplerPairs[0] = sg.ShaderTextureSamplerPair(stage: sg.shaderStageFragment, viewSlot: 0, samplerSlot: 0, glslName: "tile_tex")
  offShd.textureSamplerPairs[1] = sg.ShaderTextureSamplerPair(stage: sg.shaderStageFragment, viewSlot: 1, samplerSlot: 1, glslName: "pal_tex")
  var offPip = sg.PipelineDesc()
  offPip.shader = sg.makeShader(offShd)
  offPip.layout.attrs[0].format = sg.vertexFormatFloat2
  offPip.layout.attrs[1].format = sg.vertexFormatFloat2
  offPip.layout.attrs[2].format = sg.vertexFormatUbyte4n
  offPip.depth.pixelFormat = sg.pixelFormatNone
  offPip.colors[0].pixelFormat = sg.pixelFormatRgba8
  offPip.colors[0].blend.enabled = true
  offPip.colors[0].blend.srcFactorRgb = sg.blendFactorSrcAlpha
  offPip.colors[0].blend.dstFactorRgb = sg.blendFactorOneMinusSrcAlpha
  state.gfx.offscreenPip = sg.makePipeline(offPip)

  # pipeline and shader for rendering into the display
  var dispShd = sg.ShaderDesc()
  dispShd.attrs[0] = sg.ShaderVertexAttr(glslName: "pos", hlslSemName: "POSITION")
  dispShd.vertexFunc.source = src.displayVs.cstring
  dispShd.fragmentFunc.source = src.displayFs.cstring
  dispShd.views[0].texture = sg.ShaderTextureView(stage: sg.shaderStageFragment, hlslRegisterTN: 0, mslTextureN: 0)
  dispShd.samplers[0] = sg.ShaderSampler(stage: sg.shaderStageFragment, hlslRegisterSN: 0, mslSamplerN: 0)
  dispShd.textureSamplerPairs[0] = sg.ShaderTextureSamplerPair(stage: sg.shaderStageFragment, viewSlot: 0, samplerSlot: 0, glslName: "tex")
  var dispPip = sg.PipelineDesc()
  dispPip.shader = sg.makeShader(dispShd)
  dispPip.layout.attrs[0].format = sg.vertexFormatFloat2
  dispPip.primitiveType = sg.primitiveTypeTriangleStrip
  state.gfx.displayPip = sg.makePipeline(dispPip)

  # image and views for the rendered result
  state.gfx.render.img = sg.makeImage(sg.ImageDesc(
    usage: sg.ImageUsage(colorAttachment: true),
    width: (DISPLAY_PIXELS_X * 2).int32,
    height: (DISPLAY_PIXELS_Y * 2).int32,
    pixelFormat: sg.pixelFormatRgba8))
  state.gfx.render.texView = sg.makeView(sg.ViewDesc(
    texture: sg.TextureViewDesc(image: state.gfx.render.img)))
  state.gfx.offscreenPass.attachments.colors[0] = sg.makeView(sg.ViewDesc(
    colorAttachment: sg.ImageViewDesc(image: state.gfx.render.img)))

  # image and view for the tile ROM
  state.gfx.tilerom.img = sg.makeImage(sg.ImageDesc(
    width: TILE_TEXTURE_WIDTH.int32,
    height: TILE_TEXTURE_HEIGHT.int32,
    pixelFormat: sg.pixelFormatR8,
    data: sg.Range(addr: addr state.gfx.tilePixels[0][0],
                   size: sizeof(state.gfx.tilePixels))))
  state.gfx.tilerom.texView = sg.makeView(sg.ViewDesc(
    texture: sg.TextureViewDesc(image: state.gfx.tilerom.img)))

  # image and view for the color palette
  state.gfx.palette.img = sg.makeImage(sg.ImageDesc(
    width: 256,
    height: 1,
    pixelFormat: sg.pixelFormatRgba8,
    data: sg.Range(addr: addr state.gfx.colorPalette[0],
                   size: sizeof(state.gfx.colorPalette))))
  state.gfx.palette.texView = sg.makeView(sg.ViewDesc(
    texture: sg.TextureViewDesc(image: state.gfx.palette.img)))

  state.gfx.linearSmp = sg.makeSampler(sg.SamplerDesc(
    minFilter: sg.filterLinear, magFilter: sg.filterLinear,
    wrapU: sg.wrapClampToEdge, wrapV: sg.wrapClampToEdge))
  state.gfx.nearestSmp = sg.makeSampler(sg.SamplerDesc(
    minFilter: sg.filterNearest, magFilter: sg.filterNearest,
    wrapU: sg.wrapClampToEdge, wrapV: sg.wrapClampToEdge))

proc gfxInit*() =
  sg.setup(sg.Desc(
    bufferPoolSize: 2,
    imagePoolSize: 3,
    shaderPoolSize: 2,
    pipelinePoolSize: 2,
    viewPoolSize: 8,
    environment: sglue.environment(),
    logger: sg.Logger(fn: slog.fn)))
  disable(state.gfx.fadein)
  disable(state.gfx.fadeout)
  state.gfx.fade = 0xFF
  sprClear()
  gfxDecodeTiles()
  gfxDecodeColorPalette()
  gfxCreateResources()

proc gfxShutdown*() =
  sg.shutdown()

proc gfxAddVertex(x, y, u, v: float32, colorCode, opacity: uint8) =
  assert(state.gfx.numVertices < MAX_VERTICES)
  var vtx = addr state.gfx.vertices[state.gfx.numVertices]
  state.gfx.numVertices += 1
  vtx.x = x
  vtx.y = y
  vtx.u = u
  vtx.v = v
  vtx.attr = (opacity.uint32 shl 8) or colorCode.uint32

proc gfxAddTileVertices(tx, ty: uint32, tileCode, colorCode: uint8) =
  assert(tx < DISPLAY_TILES_X and ty < DISPLAY_TILES_Y)
  const dx = 1.0f / DISPLAY_TILES_X.float32
  const dy = 1.0f / DISPLAY_TILES_Y.float32
  const du = TILE_WIDTH.float32 / TILE_TEXTURE_WIDTH.float32
  const dv = TILE_HEIGHT.float32 / TILE_TEXTURE_HEIGHT.float32
  let x0 = tx.float32 * dx
  let x1 = x0 + dx
  let y0 = ty.float32 * dy
  let y1 = y0 + dy
  let u0 = tileCode.float32 * du
  let u1 = u0 + du
  let v0 = 0.0f
  let v1 = dv
  gfxAddVertex(x0, y0, u0, v0, colorCode, 0xFF)
  gfxAddVertex(x1, y0, u1, v0, colorCode, 0xFF)
  gfxAddVertex(x1, y1, u1, v1, colorCode, 0xFF)
  gfxAddVertex(x0, y0, u0, v0, colorCode, 0xFF)
  gfxAddVertex(x1, y1, u1, v1, colorCode, 0xFF)
  gfxAddVertex(x0, y1, u0, v1, colorCode, 0xFF)

proc gfxAddPlayfieldVertices() =
  for ty in 0..<DISPLAY_TILES_Y:
    for tx in 0..<DISPLAY_TILES_X:
      let tileCode = state.gfx.videoRam[ty][tx]
      let colorCode = state.gfx.colorRam[ty][tx] and 0x1F
      gfxAddTileVertices(tx.uint32, ty.uint32, tileCode, colorCode)

proc gfxAddDebugmarkerVertices() =
  for i in 0..<NUM_DEBUG_MARKERS:
    let dbg = state.gfx.debugMarker[i]
    if dbg.enabled:
      gfxAddTileVertices(dbg.tilePos.x.uint32, dbg.tilePos.y.uint32,
                         dbg.tile, dbg.color)

proc gfxAddSpriteVertices() =
  const dx = 1.0f / DISPLAY_PIXELS_X.float32
  const dy = 1.0f / DISPLAY_PIXELS_Y.float32
  const du = SPRITE_WIDTH.float32 / TILE_TEXTURE_WIDTH.float32
  const dv = SPRITE_HEIGHT.float32 / TILE_TEXTURE_HEIGHT.float32
  for i in 0..<NUM_SPRITES:
    let spr = state.gfx.sprite[i]
    if spr.enabled:
      var x0, x1, y0, y1: float32
      if spr.flipx:
        x1 = spr.pos.x.float32 * dx
        x0 = x1 + dx * SPRITE_WIDTH.float32
      else:
        x0 = spr.pos.x.float32 * dx
        x1 = x0 + dx * SPRITE_WIDTH.float32
      if spr.flipy:
        y1 = spr.pos.y.float32 * dy
        y0 = y1 + dy * SPRITE_HEIGHT.float32
      else:
        y0 = spr.pos.y.float32 * dy
        y1 = y0 + dy * SPRITE_HEIGHT.float32
      let u0 = spr.tile.float32 * du
      let u1 = u0 + du
      let v0 = TILE_HEIGHT.float32 / TILE_TEXTURE_HEIGHT.float32
      let v1 = v0 + dv
      let color = spr.color
      gfxAddVertex(x0, y0, u0, v0, color, 0xFF)
      gfxAddVertex(x1, y0, u1, v0, color, 0xFF)
      gfxAddVertex(x1, y1, u1, v1, color, 0xFF)
      gfxAddVertex(x0, y0, u0, v0, color, 0xFF)
      gfxAddVertex(x1, y1, u1, v1, color, 0xFF)
      gfxAddVertex(x0, y1, u0, v1, color, 0xFF)

proc gfxAddFadeVertices() =
  const du = SPRITE_WIDTH.float32 / TILE_TEXTURE_WIDTH.float32
  const dv = SPRITE_HEIGHT.float32 / TILE_TEXTURE_HEIGHT.float32
  let u0 = 64.float32 * du
  let u1 = u0 + du
  let v0 = TILE_HEIGHT.float32 / TILE_TEXTURE_HEIGHT.float32
  let v1 = v0 + dv
  let fade = state.gfx.fade
  gfxAddVertex(0.0f, 0.0f, u0, v0, 0, fade)
  gfxAddVertex(1.0f, 0.0f, u1, v0, 0, fade)
  gfxAddVertex(1.0f, 1.0f, u1, v1, 0, fade)
  gfxAddVertex(0.0f, 0.0f, u0, v0, 0, fade)
  gfxAddVertex(1.0f, 1.0f, u1, v1, 0, fade)
  gfxAddVertex(0.0f, 1.0f, u0, v1, 0, fade)

proc gfxAdjustViewport(canvasWidth, canvasHeight: int32) =
  const playfieldAspect = DISPLAY_TILES_X.float32 / DISPLAY_TILES_Y.float32
  const border = 10'i32
  let vp = slbx.letterbox(canvasWidth, canvasHeight, slbx.LetterboxDesc(
    contentAspectRatio: playfieldAspect,
    border: slbx.Border(left: border, right: border,
                        top: border, bottom: border)))
  sg.applyViewport(vp.x, vp.y, vp.width, vp.height, true)

proc gfxFade() =
  if between(state.gfx.fadein, 0, FADE_TICKS):
    let t = since(state.gfx.fadein).float32 / FADE_TICKS.float32
    state.gfx.fade = (255.0f * (1.0f - t)).uint8
  if afterOnce(state.gfx.fadein, FADE_TICKS):
    state.gfx.fade = 0
  if between(state.gfx.fadeout, 0, FADE_TICKS):
    let t = since(state.gfx.fadeout).float32 / FADE_TICKS.float32
    state.gfx.fade = (255.0f * t).uint8
  if afterOnce(state.gfx.fadeout, FADE_TICKS):
    state.gfx.fade = 255

proc gfxDraw*() =
  gfxFade()
  state.gfx.numVertices = 0
  gfxAddPlayfieldVertices()
  gfxAddSpriteVertices()
  gfxAddDebugmarkerVertices()
  if state.gfx.fade > 0:
    gfxAddFadeVertices()
  assert(state.gfx.numVertices <= MAX_VERTICES)
  sg.writeBufferTransient(sg.WriteBufferDesc(
    dst: sg.BufferLocation(buffer: state.gfx.offscreenVbuf),
    src: sg.WriteBufferSource(
      data: sg.Range(addr: addr state.gfx.vertices[0],
                     size: state.gfx.numVertices.int * sizeof(Vertex))),
    size: state.gfx.numVertices.int * sizeof(Vertex)))

  # render tiles and sprites into the offscreen render target
  sg.beginPass(state.gfx.offscreenPass)
  sg.applyPipeline(state.gfx.offscreenPip)
  sg.applyBindings(sg.Bindings(
    vertexBuffers: [state.gfx.offscreenVbuf],
    views: [state.gfx.tilerom.texView, state.gfx.palette.texView],
    samplers: [state.gfx.nearestSmp, state.gfx.nearestSmp]))
  sg.draw(0, state.gfx.numVertices, 1)
  sg.endPass()

  # upscale-render the offscreen target into the display framebuffer
  sg.beginPass(sg.Pass(action: state.gfx.displayPassAction,
                       swapchain: sglue.swapchain()))
  gfxAdjustViewport(sapp.width(), sapp.height())
  sg.applyPipeline(state.gfx.displayPip)
  sg.applyBindings(sg.Bindings(
    vertexBuffers: [state.gfx.displayQuadVbuf],
    views: [state.gfx.render.texView],
    samplers: [state.gfx.linearSmp]))
  sg.draw(0, 4, 1)
  sg.endPass()
  sg.commit()
