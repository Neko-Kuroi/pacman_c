# ghost.nim -- ghost speed, state machine, target selection and steering.
# Corresponds to pacman.c lines 1750-2087.

import pacstate
import timing
import geom

proc ghostSpeed*(ghost: Ghost): int =
  case ghost.state
  of GHOSTSTATE_HOUSE, GHOSTSTATE_LEAVEHOUSE, GHOSTSTATE_FRIGHTENED:
    # inside house / frightened: half speed
    (state.timing.tick and 1).int
  of GHOSTSTATE_EYES, GHOSTSTATE_ENTERHOUSE:
    # estimated 1.5x in eye state
    if (state.timing.tick and 1) != 0: 1 else: 2
  else:
    if isTunnel(pixelToTilePos(ghost.actor.pos)):
      if ((state.timing.tick * 2) mod 4) != 0: 1 else: 0
    else:
      if (state.timing.tick mod 7) != 0: 1 else: 0

# return the current global scatter or chase phase
proc scatterChasePhase*(): GhostState =
  let t = since(state.game.roundStarted)
  if t < 7 * 60: GHOSTSTATE_SCATTER
  elif t < 27 * 60: GHOSTSTATE_CHASE
  elif t < 34 * 60: GHOSTSTATE_SCATTER
  elif t < 54 * 60: GHOSTSTATE_CHASE
  elif t < 59 * 60: GHOSTSTATE_SCATTER
  elif t < 79 * 60: GHOSTSTATE_CHASE
  elif t < 84 * 60: GHOSTSTATE_SCATTER
  else: GHOSTSTATE_CHASE

# takes care of switching a ghost into a new state
proc updateGhostState*(ghost: var Ghost) =
  var newState = ghost.state
  case ghost.state
  of GHOSTSTATE_EYES:
    if nearequal(ghost.actor.pos, i2(ANTEPORTAS_X, ANTEPORTAS_Y), 1):
      newState = GHOSTSTATE_ENTERHOUSE
  of GHOSTSTATE_ENTERHOUSE:
    if nearequal(ghost.actor.pos, ghostHouseTargetPos[ord(ghost.typ)], 1):
      newState = GHOSTSTATE_LEAVEHOUSE
  of GHOSTSTATE_HOUSE:
    if afterOnce(state.game.forceLeaveHouse, 4 * 60):
      newState = GHOSTSTATE_LEAVEHOUSE
      start(state.game.forceLeaveHouse)
    elif state.game.globalDotCounterActive:
      if ghost.typ == GHOSTTYPE_PINKY and state.game.globalDotCounter == 7:
        newState = GHOSTSTATE_LEAVEHOUSE
      elif ghost.typ == GHOSTTYPE_INKY and state.game.globalDotCounter == 17:
        newState = GHOSTSTATE_LEAVEHOUSE
      elif ghost.typ == GHOSTTYPE_CLYDE and state.game.globalDotCounter == 32:
        newState = GHOSTSTATE_LEAVEHOUSE
        # the global dot counter is deactivated when Clyde leaves at 32
        state.game.globalDotCounterActive = false
    elif ghost.dotCounter == ghost.dotLimit:
      newState = GHOSTSTATE_LEAVEHOUSE
  of GHOSTSTATE_LEAVEHOUSE:
    if ghost.actor.pos.y == ANTEPORTAS_Y:
      newState = GHOSTSTATE_SCATTER
  else:
    if before(ghost.frightened, levelspec(state.game.round.int).frightTicks.uint32):
      newState = GHOSTSTATE_FRIGHTENED
    else:
      newState = scatterChasePhase()
  # handle state transitions
  if newState != ghost.state:
    case ghost.state
    of GHOSTSTATE_LEAVEHOUSE:
      ghost.nextDir = DIR_LEFT
      ghost.actor.dir = DIR_LEFT
    of GHOSTSTATE_ENTERHOUSE:
      # a ghost that was eaten is immune to frighten until the next pill
      disable(ghost.frightened)
    of GHOSTSTATE_FRIGHTENED:
      discard # don't reverse direction when leaving frightened state
    of GHOSTSTATE_SCATTER, GHOSTSTATE_CHASE:
      # any transition from scatter/chase causes a reversal of direction
      ghost.nextDir = reverseDir(ghost.actor.dir)
    else:
      discard
    ghost.state = newState

# update the ghost's target position
proc updateGhostTarget*(ghost: var Ghost) =
  var pos = ghost.targetPos
  case ghost.state
  of GHOSTSTATE_SCATTER:
    pos = ghostScatterTargets[ord(ghost.typ)]
  of GHOSTSTATE_CHASE:
    let pm = state.game.pacman.actor
    let pmPos = pixelToTilePos(pm.pos)
    let pmDir = dirToVec(pm.dir)
    case ghost.typ
    of GHOSTTYPE_BLINKY:
      pos = pmPos
    of GHOSTTYPE_PINKY:
      # 4 tiles ahead of Pacman (without the arcade 'diagonal overflow')
      pos = pmPos + pmDir * 4
    of GHOSTTYPE_INKY:
      let blinkyPos = pixelToTilePos(state.game.ghost[ord(GHOSTTYPE_BLINKY)].actor.pos)
      let p = pmPos + pmDir * 2
      let d = p - blinkyPos
      pos = blinkyPos + d * 2
    of GHOSTTYPE_CLYDE:
      if squaredDistance(pixelToTilePos(ghost.actor.pos), pmPos) > 64:
        pos = pmPos
      else:
        pos = ghostScatterTargets[ord(GHOSTTYPE_CLYDE)]
    else:
      discard
  of GHOSTSTATE_FRIGHTENED:
    # random target position (random direction at each intersection)
    pos = i2((xorshift32() mod DISPLAY_TILES_X).int16,
             (xorshift32() mod DISPLAY_TILES_Y).int16)
  of GHOSTSTATE_EYES:
    pos = i2(13, 14)
  else:
    discard
  ghost.targetPos = pos

# compute the next ghost direction; returns true if the resulting movement
# should always happen (movement inside the ghost house)
proc updateGhostDir*(ghost: var Ghost): bool =
  if ghost.state == GHOSTSTATE_HOUSE:
    if ghost.actor.pos.y <= 17 * TILE_HEIGHT:
      ghost.nextDir = DIR_DOWN
    elif ghost.actor.pos.y >= 18 * TILE_HEIGHT:
      ghost.nextDir = DIR_UP
    ghost.actor.dir = ghost.nextDir
    return true
  elif ghost.state == GHOSTSTATE_LEAVEHOUSE:
    let pos = ghost.actor.pos
    if pos.x == ANTEPORTAS_X:
      if pos.y > ANTEPORTAS_Y:
        ghost.nextDir = DIR_UP
    else:
      const midY = 17 * TILE_HEIGHT + TILE_HEIGHT div 2
      if pos.y > midY:
        ghost.nextDir = DIR_UP
      elif pos.y < midY:
        ghost.nextDir = DIR_DOWN
      else:
        ghost.nextDir = if pos.x > ANTEPORTAS_X: DIR_LEFT else: DIR_RIGHT
    ghost.actor.dir = ghost.nextDir
    return true
  elif ghost.state == GHOSTSTATE_ENTERHOUSE:
    let pos = ghost.actor.pos
    let tilePos = pixelToTilePos(pos)
    let tgtPos = ghostHouseTargetPos[ord(ghost.typ)]
    if tilePos.y == 14:
      if pos.x != ANTEPORTAS_X:
        ghost.nextDir = if pos.x < ANTEPORTAS_X: DIR_RIGHT else: DIR_LEFT
      else:
        ghost.nextDir = DIR_DOWN
    elif pos.y == tgtPos.y:
      ghost.nextDir = if pos.x < tgtPos.x: DIR_RIGHT else: DIR_LEFT
    ghost.actor.dir = ghost.nextDir
    return true
  else:
    # scatter/chase/frightened: head towards the current target point
    let distToMid = distToTileMid(ghost.actor.pos)
    if distToMid.x == 0 and distToMid.y == 0:
      ghost.actor.dir = ghost.nextDir
      let dirVec = dirToVec(ghost.actor.dir)
      let lookaheadPos = pixelToTilePos(ghost.actor.pos) + dirVec
      const dirs = [DIR_UP, DIR_LEFT, DIR_DOWN, DIR_RIGHT]
      var minDist = 100000'i32
      for dir in dirs:
        # in the two 'red zones', upward movement is forbidden (except eyes)
        if isRedzone(lookaheadPos) and dir == DIR_UP and
           ghost.state != GHOSTSTATE_EYES:
          continue
        let revdir = reverseDir(dir)
        let testPos = clampedTilePos(lookaheadPos + dirToVec(dir))
        if revdir != ghost.actor.dir and not isBlockingTile(testPos):
          let dist = squaredDistance(testPos, ghost.targetPos)
          if dist < minDist:
            minDist = dist
            ghost.nextDir = dir
    return false

# update the dot counters used to decide whether ghosts must leave the house
# (called each time Pacman eats a dot)
proc updateGhosthouseDotCounters*() =
  if state.game.globalDotCounterActive:
    state.game.globalDotCounter += 1
  else:
    for i in 0..<state.game.ghost.len:
      if state.game.ghost[i].dotCounter < state.game.ghost[i].dotLimit:
        state.game.ghost[i].dotCounter += 1
        break
