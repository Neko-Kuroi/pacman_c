# state.nim -- constants, types and the single global state object.
# Corresponds to pacman.c lines 142-678 (config, enums, structs, data tables).
# Inside this module the writing follows Nim conventions where the C code's
# intent allows it (e.g. freeze flags are a Nim set, not a uint32 bitfield).

import sokol/gfx as sg

# --- config (pacman.c 144-152) ---
const AUDIO_VOLUME* = 0.5f

# --- global constants (pacman.c 161-193) ---
const TICK_DURATION_NS* = 16_666_666
const TICK_TOLERANCE_NS* = 1_000_000
const NUM_VOICES* = 3
const NUM_SOUNDS* = 3
const NUM_SAMPLES* = 128
const DISABLED_TICKS* = 0xFFFFFFFF'u32
const TILE_WIDTH* = 8
const TILE_HEIGHT* = 8
const SPRITE_WIDTH* = 16
const SPRITE_HEIGHT* = 16
const DISPLAY_TILES_X* = 28
const DISPLAY_TILES_Y* = 36
const DISPLAY_PIXELS_X* = DISPLAY_TILES_X * TILE_WIDTH
const DISPLAY_PIXELS_Y* = DISPLAY_TILES_Y * TILE_HEIGHT
const NUM_SPRITES* = 8
const NUM_DEBUG_MARKERS* = 16
const TILE_TEXTURE_WIDTH* = 256 * TILE_WIDTH
const TILE_TEXTURE_HEIGHT* = TILE_HEIGHT + SPRITE_HEIGHT
const MAX_VERTICES* = ((DISPLAY_TILES_X * DISPLAY_TILES_Y) + NUM_SPRITES + NUM_DEBUG_MARKERS) * 6
const FADE_TICKS* = 30
const NUM_LIVES* = 3
const NUM_STATUS_FRUITS* = 7
const NUM_DOTS* = 244
const NUM_PILLS* = 4
const ANTEPORTAS_X* = 14 * TILE_WIDTH
const ANTEPORTAS_Y* = 14 * TILE_HEIGHT + TILE_HEIGHT div 2
const GHOST_EATEN_FREEZE_TICKS* = 60
const PACMAN_EATEN_TICKS* = 60
const PACMAN_DEATH_TICKS* = 150
const GAMEOVER_TICKS* = 3 * 60
const ROUNDWON_TICKS* = 4 * 60
const FRUITACTIVE_TICKS* = 10 * 60

# --- tile, sprite and color codes (pacman.c 198-248) ---
const TILE_SPACE* = 0x40'u8
const TILE_DOT* = 0x10'u8
const TILE_PILL* = 0x14'u8
const TILE_GHOST* = 0xB0'u8
const TILE_LIFE* = 0x20'u8
const TILE_CHERRIES* = 0x90'u8
const TILE_STRAWBERRY* = 0x94'u8
const TILE_PEACH* = 0x98'u8
const TILE_BELL* = 0x9C'u8
const TILE_APPLE* = 0xA0'u8
const TILE_GRAPES* = 0xA4'u8
const TILE_GALAXIAN* = 0xA8'u8
const TILE_KEY* = 0xAC'u8
const TILE_DOOR* = 0xCF'u8

const SPRITETILE_INVISIBLE* = 30'u8
const SPRITETILE_SCORE_200* = 40'u8
const SPRITETILE_SCORE_400* = 41'u8
const SPRITETILE_SCORE_800* = 42'u8
const SPRITETILE_SCORE_1600* = 43'u8
const SPRITETILE_CHERRIES* = 0'u8
const SPRITETILE_STRAWBERRY* = 1'u8
const SPRITETILE_PEACH* = 2'u8
const SPRITETILE_BELL* = 3'u8
const SPRITETILE_APPLE* = 4'u8
const SPRITETILE_GRAPES* = 5'u8
const SPRITETILE_GALAXIAN* = 6'u8
const SPRITETILE_KEY* = 7'u8
const SPRITETILE_PACMAN_CLOSED_MOUTH* = 48'u8

const COLOR_BLANK* = 0x00'u8
const COLOR_DEFAULT* = 0x0F'u8
const COLOR_DOT* = 0x10'u8
const COLOR_PACMAN* = 0x09'u8
const COLOR_BLINKY* = 0x01'u8
const COLOR_PINKY* = 0x03'u8
const COLOR_INKY* = 0x05'u8
const COLOR_CLYDE* = 0x07'u8
const COLOR_FRIGHTENED* = 0x11'u8
const COLOR_FRIGHTENED_BLINKING* = 0x12'u8
const COLOR_GHOST_SCORE* = 0x18'u8
const COLOR_EYES* = 0x19'u8
const COLOR_CHERRIES* = 0x14'u8
const COLOR_STRAWBERRY* = 0x0F'u8
const COLOR_PEACH* = 0x15'u8
const COLOR_BELL* = 0x16'u8
const COLOR_APPLE* = 0x14'u8
const COLOR_GRAPES* = 0x17'u8
const COLOR_GALAXIAN* = 0x09'u8
const COLOR_KEY* = 0x16'u8
const COLOR_WHITE_BORDER* = 0x1F'u8
const COLOR_FRUIT_SCORE* = 0x03'u8

# --- enums (pacman.c 254-320) ---
type GameState* = enum
  GAMESTATE_INTRO, GAMESTATE_GAME

# NOTE: bit0==0: horizontal movement, bit0==1: vertical movement
type Dir* = enum
  DIR_RIGHT, DIR_DOWN, DIR_LEFT, DIR_UP, NUM_DIRS

type Fruit* = enum
  FRUIT_NONE, FRUIT_CHERRIES, FRUIT_STRAWBERRY, FRUIT_PEACH, FRUIT_APPLE,
  FRUIT_GRAPES, FRUIT_GALAXIAN, FRUIT_BELL, FRUIT_KEY, NUM_FRUITS

type SpriteIndex* = enum
  SPRITE_PACMAN, SPRITE_BLINKY, SPRITE_PINKY, SPRITE_INKY, SPRITE_CLYDE,
  SPRITE_FRUIT

type GhostType* = enum
  GHOSTTYPE_BLINKY, GHOSTTYPE_PINKY, GHOSTTYPE_INKY, GHOSTTYPE_CLYDE,
  NUM_GHOSTS

type GhostState* = enum
  GHOSTSTATE_NONE, GHOSTSTATE_CHASE, GHOSTSTATE_SCATTER,
  GHOSTSTATE_FRIGHTENED, GHOSTSTATE_EYES, GHOSTSTATE_HOUSE,
  GHOSTSTATE_LEAVEHOUSE, GHOSTSTATE_ENTERHOUSE

# In C these are (1<<n) bit values in a uint8. In Nim they are the members
# of a set, so the enum ordinals are the bit positions.
type FreezeType* = enum
  FREEZETYPE_PRELUDE, FREEZETYPE_READY, FREEZETYPE_EAT_GHOST,
  FREEZETYPE_DEAD, FREEZETYPE_WON

type SoundFlag* = enum
  SOUNDFLAG_VOICE0, SOUNDFLAG_VOICE1, SOUNDFLAG_VOICE2

const SOUNDFLAG_ALL_VOICES* = {SOUNDFLAG_VOICE0, SOUNDFLAG_VOICE1, SOUNDFLAG_VOICE2}

# --- basic types (pacman.c 323-352) ---
type Trigger* = object
  tick*: uint32

type Int2* = object
  x*: int16
  y*: int16

proc i2*(x, y: int16): Int2 = Int2(x: x, y: y)
proc `+`*(v0, v1: Int2): Int2 = i2(v0.x + v1.x, v0.y + v1.y)
proc `-`*(v0, v1: Int2): Int2 = i2(v0.x - v1.x, v0.y - v1.y)
proc `*`*(v: Int2, s: int16): Int2 = i2(v.x * s, v.y * s)
proc squaredDistance*(v0, v1: Int2): int32 =
  let dx = int32(v1.x - v0.x)
  let dy = int32(v1.y - v0.y)
  dx * dx + dy * dy
proc nearequal*(v0, v1: Int2, tolerance: int16): bool =
  abs(v1.x - v0.x) <= tolerance and abs(v1.y - v0.y) <= tolerance
proc actorToSpritePos*(pos: Int2): Int2 =
  i2(pos.x - SPRITE_WIDTH div 2, pos.y - SPRITE_HEIGHT div 2)

type Actor* = object
  dir*: Dir
  pos*: Int2
  animTick*: uint32

type Ghost* = object
  actor*: Actor
  typ*: GhostType
  nextDir*: Dir
  targetPos*: Int2
  state*: GhostState
  frightened*: Trigger
  eaten*: Trigger
  dotCounter*: uint16
  dotLimit*: uint16

type Pacman* = object
  actor*: Actor

# --- renderer types (pacman.c 360-385) ---
type Vertex* = object
  x*, y*: float32
  u*, v*: float32
  attr*: uint32

type Sprite* = object
  enabled*: bool
  tile*, color*: uint8
  flipx*, flipy*: bool
  pos*: Int2

type DebugMarker* = object
  enabled*: bool
  tile*, color*: uint8
  tilePos*: Int2

# --- sound types (pacman.c 388-418) ---
type SoundFunc* = proc(slot: int32) {.nimcall.}

type SoundDesc* = object
  fn*: SoundFunc
  data*: ptr UncheckedArray[uint32]  # register dump data (nil for procedural sounds)
  size*: uint32          # byte size of register dump data
  voice*: array[3, bool]

type Voice* = object
  counter*: uint32
  frequency*: uint32
  waveform*: uint8
  volume*: uint8
  sampleAcc*: float32
  sampleDiv*: float32

type Sound* = object
  curTick*: uint32
  fn*: SoundFunc
  numTicks*: uint32
  stride*: uint32
  data*: ptr UncheckedArray[uint32]
  flags*: set[SoundFlag]

# --- the global state (pacman.c 420-540) ---
type TimingState* = object
  tick*: uint32
  laptimeStore*: uint64
  tickAccum*: int32

type IntroState* = object
  started*: Trigger

type Game* = object
  xorshift*: uint32
  hiscore*: uint32
  started*: Trigger
  readyStarted*: Trigger
  roundStarted*: Trigger
  roundWon*: Trigger
  gameOver*: Trigger
  dotEaten*: Trigger
  pillEaten*: Trigger
  ghostEaten*: Trigger
  pacmanEaten*: Trigger
  fruitEaten*: Trigger
  forceLeaveHouse*: Trigger
  fruitActive*: Trigger
  freeze*: set[FreezeType]
  round*: uint8
  score*: uint32
  numLives*: int8
  numGhostsEaten*: uint8
  numDotsEaten*: uint8
  globalDotCounterActive*: bool
  globalDotCounter*: uint8
  ghost*: array[4, Ghost]
  pacman*: Pacman
  activeFruit*: Fruit

type InputState* = object
  enabled*: bool
  up*, down*, left*, right*: bool
  esc*: bool
  anykey*: bool

type AudioState* = object
  voice*: array[NUM_VOICES, Voice]
  sound*: array[NUM_SOUNDS, Sound]
  voiceTickAccum*: int32
  voiceTickPeriod*: int32
  sampleDurationNs*: int32
  sampleAccum*: int32
  numSamples*: uint32
  sampleBuffer*: array[NUM_SAMPLES, float32]

type GfxResources = object
  img*: sg.Image
  texView*: sg.View

type GfxState* = object
  fadein*: Trigger
  fadeout*: Trigger
  fade*: uint8
  videoRam*: array[DISPLAY_TILES_Y, array[DISPLAY_TILES_X, uint8]]
  colorRam*: array[DISPLAY_TILES_Y, array[DISPLAY_TILES_X, uint8]]
  sprite*: array[NUM_SPRITES, Sprite]
  debugMarker*: array[NUM_DEBUG_MARKERS, DebugMarker]
  tilerom*: GfxResources
  palette*: GfxResources
  render*: GfxResources
  linearSmp*: sg.Sampler
  nearestSmp*: sg.Sampler
  offscreenPass*: sg.Pass
  offscreenVbuf*: sg.Buffer
  offscreenPip*: sg.Pipeline
  displayPassAction*: sg.PassAction
  displayQuadVbuf*: sg.Buffer
  displayPip*: sg.Pipeline
  numVertices*: int32
  vertices*: array[MAX_VERTICES, Vertex]
  tilePixels*: array[TILE_TEXTURE_HEIGHT, array[TILE_TEXTURE_WIDTH, uint8]]
  colorPalette*: array[256, uint32]

type State* = object
  gamestate*: GameState
  timing*: TimingState
  intro*: IntroState
  game*: Game
  input*: InputState
  audio*: AudioState
  gfx*: GfxState

var state*: State

# --- data tables (pacman.c 542-623) ---
const ghostScatterTargets*: array[4, Int2] = [
  i2(25, 0), i2(2, 0), i2(27, 34), i2(0, 34)]

# starting positions for ghosts (pixel coords), pacman.c 548-553
const ghostStartingPos*: array[4, Int2] = [
  i2(14 * 8, 14 * 8 + 4), i2(14 * 8, 17 * 8 + 4),
  i2(12 * 8, 17 * 8 + 4), i2(16 * 8, 17 * 8 + 4)]

# target positions for ghosts entering the ghost house, pacman.c 556-561
const ghostHouseTargetPos*: array[4, Int2] = [
  i2(14 * 8, 17 * 8 + 4), i2(14 * 8, 17 * 8 + 4),
  i2(12 * 8, 17 * 8 + 4), i2(16 * 8, 17 * 8 + 4)]

const fruitTilesColors*: array[9, array[3, uint8]] = [
  [0'u8, 0, 0],
  [TILE_CHERRIES, SPRITETILE_CHERRIES, COLOR_CHERRIES],
  [TILE_STRAWBERRY, SPRITETILE_STRAWBERRY, COLOR_STRAWBERRY],
  [TILE_PEACH, SPRITETILE_PEACH, COLOR_PEACH],
  [TILE_APPLE, SPRITETILE_APPLE, COLOR_APPLE],
  [TILE_GRAPES, SPRITETILE_GRAPES, COLOR_GRAPES],
  [TILE_GALAXIAN, SPRITETILE_GALAXIAN, COLOR_GALAXIAN],
  [TILE_BELL, SPRITETILE_BELL, COLOR_BELL],
  [TILE_KEY, SPRITETILE_KEY, COLOR_KEY]]

const fruitScoreTiles*: array[9, array[4, uint8]] = [
  [0x40'u8, 0x40, 0x40, 0x40],
  [0x40'u8, 0x81, 0x85, 0x40],
  [0x40'u8, 0x82, 0x85, 0x40],
  [0x40'u8, 0x83, 0x85, 0x40],
  [0x40'u8, 0x84, 0x85, 0x40],
  [0x40'u8, 0x86, 0x8D, 0x8E],
  [0x87'u8, 0x88, 0x8D, 0x8E],
  [0x89'u8, 0x8A, 0x8D, 0x8E],
  [0x8B'u8, 0x8C, 0x8D, 0x8E]]

type LevelSpec* = object
  bonusFruit*: Fruit
  bonusScore*: uint16
  frightTicks*: uint16

const MAX_LEVELSPEC* = 21
const levelspecTable*: array[MAX_LEVELSPEC, LevelSpec] = [
  LevelSpec(bonusFruit: FRUIT_CHERRIES, bonusScore: 10, frightTicks: 6 * 60),
  LevelSpec(bonusFruit: FRUIT_STRAWBERRY, bonusScore: 30, frightTicks: 5 * 60),
  LevelSpec(bonusFruit: FRUIT_PEACH, bonusScore: 50, frightTicks: 4 * 60),
  LevelSpec(bonusFruit: FRUIT_PEACH, bonusScore: 50, frightTicks: 3 * 60),
  LevelSpec(bonusFruit: FRUIT_APPLE, bonusScore: 70, frightTicks: 2 * 60),
  LevelSpec(bonusFruit: FRUIT_APPLE, bonusScore: 70, frightTicks: 5 * 60),
  LevelSpec(bonusFruit: FRUIT_GRAPES, bonusScore: 100, frightTicks: 2 * 60),
  LevelSpec(bonusFruit: FRUIT_GRAPES, bonusScore: 100, frightTicks: 2 * 60),
  LevelSpec(bonusFruit: FRUIT_GALAXIAN, bonusScore: 200, frightTicks: 1 * 60),
  LevelSpec(bonusFruit: FRUIT_GALAXIAN, bonusScore: 200, frightTicks: 5 * 60),
  LevelSpec(bonusFruit: FRUIT_BELL, bonusScore: 300, frightTicks: 2 * 60),
  LevelSpec(bonusFruit: FRUIT_BELL, bonusScore: 300, frightTicks: 1 * 60),
  LevelSpec(bonusFruit: FRUIT_KEY, bonusScore: 500, frightTicks: 1 * 60),
  LevelSpec(bonusFruit: FRUIT_KEY, bonusScore: 500, frightTicks: 3 * 60),
  LevelSpec(bonusFruit: FRUIT_KEY, bonusScore: 500, frightTicks: 1 * 60),
  LevelSpec(bonusFruit: FRUIT_KEY, bonusScore: 500, frightTicks: 1 * 60),
  LevelSpec(bonusFruit: FRUIT_KEY, bonusScore: 500, frightTicks: 1),
  LevelSpec(bonusFruit: FRUIT_KEY, bonusScore: 500, frightTicks: 1 * 60),
  LevelSpec(bonusFruit: FRUIT_KEY, bonusScore: 500, frightTicks: 1),
  LevelSpec(bonusFruit: FRUIT_KEY, bonusScore: 500, frightTicks: 1),
  LevelSpec(bonusFruit: FRUIT_KEY, bonusScore: 500, frightTicks: 1)]

proc levelspec*(round: int): LevelSpec =
  assert(round >= 0)
  let r = min(round, MAX_LEVELSPEC - 1)
  levelspecTable[r]
