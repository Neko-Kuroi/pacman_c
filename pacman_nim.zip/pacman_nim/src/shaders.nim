# shaders.nim -- shader sources extracted mechanically from pacman.c
# gfx_create_resources (lines 2438-2640). Do not edit by hand.

import sokol/gfx as sg

type ShaderSources* = object
  offscreenVs*, offscreenFs*, displayVs*, displayFs*: string

proc shaderSources*(backend: sg.Backend): ShaderSources =
  case backend
  of sg.backendMetalMacos:
    ShaderSources(
      offscreenVs: """#include <metal_stdlib>
using namespace metal;
struct vs_in {
  float4 pos [[attribute(0)]];
  float2 uv [[attribute(1)]];
  float4 data [[attribute(2)]];
};
struct vs_out {
  float4 pos [[position]];
  float2 uv;
  float4 data;
};
vertex vs_out _main(vs_in in [[stage_in]]) {
  vs_out out;
  out.pos = float4((in.pos.xy - 0.5) * float2(2.0, -2.0), 0.5, 1.0);
  out.uv  = in.uv;  out.data = in.data;
  return out;
}
""",
      offscreenFs: """#include <metal_stdlib>
using namespace metal;
struct ps_in {
  float2 uv;
  float4 data;
};
fragment float4 _main(ps_in in [[stage_in]],
                      texture2d<float> tile_tex [[texture(0)]],
                      texture2d<float> pal_tex [[texture(1)]],
                      sampler tile_smp [[sampler(0)]],
                      sampler pal_smp [[sampler(1)]])
{
  float color_code = in.data.x;
  float tile_color = tile_tex.sample(tile_smp, in.uv).x;
  float2 pal_uv = float2(color_code * 4 + tile_color, 0);
  float4 color = pal_tex.sample(pal_smp, pal_uv) * float4(1, 1, 1, in.data.y);
  return color;
}
""",
      displayVs: """#include <metal_stdlib>
using namespace metal;
struct vs_in {
  float4 pos [[attribute(0)]];
};
struct vs_out {
  float4 pos [[position]];
  float2 uv;
};
vertex vs_out _main(vs_in in[[stage_in]]) {
  vs_out out;
  out.pos = float4((in.pos.xy - 0.5) * float2(2.0, -2.0), 0.0, 1.0);
  out.uv = in.pos.xy;
  return out;
}
""",
      displayFs: """#include <metal_stdlib>
using namespace metal;
struct ps_in {
  float2 uv;
};
fragment float4 _main(ps_in in [[stage_in]],
                      texture2d<float> tex [[texture(0)]],
                      sampler smp [[sampler(0)]])
{
  return tex.sample(smp, in.uv);
}
""",
    )
  of sg.backendD3d11:
    ShaderSources(
      offscreenVs: """struct vs_in {
  float4 pos: POSITION;
  float2 uv: TEXCOORD0;
  float4 data: TEXCOORD1;
};
struct vs_out {
  float2 uv: UV;
  float4 data: DATA;
  float4 pos: SV_Position;
};
vs_out main(vs_in inp) {
  vs_out outp;  outp.pos = float4(inp.pos.xy * float2(2.0, -2.0) + float2(-1.0, 1.0), 0.0, 1.0);
  outp.uv  = inp.uv;  outp.data = inp.data;
  return outp;
}
""",
      offscreenFs: """Texture2D<float4> tile_tex: register(t0);
Texture2D<float4> pal_tex: register(t1);
sampler tile_smp: register(s0);
sampler pal_smp: register(s1);
float4 main(float2 uv: UV, float4 data: DATA): SV_Target0 {
  float color_code = data.x;
  float tile_color = tile_tex.Sample(tile_smp, uv).x;
  float2 pal_uv = float2(color_code * 4 + tile_color, 0);
  float4 color = pal_tex.Sample(pal_smp, pal_uv) * float4(1, 1, 1, data.y);
  return color;
}
""",
      displayVs: """struct vs_out {
  float2 uv: UV;
  float4 pos: SV_Position;
};
vs_out main(float4 pos: POSITION) {
  vs_out outp;
  outp.pos = float4((pos.xy - 0.5) * float2(2.0, -2.0), 0.0, 1.0);
  outp.uv = pos.xy;
  return outp;
}
""",
      displayFs: """Texture2D<float4> tex: register(t0);
sampler smp: register(s0);
float4 main(float2 uv: UV): SV_Target0 {
  return tex.Sample(smp, uv);
}
""",
    )
  of sg.backendGlcore:
    ShaderSources(
      offscreenVs: """#version 410
layout(location=0) in vec4 pos;
layout(location=1) in vec2 uv_in;
layout(location=2) in vec4 data_in;
out vec2 uv;
out vec4 data;
void main() {
  gl_Position = vec4((pos.xy - 0.5) * vec2(2.0, -2.0), 0.5, 1.0);
  uv  = uv_in;  data = data_in;
}
""",
      offscreenFs: """#version 410
uniform sampler2D tile_tex;
uniform sampler2D pal_tex;
in vec2 uv;
in vec4 data;
out vec4 frag_color;
void main() {
  float color_code = data.x;
  float tile_color = texture(tile_tex, uv).x;
  vec2 pal_uv = vec2(color_code * 4 + tile_color, 0);
  frag_color = texture(pal_tex, pal_uv) * vec4(1, 1, 1, data.y);
}
""",
      displayVs: """#version 410
layout(location=0) in vec4 pos;
out vec2 uv;
void main() {
  gl_Position = vec4((pos.xy - 0.5) * 2.0, 0.0, 1.0);
  uv = pos.xy;
}
""",
      displayFs: """#version 410
uniform sampler2D tex;
in vec2 uv;
out vec4 frag_color;
void main() {
  frag_color = texture(tex, uv);
}
""",
    )
  of sg.backendGles3:
    ShaderSources(
      offscreenVs: """attribute vec4 pos;
attribute vec2 uv_in;
attribute vec4 data_in;
varying vec2 uv;
varying vec4 data;
void main() {
  gl_Position = vec4((pos.xy - 0.5) * vec2(2.0, -2.0), 0.5, 1.0);
  uv  = uv_in;  data = data_in;
}
""",
      offscreenFs: """precision mediump float;
uniform sampler2D tile_tex;
uniform sampler2D pal_tex;
varying vec2 uv;
varying vec4 data;
void main() {
  float color_code = data.x;
  float tile_color = texture2D(tile_tex, uv).x;
  vec2 pal_uv = vec2(color_code * 4.0 + tile_color, 0.0);
  gl_FragColor = texture2D(pal_tex, pal_uv) * vec4(1.0, 1.0, 1.0, data.y);
}
""",
      displayVs: """attribute vec4 pos;
varying vec2 uv;
void main() {
  gl_Position = vec4((pos.xy - 0.5) * 2.0, 0.0, 1.0);
  uv = pos.xy;
}
""",
      displayFs: """precision mediump float;
uniform sampler2D tex;
varying vec2 uv;
void main() {
  gl_FragColor = texture2D(tex, uv);
}
""",
    )
  else:
    assert(false, "unsupported backend")
    ShaderSources()
