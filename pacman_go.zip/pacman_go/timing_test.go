package main

import "testing"

func TestXorshiftSequence(t *testing.T) {
	p := &PlayState{Xorshift: 0x12345678}
	want := []uint32{2274908837, 358294691, 1210119364, 2176035992, 1882851208}
	for i, w := range want {
		if got := p.xorshift32(); got != w {
			t.Errorf("step %d: got %d, want %d", i, got, w)
		}
	}
}

func TestTriggerVocabulary(t *testing.T) {
	var tr Trigger
	tr.Start(10) // promises tick 11
	if tr.Tick != 11 {
		t.Fatalf("Start: tick = %d, want 11", tr.Tick)
	}
	if !tr.Now(11) || tr.Now(10) {
		t.Error("Now semantics wrong")
	}
	if tr.Since(16) != 5 {
		t.Errorf("Since = %d, want 5", tr.Since(16))
	}
	if !tr.AfterOnce(16, 5) || tr.AfterOnce(15, 5) {
		t.Error("AfterOnce semantics wrong")
	}
	if !tr.After(16, 5) || tr.After(15, 5) {
		t.Error("After semantics wrong")
	}
	if !tr.Before(15, 5) || tr.Before(16, 5) {
		t.Error("Before semantics wrong")
	}
	if !tr.Between(16, 5, 10) || tr.Between(16, 0, 5) {
		t.Error("Between semantics wrong")
	}

	d := DisabledTrigger()
	if d.Since(100) != DisabledTicks {
		t.Error("disabled trigger: Since must be DisabledTicks")
	}
	if d.After(100, 0) || d.Before(100, 100) || d.Between(100, 0, 100) {
		t.Error("disabled trigger must never be After/Before/Between")
	}

	var sa Trigger
	sa.StartAfter(10, 30)
	if sa.Tick != 40 || !sa.Now(40) {
		t.Error("StartAfter semantics wrong")
	}
}

func TestInputDirPriority(t *testing.T) {
	cases := []struct {
		in   InputState
		want Dir
	}{
		{InputState{Up: true, Left: true}, DirUp},
		{InputState{Down: true, Right: true}, DirDown},
		{InputState{Right: true, Left: true}, DirRight},
		{InputState{Left: true}, DirLeft},
		{InputState{}, DirDown}, // default passed below
	}
	for i, c := range cases {
		if got := c.in.DirOr(DirDown); got != c.want {
			t.Errorf("case %d: got %v, want %v", i, got, c.want)
		}
	}
}
