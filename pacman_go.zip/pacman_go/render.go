// render.go -- video RAM writes, sprite animation, and (from Phase 3)
// the Ebitengine renderer. Corresponds to pacman.c lines 993-1229
// (vid/spr), 1584-1732 (tile/sprite updates) and 2404-3124 (gfx).
package main

import (
	"image/color"

	"github.com/hajimehoshi/ebiten/v2"
)

// --- vid: writes into the tile/color buffers (pacman.c 993-1133) ---

func (g *Game) vidClear(tileCode, colorCode uint8) {
	for y := 0; y < DisplayTilesY; y++ {
		for x := 0; x < DisplayTilesX; x++ {
			g.Gfx.VideoRAM[y][x] = tileCode
			g.Gfx.ColorRAM[y][x] = colorCode
		}
	}
}

func (g *Game) vidColorPlayfield(colorCode uint8) {
	for y := 3; y < DisplayTilesY-2; y++ {
		for x := 0; x < DisplayTilesX; x++ {
			g.Gfx.ColorRAM[y][x] = colorCode
		}
	}
}

func validTilePos(tilePos Int2) bool {
	return tilePos.X >= 0 && tilePos.X < DisplayTilesX &&
		tilePos.Y >= 0 && tilePos.Y < DisplayTilesY
}

func (g *Game) vidColor(tilePos Int2, colorCode uint8) {
	if !validTilePos(tilePos) {
		panic("vidColor: invalid tile pos")
	}
	g.Gfx.ColorRAM[tilePos.Y][tilePos.X] = colorCode
}

func (g *Game) vidTile(tilePos Int2, tileCode uint8) {
	if !validTilePos(tilePos) {
		panic("vidTile: invalid tile pos")
	}
	g.Gfx.VideoRAM[tilePos.Y][tilePos.X] = tileCode
}

func (g *Game) vidColorTile(tilePos Int2, colorCode, tileCode uint8) {
	if !validTilePos(tilePos) {
		panic("vidColorTile: invalid tile pos")
	}
	g.Gfx.VideoRAM[tilePos.Y][tilePos.X] = tileCode
	g.Gfx.ColorRAM[tilePos.Y][tilePos.X] = colorCode
}

// convChar translates an ASCII char into a "NAMCO char".
func convChar(c byte) uint8 {
	switch c {
	case ' ':
		return 0x40
	case '/':
		return 58
	case '-':
		return 59
	case '"':
		return 38
	case '!':
		return 'Z' + 1
	default:
		return c
	}
}

func (g *Game) vidColorChar(tilePos Int2, colorCode uint8, chr byte) {
	if !validTilePos(tilePos) {
		panic("vidColorChar: invalid tile pos")
	}
	g.Gfx.VideoRAM[tilePos.Y][tilePos.X] = convChar(chr)
	g.Gfx.ColorRAM[tilePos.Y][tilePos.X] = colorCode
}

func (g *Game) vidChar(tilePos Int2, chr byte) {
	if !validTilePos(tilePos) {
		panic("vidChar: invalid tile pos")
	}
	g.Gfx.VideoRAM[tilePos.Y][tilePos.X] = convChar(chr)
}

func (g *Game) vidColorText(tilePos Int2, colorCode uint8, text string) {
	if !validTilePos(tilePos) {
		panic("vidColorText: invalid tile pos")
	}
	tp := tilePos
	for i := 0; i < len(text); i++ {
		if tp.X < DisplayTilesX {
			g.vidColorChar(tp, colorCode, text[i])
			tp.X++
		} else {
			break
		}
	}
}

func (g *Game) vidText(tilePos Int2, text string) {
	if !validTilePos(tilePos) {
		panic("vidText: invalid tile pos")
	}
	tp := tilePos
	for i := 0; i < len(text); i++ {
		if tp.X < DisplayTilesX {
			g.vidChar(tp, text[i])
			tp.X++
		} else {
			break
		}
	}
}

// vidColorScore prints a score (scores are /10, printed right to left,
// last digit always 0).
func (g *Game) vidColorScore(tilePos Int2, colorCode uint8, score uint32) {
	tp := tilePos
	s := score
	g.vidColorChar(tp, colorCode, '0')
	tp.X--
	for digit := 0; digit < 8; digit++ {
		chr := byte(s%10) + '0'
		if validTilePos(tp) {
			g.vidColorChar(tp, colorCode, chr)
			tp.X--
			s /= 10
			if s == 0 {
				break
			}
		}
	}
}

// vidDrawTileQuad draws a 2x2 tile quad (used for lives and status
// fruits).
func (g *Game) vidDrawTileQuad(tilePos Int2, colorCode, tileCode uint8) {
	for yy := 0; yy < 2; yy++ {
		for xx := 0; xx < 2; xx++ {
			t := tileCode + uint8(yy*2+(1-xx))
			g.vidColorTile(I2(tilePos.X+int16(xx), tilePos.Y+int16(yy)),
				colorCode, t)
		}
	}
}

// vidFruitScore draws the fruit bonus score tiles (when Pacman has
// eaten the bonus fruit).
func (g *Game) vidFruitScore(fruitType Fruit) {
	if fruitType < FruitNone || fruitType >= NumFruits {
		panic("vidFruitScore: invalid fruit")
	}
	colorCode := uint8(ColorFruitScore)
	if fruitType == FruitNone {
		colorCode = ColorDot
	}
	for i := 0; i < 4; i++ {
		g.vidColorTile(I2(int16(12+i), 20), colorCode,
			fruitScoreTiles[fruitType][i])
	}
}

// --- spr: sprite state and animation (pacman.c 1134-1229) ---

func (g *Game) sprClear() {
	for i := range g.Gfx.Sprite {
		g.Gfx.Sprite[i] = Sprite{}
	}
}

func (g *Game) sprPacman() *Sprite { return &g.Gfx.Sprite[SpritePacman] }

func (g *Game) sprGhost(typ GhostType) *Sprite {
	if typ < GhostBlinky || typ >= NumGhosts {
		panic("sprGhost: invalid ghost type")
	}
	return &g.Gfx.Sprite[int(SpriteBlinky)+int(typ)]
}

func (g *Game) sprFruit() *Sprite { return &g.Gfx.Sprite[SpriteFruit] }

func (g *Game) sprAnimPacman(dir Dir, tick uint32) {
	tiles := [2][4]uint8{
		{44, 46, 48, 46}, // horizontal (needs flipx)
		{45, 47, 48, 47}, // vertical (needs flipy)
	}
	spr := g.sprPacman()
	phase := (tick / 2) & 3
	spr.Tile = tiles[dir&1][phase]
	spr.Color = ColorPacman
	spr.FlipX = dir == DirLeft
	spr.FlipY = dir == DirUp
}

func (g *Game) sprAnimPacmanDeath(tick uint32) {
	spr := g.sprPacman()
	tile := 52 + tick/8
	if tile > 63 {
		tile = 63
	}
	spr.Tile = uint8(tile)
	spr.FlipX = false
	spr.FlipY = false
}

func (g *Game) sprAnimGhost(ghostType GhostType, dir Dir, tick uint32) {
	if dir < DirRight || dir >= NumDirs {
		panic("sprAnimGhost: invalid dir")
	}
	tiles := [4][2]uint8{{32, 33}, {34, 35}, {36, 37}, {38, 39}}
	phase := (tick / 8) & 1
	spr := g.sprGhost(ghostType)
	spr.Tile = tiles[dir][phase]
	spr.Color = ColorBlinky + uint8(2*ghostType)
	spr.FlipX = false
	spr.FlipY = false
}

func (g *Game) sprAnimGhostFrightened(ghostType GhostType, tick uint32) {
	tiles := [2]uint8{28, 29}
	phase := (tick / 4) & 1
	spr := g.sprGhost(ghostType)
	spr.Tile = tiles[phase]
	// towards the end of the frightened period, start blinking (the C
	// code casts the possibly negative difference to uint32,
	// replicated here)
	fright := uint32(int32(levelSpec(int(g.Play.Round)).FrightTicks) - 60)
	if tick > fright {
		if (tick & 0x10) != 0 {
			spr.Color = ColorFrightened
		} else {
			spr.Color = ColorFrightenedBlinking
		}
	} else {
		spr.Color = ColorFrightened
	}
	spr.FlipX = false
	spr.FlipY = false
}

func (g *Game) sprAnimGhostEyes(ghostType GhostType, dir Dir) {
	if dir < DirRight || dir >= NumDirs {
		panic("sprAnimGhostEyes: invalid dir")
	}
	tiles := [4]uint8{32, 34, 36, 38}
	spr := g.sprGhost(ghostType)
	spr.Tile = tiles[dir]
	spr.Color = ColorEyes
	spr.FlipX = false
	spr.FlipY = false
}

// --- dynamic tile and sprite updates (pacman.c 1584-1732) ---

func (g *Game) gameUpdateTiles() {
	now := g.Timing.Tick
	g.vidColorScore(I2(6, 1), ColorDefault, g.Play.Score)
	if g.Play.Hiscore > 0 {
		g.vidColorScore(I2(16, 1), ColorDefault, g.Play.Hiscore)
	}

	pillPos := [NumPills]Int2{I2(1, 6), I2(26, 6), I2(1, 26), I2(26, 26)}
	for i := 0; i < NumPills; i++ {
		if g.Play.Freeze != 0 {
			g.vidColor(pillPos[i], ColorDot)
		} else if (g.Timing.Tick & 0x8) != 0 {
			g.vidColor(pillPos[i], 0x10)
		} else {
			g.vidColor(pillPos[i], 0)
		}
	}

	if g.Play.FruitEaten.AfterOnce(now, 2*60) {
		g.vidFruitScore(FruitNone)
	}

	for i := 0; i < NumLives; i++ {
		color := uint8(0)
		if i < int(g.Play.NumLives) {
			color = ColorPacman
		}
		g.vidDrawTileQuad(I2(int16(2+2*i), 34), color, TileLife)
	}

	// bonus fruit list in the bottom-right corner
	{
		x := int16(24)
		round := int(g.Play.Round)
		for i := round - NumStatusFruits + 1; i <= round; i++ {
			if i >= 0 {
				fruit := levelSpec(i).BonusFruit
				g.vidDrawTileQuad(I2(x, 34), fruitTilesColors[fruit][2],
					fruitTilesColors[fruit][0])
				x -= 2
			}
		}
	}

	// if the round was won, blink the whole playfield blue/white
	if g.Play.RoundWon.After(now, 1*60) {
		if (g.Play.RoundWon.Since(now) & 0x10) != 0 {
			g.vidColorPlayfield(ColorDot)
		} else {
			g.vidColorPlayfield(ColorWhiteBorder)
		}
	}
}

func (g *Game) gameUpdateSprites() {
	now := g.Timing.Tick
	// Pacman sprite
	if spr := g.sprPacman(); spr.Enabled {
		actor := g.Play.Pacman.Actor
		spr.Pos = actor.Pos.ActorToSpritePos()
		switch {
		case g.Play.Freeze.Has(FreezeEatGhost):
			spr.Tile = SpritetileInvisible
		case g.Play.Freeze.Has(FreezePrelude) || g.Play.Freeze.Has(FreezeReady):
			spr.Tile = SpritetilePacmanClosedMouth
		case g.Play.Freeze.Has(FreezeDead):
			if g.Play.PacmanEaten.After(now, PacmanEatenTicks) {
				g.sprAnimPacmanDeath(g.Play.PacmanEaten.Since(now) - PacmanEatenTicks)
			}
		default:
			g.sprAnimPacman(actor.Dir, actor.AnimTick)
		}
	}

	// ghost sprites
	for i := 0; i < int(NumGhosts); i++ {
		sprite := g.sprGhost(GhostType(i))
		if sprite.Enabled {
			ghost := g.Play.Ghost[i]
			sprite.Pos = ghost.Actor.Pos.ActorToSpritePos()
			switch {
			case g.Play.Freeze.Has(FreezeDead):
				if g.Play.PacmanEaten.After(now, PacmanEatenTicks) {
					sprite.Tile = SpritetileInvisible
				}
			case g.Play.Freeze.Has(FreezeWon):
				sprite.Tile = SpritetileInvisible
			default:
				switch ghost.State {
				case GhostStateEyes:
					if ghost.Eaten.Before(now, GhostEatenFreezeTicks) {
						// show the score number for the just-eaten ghost
						sprite.Tile = uint8(int(SpritetileScore200) +
							int(g.Play.NumGhostsEaten) - 1)
						sprite.Color = ColorGhostScore
					} else {
						g.sprAnimGhostEyes(GhostType(i), ghost.NextDir)
					}
				case GhostStateEnterHouse:
					g.sprAnimGhostEyes(GhostType(i), ghost.Actor.Dir)
				case GhostStateFrightened:
					g.sprAnimGhostFrightened(GhostType(i),
						ghost.Frightened.Since(now))
				default:
					g.sprAnimGhost(GhostType(i), ghost.NextDir,
						ghost.Actor.AnimTick)
				}
			}
		}
	}

	// bonus fruit sprite
	if g.Play.ActiveFruit == FruitNone {
		g.sprFruit().Enabled = false
	} else {
		spr := g.sprFruit()
		spr.Enabled = true
		spr.Pos = I2(13*TileWidth, 19*TileHeight+TileHeight/2)
		spr.Tile = fruitTilesColors[g.Play.ActiveFruit][1]
		spr.Color = fruitTilesColors[g.Play.ActiveFruit][2]
	}
}

// --- the Ebitengine renderer (pacman.c 2404-3124, SPEC H5/H6) ---
//
// The sokol version renders indexed pixels through a palette shader.
// Here the palette is baked into RGBA atlases at startup instead:
// one image per (tile, color) and (sprite, color) pair, drawn with
// FilterNearest. The board keeps the original's table + an offscreen
// image that is updated only where tiles changed.

// tileTextureWidth/Height mirror the C layout of the decoded pixel
// buffer: 256 tiles of 8px on the top row band, 64 sprites of 16px
// below (pacman.c TILE_TEXTURE_WIDTH / TILE_TEXTURE_HEIGHT).
const (
	tileTextureWidth  = 256 * TileWidth
	tileTextureHeight = TileHeight + SpriteHeight
)

// Renderer owns the Ebitengine-side drawing resources.
type Renderer struct {
	g *Game

	tilePixels [tileTextureHeight][tileTextureWidth]uint8

	tileImgs   [256][32]*ebiten.Image
	spriteImgs [64][32]*ebiten.Image

	board      *ebiten.Image
	boardValid bool
	lastVideo  [DisplayTilesY][DisplayTilesX]uint8
	lastColor  [DisplayTilesY][DisplayTilesX]uint8

	white *ebiten.Image
}

// gfxDecodeTile8x4 decodes one 8x4 half of a tile or sprite from the
// ROM bitplanes into the pixel-value buffer.
func (r *Renderer) gfxDecodeTile8x4(texX, texY uint32, tileBase []uint8,
	tileStride, tileOffset uint32, tileCode uint8) {
	for tx := uint32(0); tx < TileWidth; tx++ {
		ti := uint32(tileCode)*tileStride + tileOffset + (7 - tx)
		for ty := uint32(0); ty < TileHeight/2; ty++ {
			pHi := (tileBase[ti] >> (7 - ty)) & 1
			pLo := (tileBase[ti] >> (3 - ty)) & 1
			p := (pHi << 1) | pLo
			r.tilePixels[texY+ty][texX+tx] = p
		}
	}
}

func (r *Renderer) gfxDecodeTile(tileCode uint8) {
	x := uint32(tileCode) * TileWidth
	r.gfxDecodeTile8x4(x, 0, romTiles[:], 16, 8, tileCode)
	r.gfxDecodeTile8x4(x, TileHeight/2, romTiles[:], 16, 0, tileCode)
}

func (r *Renderer) gfxDecodeSprite(spriteCode uint8) {
	x0 := uint32(spriteCode) * SpriteWidth
	x1 := x0 + TileWidth
	y0 := uint32(TileHeight)
	y1 := y0 + TileHeight/2
	y2 := y1 + TileHeight/2
	y3 := y2 + TileHeight/2
	r.gfxDecodeTile8x4(x0, y0, romSprites[:], 64, 40, spriteCode)
	r.gfxDecodeTile8x4(x1, y0, romSprites[:], 64, 8, spriteCode)
	r.gfxDecodeTile8x4(x0, y1, romSprites[:], 64, 48, spriteCode)
	r.gfxDecodeTile8x4(x1, y1, romSprites[:], 64, 16, spriteCode)
	r.gfxDecodeTile8x4(x0, y2, romSprites[:], 64, 56, spriteCode)
	r.gfxDecodeTile8x4(x1, y2, romSprites[:], 64, 24, spriteCode)
	r.gfxDecodeTile8x4(x0, y3, romSprites[:], 64, 32, spriteCode)
	r.gfxDecodeTile8x4(x1, y3, romSprites[:], 64, 0, spriteCode)
}

func (r *Renderer) gfxDecodeTiles() {
	for tileCode := 0; tileCode < 256; tileCode++ {
		r.gfxDecodeTile(uint8(tileCode))
	}
	for spriteCode := 0; spriteCode < 64; spriteCode++ {
		r.gfxDecodeSprite(uint8(spriteCode))
	}
}

// gfxDecodeColorPalette decodes the hardware color palette into
// g.Gfx.ColorPalette (packed 0xAABBGGRR, alpha cleared for index 0 of
// each group of 4), as in pacman.c.
func (g *Game) gfxDecodeColorPalette() {
	var hwColors [32]uint32
	for i := 0; i < 32; i++ {
		rgb := romHWColors[i]
		rr := uint32((rgb>>0)&1)*0x21 + uint32((rgb>>1)&1)*0x47 + uint32((rgb>>2)&1)*0x97
		gg := uint32((rgb>>3)&1)*0x21 + uint32((rgb>>4)&1)*0x47 + uint32((rgb>>5)&1)*0x97
		bb := uint32((rgb>>6)&1)*0x47 + uint32((rgb>>7)&1)*0x97
		hwColors[i] = 0xFF000000 | (bb << 16) | (gg << 8) | rr
	}
	for i := 0; i < 256; i++ {
		g.Gfx.ColorPalette[i] = hwColors[romPalette[i]&0xF]
		if (i & 3) == 0 {
			g.Gfx.ColorPalette[i] &= 0x00FFFFFF
		}
	}
}

// paletteColor converts a packed palette entry to an RGBA color.
func paletteColor(packed uint32) color.RGBA {
	return color.RGBA{
		R: uint8(packed & 0xFF),
		G: uint8((packed >> 8) & 0xFF),
		B: uint8((packed >> 16) & 0xFF),
		A: uint8((packed >> 24) & 0xFF),
	}
}

// bakeAtlases renders every (tile, color) and (sprite, color) pair
// into its own small image, using the decoded palette.
func (r *Renderer) bakeAtlases() {
	pal := &r.g.Gfx.ColorPalette
	// tiles: 8x8 at (0,0) band of tilePixels
	tileBuf := make([]byte, TileWidth*TileHeight*4)
	for code := 0; code < 256; code++ {
		for c := 0; c < 32; c++ {
			for y := 0; y < TileHeight; y++ {
				for x := 0; x < TileWidth; x++ {
					pix := r.tilePixels[y][code*TileWidth+x]
					col := paletteColor(pal[c*4+int(pix)])
					o := (y*TileWidth + x) * 4
					tileBuf[o+0] = col.R
					tileBuf[o+1] = col.G
					tileBuf[o+2] = col.B
					tileBuf[o+3] = col.A
				}
			}
			img := ebiten.NewImage(TileWidth, TileHeight)
			img.WritePixels(tileBuf)
			r.tileImgs[code][c] = img
		}
	}
	// sprites: 16x16 at the (0, TileHeight) band of tilePixels
	sprBuf := make([]byte, SpriteWidth*SpriteHeight*4)
	for code := 0; code < 64; code++ {
		for c := 0; c < 32; c++ {
			for y := 0; y < SpriteHeight; y++ {
				for x := 0; x < SpriteWidth; x++ {
					pix := r.tilePixels[TileHeight+y][code*SpriteWidth+x]
					col := paletteColor(pal[c*4+int(pix)])
					o := (y*SpriteWidth + x) * 4
					sprBuf[o+0] = col.R
					sprBuf[o+1] = col.G
					sprBuf[o+2] = col.B
					sprBuf[o+3] = col.A
				}
			}
			img := ebiten.NewImage(SpriteWidth, SpriteHeight)
			img.WritePixels(sprBuf)
			r.spriteImgs[code][c] = img
		}
	}
}

// newRenderer performs the state-side gfx init (fade triggers
// disabled, fade fully set, sprites cleared) and builds the atlases.
func newRenderer(g *Game) *Renderer {
	g.Gfx.Fadein.Disable()
	g.Gfx.Fadeout.Disable()
	g.Gfx.Fade = 0xFF
	g.sprClear()
	r := &Renderer{g: g}
	r.gfxDecodeTiles()
	g.gfxDecodeColorPalette()
	r.bakeAtlases()
	r.board = ebiten.NewImage(DisplayPixelsX, DisplayPixelsY)
	r.white = ebiten.NewImage(1, 1)
	r.white.Fill(color.White)
	return r
}

// gfxFade advances the fade value from the fade triggers, as in
// pacman.c's gfx_fade (called once per Draw).
func (g *Game) gfxFade() {
	now := g.Timing.Tick
	if g.Gfx.Fadein.Between(now, 0, FadeTicks) {
		t := float32(g.Gfx.Fadein.Since(now)) / FadeTicks
		g.Gfx.Fade = uint8(255.0 * (1.0 - t))
	}
	if g.Gfx.Fadein.AfterOnce(now, FadeTicks) {
		g.Gfx.Fade = 0
	}
	if g.Gfx.Fadeout.Between(now, 0, FadeTicks) {
		t := float32(g.Gfx.Fadeout.Since(now)) / FadeTicks
		g.Gfx.Fade = uint8(255.0 * t)
	}
	if g.Gfx.Fadeout.AfterOnce(now, FadeTicks) {
		g.Gfx.Fade = 255
	}
}

// updateBoard redraws the changed tiles into the board offscreen.
func (r *Renderer) updateBoard() {
	g := r.g
	if !r.boardValid {
		r.board.Fill(color.Black)
	}
	for y := 0; y < DisplayTilesY; y++ {
		for x := 0; x < DisplayTilesX; x++ {
			tile := g.Gfx.VideoRAM[y][x]
			col := g.Gfx.ColorRAM[y][x] & 0x1F
			if r.boardValid && tile == r.lastVideo[y][x] && col == (r.lastColor[y][x]&0x1F) {
				continue
			}
			op := &ebiten.DrawImageOptions{Filter: ebiten.FilterNearest}
			op.GeoM.Translate(float64(x*TileWidth), float64(y*TileHeight))
			r.board.DrawImage(r.tileImgs[tile][col], op)
			r.lastVideo[y][x] = tile
			r.lastColor[y][x] = g.Gfx.ColorRAM[y][x]
		}
	}
	r.boardValid = true
}

// Draw renders one frame: board, sprites, debug markers, fade.
func (r *Renderer) Draw(screen *ebiten.Image) {
	g := r.g
	g.gfxFade()
	r.updateBoard()

	op := &ebiten.DrawImageOptions{Filter: ebiten.FilterNearest}
	screen.DrawImage(r.board, op)

	// sprites
	for i := 0; i < NumSprites; i++ {
		spr := g.Gfx.Sprite[i]
		if !spr.Enabled {
			continue
		}
		img := r.spriteImgs[spr.Tile][spr.Color&0x1F]
		sop := &ebiten.DrawImageOptions{Filter: ebiten.FilterNearest}
		sx, sy := 1.0, 1.0
		tx, ty := float64(spr.Pos.X), float64(spr.Pos.Y)
		if spr.FlipX {
			sx = -1
			tx += SpriteWidth
		}
		if spr.FlipY {
			sy = -1
			ty += SpriteHeight
		}
		sop.GeoM.Scale(sx, sy)
		sop.GeoM.Translate(tx, ty)
		screen.DrawImage(img, sop)
	}

	// debug markers (never enabled by the game itself)
	for i := 0; i < NumDebugMarkers; i++ {
		dbg := g.Gfx.DebugMarker[i]
		if !dbg.Enabled {
			continue
		}
		dop := &ebiten.DrawImageOptions{Filter: ebiten.FilterNearest}
		dop.GeoM.Translate(float64(dbg.TilePos.X*TileWidth),
			float64(dbg.TilePos.Y*TileHeight))
		screen.DrawImage(r.tileImgs[dbg.Tile][dbg.Color&0x1F], dop)
	}

	// fade: a black overlay whose opacity is the fade value
	if g.Gfx.Fade > 0 {
		fop := &ebiten.DrawImageOptions{Filter: ebiten.FilterNearest}
		fop.GeoM.Scale(DisplayPixelsX, DisplayPixelsY)
		fop.ColorScale.Scale(0, 0, 0, float32(g.Gfx.Fade)/255)
		screen.DrawImage(r.white, fop)
	}
}
