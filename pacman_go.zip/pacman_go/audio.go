// audio.go -- the Namco sound-board state and sound effects.
// Corresponds to pacman.c lines 638-678 (descriptions) and 3125-3388
// (logic). The sample output (the pull-type Synth) is at the end of
// this file, added in Phase 4.
package main

// sndClear clears all active sound effects (the voices go silent).
func (g *Game) sndClear() {
	for i := range g.Audio.Voice {
		g.Audio.Voice[i] = Voice{}
	}
	for i := range g.Audio.Sound {
		g.Audio.Sound[i] = Sound{}
	}
}

// sndStop stops a sound effect.
func (g *Game) sndStop(slot int32) {
	if slot < 0 || slot >= NumSounds {
		panic("sndStop: invalid slot")
	}
	for i := 0; i < NumVoices; i++ {
		if g.Audio.Sound[slot].Flags&(SoundFlags(1<<i)) != 0 {
			g.Audio.Voice[i] = Voice{}
		}
	}
	g.Audio.Sound[slot] = Sound{}
}

// sndStart starts a sound effect in a slot.
func (g *Game) sndStart(slot int32, desc SoundDesc) {
	if slot < 0 || slot >= NumSounds {
		panic("sndStart: invalid slot")
	}
	if desc.Data == nil && desc.Fn == nil {
		panic("sndStart: desc has neither data nor fn")
	}
	snd := &g.Audio.Sound[slot]
	*snd = Sound{}
	numVoices := 0
	for i := 0; i < NumVoices; i++ {
		if desc.Voice[i] {
			snd.Flags |= SoundFlags(1 << i)
			numVoices++
		}
	}
	if desc.Fn != nil {
		snd.Fn = desc.Fn
	} else {
		if numVoices == 0 {
			panic("sndStart: dump sound with no voices")
		}
		if len(desc.Data)%numVoices != 0 {
			panic("sndStart: dump size not a multiple of the voice count")
		}
		snd.Stride = uint32(numVoices)
		snd.NumTicks = uint32(len(desc.Data)) / snd.Stride
		snd.Data = desc.Data
	}
}

// sndTick is the sound system's 60 Hz tick function (called from
// Game.Tick before the scene tick, as in pacman.c's frame callback).
func (g *Game) sndTick() {
	for slot := 0; slot < NumSounds; slot++ {
		snd := &g.Audio.Sound[slot]
		skipIncrement := false
		if snd.Fn != nil {
			snd.Fn(g, int32(slot))
		} else if snd.Flags&SoundAllVoices != 0 {
			if snd.Data == nil {
				panic("sndTick: dump sound without data")
			}
			if snd.CurTick == snd.NumTicks {
				g.sndStop(int32(slot))
				skipIncrement = true
			} else {
				idx := int(snd.CurTick * snd.Stride)
				for i := 0; i < NumVoices; i++ {
					if snd.Flags&(SoundFlags(1<<i)) != 0 {
						voice := &g.Audio.Voice[i]
						val := snd.Data[idx]
						idx++
						voice.Frequency = val & ((1 << 20) - 1)
						voice.Waveform = uint8((val >> 24) & 7)
						voice.Volume = uint8((val >> 28) & 0xF)
					}
				}
			}
		}
		if !skipIncrement {
			snd.CurTick++
		}
	}
}

// --- procedural sound effects (pacman.c 3281-3388) ---

func sndFuncEatdot1(g *Game, slot int32) {
	snd := &g.Audio.Sound[slot]
	voice := &g.Audio.Voice[2]
	switch {
	case snd.CurTick == 0:
		voice.Volume = 12
		voice.Waveform = 2
		voice.Frequency = 0x1500
	case snd.CurTick == 5:
		g.sndStop(slot)
	default:
		voice.Frequency -= 0x0300
	}
}

func sndFuncEatdot2(g *Game, slot int32) {
	snd := &g.Audio.Sound[slot]
	voice := &g.Audio.Voice[2]
	switch {
	case snd.CurTick == 0:
		voice.Volume = 12
		voice.Waveform = 2
		voice.Frequency = 0x0700
	case snd.CurTick == 5:
		g.sndStop(slot)
	default:
		voice.Frequency += 0x300
	}
}

func sndFuncEatghost(g *Game, slot int32) {
	snd := &g.Audio.Sound[slot]
	voice := &g.Audio.Voice[2]
	switch {
	case snd.CurTick == 0:
		voice.Volume = 12
		voice.Waveform = 5
		voice.Frequency = 0
	case snd.CurTick == 32:
		g.sndStop(slot)
	default:
		voice.Frequency += 0x20
	}
}

func sndFuncEatfruit(g *Game, slot int32) {
	snd := &g.Audio.Sound[slot]
	voice := &g.Audio.Voice[2]
	switch {
	case snd.CurTick == 0:
		voice.Volume = 15
		voice.Waveform = 6
		voice.Frequency = 0x1600
	case snd.CurTick == 23:
		g.sndStop(slot)
	case snd.CurTick < 11:
		voice.Frequency -= 0x200
	default:
		voice.Frequency += 0x0200
	}
}

func sndFuncWeeooh(g *Game, slot int32) {
	snd := &g.Audio.Sound[slot]
	voice := &g.Audio.Voice[1]
	switch {
	case snd.CurTick == 0:
		voice.Volume = 6
		voice.Waveform = 6
		voice.Frequency = 0x1000
	case (snd.CurTick % 24) < 12:
		voice.Frequency += 0x0200
	default:
		voice.Frequency -= 0x0200
	}
}

func sndFuncFrightened(g *Game, slot int32) {
	snd := &g.Audio.Sound[slot]
	voice := &g.Audio.Voice[1]
	switch {
	case snd.CurTick == 0:
		voice.Volume = 10
		voice.Waveform = 4
		voice.Frequency = 0x0180
	case (snd.CurTick % 8) == 0:
		voice.Frequency = 0x0180
	default:
		voice.Frequency += 0x180
	}
}

// --- sound effect descriptions (pacman.c 638-678) ---

var sndPrelude = SoundDesc{
	Data:  sndDumpPrelude[:],
	Voice: [3]bool{true, true, false},
}

var sndDead = SoundDesc{
	Data:  sndDumpDead[:],
	Voice: [3]bool{false, false, true},
}

var sndEatdot1 = SoundDesc{Fn: sndFuncEatdot1, Voice: [3]bool{false, false, true}}
var sndEatdot2 = SoundDesc{Fn: sndFuncEatdot2, Voice: [3]bool{false, false, true}}
var sndEatghost = SoundDesc{Fn: sndFuncEatghost, Voice: [3]bool{false, false, true}}
var sndEatfruit = SoundDesc{Fn: sndFuncEatfruit, Voice: [3]bool{false, false, true}}
var sndWeeooh = SoundDesc{Fn: sndFuncWeeooh, Voice: [3]bool{false, true, false}}
var sndFrightened = SoundDesc{Fn: sndFuncFrightened, Voice: [3]bool{false, true, false}}

// --- the pull-type sample output (SPEC H3) ---
//
// The C version pushes samples from the frame callback; Ebitengine
// pulls them through an io.Reader on the audio thread. The register
// state is advanced by Game.Tick (sndTick, 60 Hz) on the game thread
// and read here as it stands -- the same lock-free relationship the
// original has with the sound hardware. One tick is exactly 735
// samples at 44,100 Hz.

const (
	SampleRate     = 44100
	SamplesPerTick = SampleRate / 60 // 735
	bytesPerSample = 4               // 16-bit stereo
)

// Synth converts the Namco voice state into a sample stream.
type Synth struct {
	g *Game

	voiceTickAccum  int32 // in thousandths of a 96 kHz tick
	voiceTickPeriod int32 // 96,000,000 / SampleRate = 2176

	buf []byte // one tick of generated samples
	pos int
}

// NewSynth creates a Synth reading the game's audio state.
func NewSynth(g *Game) *Synth {
	return &Synth{
		g:               g,
		voiceTickPeriod: 96_000_000 / SampleRate,
		buf:             make([]byte, SamplesPerTick*bytesPerSample),
		pos:             SamplesPerTick * bytesPerSample, // start empty
	}
}

// voiceTick updates the Namco sound generator once (96 kHz).
func (s *Synth) voiceTick() {
	for i := 0; i < NumVoices; i++ {
		voice := &s.g.Audio.Voice[i]
		voice.Counter += voice.Frequency
		waveIndex := ((uint32(voice.Waveform) << 5) |
			((voice.Counter >> 15) & 0x1F)) & 0xFF
		sample := (int32(romWavetable[waveIndex]&0xF) - 8) * int32(voice.Volume)
		voice.SampleAcc += float32(sample)
		voice.SampleDiv += 128
	}
}

// sampleTick computes one output sample from the voice averages.
func (s *Synth) sampleTick() float32 {
	var sm float32
	for i := 0; i < NumVoices; i++ {
		voice := &s.g.Audio.Voice[i]
		if voice.SampleDiv > 0 {
			sm += voice.SampleAcc / voice.SampleDiv
			voice.SampleAcc = 0
			voice.SampleDiv = 0
		}
	}
	return sm * 0.333333 * AudioVolume
}

// generate fills the internal buffer with one tick of samples.
func (s *Synth) generate() {
	for i := 0; i < SamplesPerTick; i++ {
		s.voiceTickAccum -= s.voiceTickPeriod
		for s.voiceTickAccum < 0 {
			s.voiceTickAccum += 1000
			s.voiceTick()
		}
		v := int16(s.sampleTick() * 32767)
		o := i * bytesPerSample
		s.buf[o+0] = byte(v)
		s.buf[o+1] = byte(v >> 8)
		s.buf[o+2] = byte(v)
		s.buf[o+3] = byte(v >> 8)
	}
	s.pos = 0
}

// Read implements io.Reader for the Ebitengine audio player.
func (s *Synth) Read(p []byte) (int, error) {
	n := 0
	for n < len(p) {
		if s.pos >= len(s.buf) {
			s.generate()
		}
		m := copy(p[n:], s.buf[s.pos:])
		s.pos += m
		n += m
	}
	return n, nil
}
