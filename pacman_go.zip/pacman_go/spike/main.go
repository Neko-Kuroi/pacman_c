// Phase 0 spike: verify the Ebitengine foundation for the pacman port.
// Checks: window + Layout scaling, tile drawing with FilterNearest,
// audio pull-reader, clean exit after 180 updates.
package main

import (
	"fmt"
	"image/color"
	"os"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/audio"
)

// silenceReader is a pull-type sample source that produces silence.
type silenceReader struct{ bytesRead int }

func (r *silenceReader) Read(p []byte) (int, error) {
	for i := range p {
		p[i] = 0
	}
	r.bytesRead += len(p)
	return len(p), nil
}

type spike struct {
	frames int
	tiles  [4]*ebiten.Image
	reader *silenceReader
}

func (s *spike) Update() error {
	s.frames++
	if s.frames == 180 {
		fmt.Printf("spike: 180 updates reached, audio bytes pulled: %d\n", s.reader.bytesRead)
		return ebiten.Termination
	}
	return nil
}

func (s *spike) Draw(screen *ebiten.Image) {
	for y := 0; y < 36; y++ {
		for x := 0; x < 28; x++ {
			op := &ebiten.DrawImageOptions{Filter: ebiten.FilterNearest}
			op.GeoM.Translate(float64(x*8), float64(y*8))
			screen.DrawImage(s.tiles[(x+y)%4], op)
		}
	}
}

func (s *spike) Layout(w, h int) (int, int) { return 224, 288 }

func main() {
	colors := [4]color.RGBA{
		{0x21, 0x21, 0xff, 0xff}, // pacman blue
		{0xff, 0xff, 0x00, 0xff}, // yellow
		{0xff, 0x00, 0x00, 0xff}, // red
		{0x00, 0xff, 0xff, 0xff}, // cyan
	}
	s := &spike{reader: &silenceReader{}}
	for i, c := range colors {
		s.tiles[i] = ebiten.NewImage(8, 8)
		s.tiles[i].Fill(c)
	}

	if os.Getenv("PACMAN_AUDIO") == "off" {
		// Skip audio entirely: creating a player would initialize the
		// driver, and on a machine without an audio device that error
		// makes RunGame return immediately (verified: frames run: 1).
		fmt.Println("spike: audio disabled by PACMAN_AUDIO=off")
		ebiten.SetWindowSize(448, 576)
		ebiten.SetWindowTitle("pacman-go spike")
		err := ebiten.RunGame(s)
		fmt.Printf("spike: RunGame returned: %v (frames run: %d)\n", err, s.frames)
		return
	}
	ctx := audio.NewContext(44100)
	fmt.Printf("spike: audio context sample rate: %d\n", ctx.SampleRate())
	player, err := ctx.NewPlayer(s.reader)
	if err != nil {
		// No audio device on this machine: the driver initialization
		// fails with an error (not a crash of the engine itself).
		// The game must continue silently in that case.
		fmt.Printf("spike: audio unavailable, continuing silently: %v\n", err)
		// Exercise the pull reader directly to verify the mechanism.
		buf := make([]byte, 735*4)
		for i := 0; i < 10; i++ {
			n, rerr := s.reader.Read(buf)
			if rerr != nil || n != len(buf) {
				panic("reader failed")
			}
		}
		fmt.Printf("spike: reader pulled directly: %d bytes\n", s.reader.bytesRead)
	} else {
		player.Play()
		fmt.Println("spike: audio player started")
	}

	ebiten.SetWindowSize(448, 576)
	ebiten.SetWindowTitle("pacman-go spike")
	err = ebiten.RunGame(s)
	fmt.Printf("spike: RunGame returned: %v (frames run: %d)\n", err, s.frames)
}
