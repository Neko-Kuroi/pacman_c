package main

import "testing"

// Behavioural probes: the Go counterpart of the Nim port's
// tests/audit_probes.nim (17 checks). Speeds, phase timing, house dot
// counters, frightened duration, ghost-eaten scores and event timing,
// all against the C original's rules.

func TestProbeEventTiming(t *testing.T) {
	g := toGameplay(t)
	dtReady := int64(g.Play.ReadyStarted.Tick) - int64(g.Play.Started.Tick)
	if dtReady != 120 {
		t.Errorf("prelude timing: started->readyStarted = %d, want 120", dtReady)
	}
	dtRound := int64(g.Play.RoundStarted.Tick) - int64(g.Play.ReadyStarted.Tick)
	if dtRound != 130 {
		t.Errorf("ready timing: readyStarted->roundStarted = %d, want 130", dtRound)
	}
}

func TestProbeScatterChaseSwitch(t *testing.T) {
	g := toGameplay(t)
	base := int64(g.Play.RoundStarted.Tick)
	for int64(g.Timing.Tick) < base+419 {
		g.Tick()
	}
	if s := g.Play.Ghost[GhostBlinky].State; s != GhostStateScatter {
		t.Errorf("at +419: Blinky state = %v, want scatter", s)
	}
	g.Tick()
	if s := g.Play.Ghost[GhostBlinky].State; s != GhostStateChase {
		t.Errorf("at +420: Blinky state = %v, want chase", s)
	}
}

func TestProbePacmanClearSpeed(t *testing.T) {
	g := toGameplay(t)
	// row 17 has dots at tiles 6 and 21; clear them for an empty corridor
	for x := 0; x < DisplayTilesX; x++ {
		if g.Gfx.VideoRAM[17][x] == TileDot {
			g.Gfx.VideoRAM[17][x] = TileSpace
		}
	}
	g.Play.Pacman.Actor.Pos = I2(60, 17*8+4)
	g.Play.Pacman.Actor.Dir = DirLeft
	setInput(g, DirLeft)
	moved := 0
	prevX := g.Play.Pacman.Actor.Pos.X
	for i := 0; i < 112; i++ {
		g.Tick()
		x := g.Play.Pacman.Actor.Pos.X
		d := int(prevX - x)
		if d < -100 {
			d += DisplayPixelsX // wrapped through the tunnel
		}
		moved += d
		prevX = x
	}
	if moved != 98 {
		t.Errorf("clear speed: moved %d px in 112 ticks, want 98 (7/8)", moved)
	}
}

func TestProbePacmanEatingSpeed(t *testing.T) {
	g := toGameplay(t)
	g.Play.Pacman.Actor.Pos = I2(12*8+4, 23*8+4)
	g.Play.Pacman.Actor.Dir = DirLeft
	setInput(g, DirLeft)
	ticks := 0
	for g.Play.Pacman.Actor.Pos.X > 12 && ticks < 300 {
		g.Tick()
		ticks++
	}
	ratio := 88.0 / float64(ticks)
	if ratio <= 0.77 || ratio >= 0.83 {
		t.Errorf("eating speed: 88px in %d ticks, ratio %.3f, want ~0.80", ticks, ratio)
	}
}

func TestProbeGhostSpeed(t *testing.T) {
	g := toGameplay(t)
	gTicks, gMoved := 0, 0
	prevPos := g.Play.Ghost[0].Actor.Pos
	for i := 0; i < 3000; i++ {
		g.Tick()
		gh := g.Play.Ghost[0]
		d := int(abs16(gh.Actor.Pos.X-prevPos.X)) + int(abs16(gh.Actor.Pos.Y-prevPos.Y))
		if (gh.State == GhostStateScatter || gh.State == GhostStateChase) &&
			!isTunnel(pixelToTilePos(gh.Actor.Pos)) && g.Play.Freeze.Empty() {
			gTicks++
			gMoved += d
		}
		prevPos = gh.Actor.Pos
	}
	ratio := float64(gMoved) / float64(gTicks)
	if ratio <= 0.83 || ratio >= 0.88 {
		t.Errorf("ghost speed: ratio %.4f over %d ticks, want ~0.857 (6/7)", ratio, gTicks)
	}
}

func TestProbeHouseCounters(t *testing.T) {
	g := toGameplay(t)
	inkyAt, clydeAt := -1, -1
	pills := 0
	lastPillTick := uint32(DisabledTicks)
	lives0 := g.Play.NumLives
	for g.Play.NumDotsEaten < 120 && g.Play.NumLives == lives0 {
		g.Tick()
		if g.Play.PillEaten.Tick != DisabledTicks && g.Play.PillEaten.Tick != lastPillTick {
			lastPillTick = g.Play.PillEaten.Tick
			pills++
		}
		// pin the two roaming ghosts so Pacman survives long enough;
		// this does not touch the dot-counter mechanism under test
		g.Play.Ghost[0].Actor.Pos = ghostStartingPos[0]
		if g.Play.Ghost[1].State != GhostStateHouse {
			g.Play.Ghost[1].Actor.Pos = ghostStartingPos[1]
		}
		if g.Play.Freeze.Empty() {
			setInput(g, steerDir(g))
		}
		if inkyAt < 0 && g.Play.Ghost[GhostInky].State != GhostStateHouse {
			inkyAt = int(g.Play.NumDotsEaten)
		}
		if clydeAt < 0 && g.Play.Ghost[GhostClyde].State != GhostStateHouse {
			clydeAt = int(g.Play.NumDotsEaten)
		}
	}
	if inkyAt != 30 {
		t.Errorf("Inky left at %d dots, want 30", inkyAt)
	}
	if clydeAt >= 0 {
		// pills raise NumDotsEaten but do not advance the house
		// counters (the C pill branch never calls the counter
		// update), so Clyde's exit shifts by the pills eaten
		if clydeAt != 90+pills {
			t.Errorf("Clyde left at %d dots with %d pills, want %d", clydeAt, pills, 90+pills)
		}
	} else {
		t.Logf("Clyde check skipped (death or 120 dots first), dots=%d", g.Play.NumDotsEaten)
	}
}

func TestProbeGlobalCounter(t *testing.T) {
	g := toGameplay(t)
	// stage a death: put Blinky (chase) onto Pacman's tile
	g.Play.Ghost[0].State = GhostStateChase
	g.Play.Ghost[0].Actor.Pos = g.Play.Pacman.Actor.Pos
	g.Tick()
	if g.Play.PacmanEaten.Tick == DisabledTicks {
		t.Fatal("death did not set pacmanEaten")
	}
	// start() stores tick+1 while StartAfter() stores tick+N, so the
	// stored trigger values differ by 209 even though the delay is
	// 210 ticks (the C code has the same arithmetic)
	dtDeath := int64(g.Play.ReadyStarted.Tick) - int64(g.Play.PacmanEaten.Tick)
	if dtDeath != 209 {
		t.Errorf("death->ready timing: delta = %d, want 209", dtDeath)
	}
	// wait for the new round to run with the global counter active
	for i := 0; i < 2000; i++ {
		g.Tick()
		if g.Play.Freeze.Empty() && g.Play.GlobalDotCounterActive {
			break
		}
	}
	gPinky, gInky, gClyde := -1, -1, -1
	for guard := 0; gClyde < 0 && guard < 30000; guard++ {
		g.Tick()
		if g.Play.Freeze.Empty() {
			setInput(g, steerDir(g))
		}
		if gPinky < 0 && g.Play.Ghost[GhostPinky].State != GhostStateHouse {
			gPinky = int(g.Play.GlobalDotCounter)
		}
		if gInky < 0 && g.Play.Ghost[GhostInky].State != GhostStateHouse {
			gInky = int(g.Play.GlobalDotCounter)
		}
		if gClyde < 0 && g.Play.Ghost[GhostClyde].State != GhostStateHouse {
			gClyde = int(g.Play.GlobalDotCounter)
		}
	}
	if gPinky != 7 {
		t.Errorf("global counter: Pinky left at %d, want 7", gPinky)
	}
	if gInky != 17 {
		t.Errorf("global counter: Inky left at %d, want 17", gInky)
	}
	if gClyde != 32 {
		t.Errorf("global counter: Clyde left at %d, want 32", gClyde)
	}
}

func TestProbeFrightenedDuration(t *testing.T) {
	g := toGameplay(t)
	g.Play.Pacman.Actor.Pos = I2(1*8+4, 6*8+4) // on the pill tile
	setInput(g, DirLeft)
	frightStart := -1
	for i := 0; i < 60; i++ {
		g.Tick()
		if g.Play.Ghost[0].State == GhostStateFrightened {
			frightStart = int(g.Timing.Tick)
			break
		}
	}
	if frightStart < 0 {
		t.Fatal("pill did not frighten Blinky")
	}
	// park Pacman far away in the bottom right corner area
	g.Play.Pacman.Actor.Pos = I2(26*8+4, 32*8+4)
	leftAt := -1
	for i := 0; i < 500; i++ {
		g.Tick()
		if g.Play.Ghost[0].State != GhostStateFrightened {
			leftAt = int(g.Timing.Tick) - frightStart
			break
		}
	}
	if leftAt != 360 {
		t.Errorf("frightened lasted %d ticks, want 360", leftAt)
	}
}

func TestProbeGhostScores(t *testing.T) {
	g := toGameplay(t)
	g.Play.Pacman.Actor.Pos = I2(1*8+4, 6*8+4)
	setInput(g, DirLeft)
	for i := 0; i < 60; i++ {
		g.Tick()
		if g.Play.Ghost[0].Frightened.Tick != DisabledTicks &&
			g.Play.Ghost[0].Frightened.Before(g.Timing.Tick, 10) {
			break
		}
	}
	var deltas []int
	for gi := 0; gi < 4; gi++ {
		ghost := &g.Play.Ghost[gi]
		if ghost.State == GhostStateEyes || ghost.State == GhostStateEnterHouse {
			continue
		}
		ghost.State = GhostStateFrightened
		ghost.Frightened.Start(g.Timing.Tick)
		ghost.Actor.Pos = g.Play.Pacman.Actor.Pos
		s0 := int(g.Play.Score)
		for i := 0; i < 30; i++ {
			g.Tick()
			if g.Play.Freeze.Has(FreezeEatGhost) {
				break
			}
		}
		deltas = append(deltas, int(g.Play.Score)-s0)
		// wait out the eat-ghost freeze
		for i := 0; i < 80; i++ {
			g.Tick()
			if !g.Play.Freeze.Has(FreezeEatGhost) {
				break
			}
		}
	}
	want := []int{20, 40, 80, 160}
	if len(deltas) != len(want) {
		t.Fatalf("ghost score deltas = %v, want %v", deltas, want)
	}
	for i := range want {
		if deltas[i] != want[i] {
			t.Fatalf("ghost score deltas = %v, want %v", deltas, want)
		}
	}
}
