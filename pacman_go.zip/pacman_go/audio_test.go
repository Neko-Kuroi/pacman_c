package main

import "testing"

// The Synth's sample generation is verified without an audio device:
// silence stays silent, a started dump sound produces samples and
// advances, and generation is deterministic for a fixed state.

func TestPreludeDescDecode(t *testing.T) {
	g := NewGame()
	g.sndStart(0, sndPrelude)
	snd := g.Audio.Sound[0]
	if snd.Stride != 2 || snd.NumTicks != 245 {
		t.Errorf("prelude: stride=%d numTicks=%d, want 2/245", snd.Stride, snd.NumTicks)
	}
	if snd.Flags != SoundVoice0|SoundVoice1 {
		t.Errorf("prelude flags = %v, want voices 0+1", snd.Flags)
	}
	g.sndStart(2, sndDead)
	snd = g.Audio.Sound[2]
	if snd.Stride != 1 || snd.NumTicks != 90 {
		t.Errorf("dead: stride=%d numTicks=%d, want 1/90", snd.Stride, snd.NumTicks)
	}
}

func TestSynthSilenceAndSignal(t *testing.T) {
	g := NewGame()
	s := NewSynth(g)
	buf := make([]byte, SamplesPerTick*bytesPerSample)

	// no voices active: pure silence
	if _, err := s.Read(buf); err != nil {
		t.Fatal(err)
	}
	for i, b := range buf {
		if b != 0 {
			t.Fatalf("silence broken at byte %d: %d", i, b)
		}
	}

	// start the prelude (a register dump): tick the sound state so
	// the registers load, then the synth must produce a signal
	g.sndStart(0, sndPrelude)
	for i := 0; i < 30; i++ {
		g.sndTick()
	}
	nonzero := 0
	for chunk := 0; chunk < 10; chunk++ {
		if _, err := s.Read(buf); err != nil {
			t.Fatal(err)
		}
		for _, b := range buf {
			if b != 0 {
				nonzero++
			}
		}
	}
	if nonzero == 0 {
		t.Error("prelude produced no samples")
	}

	// stereo channels must be identical (mono duplicated, SPEC H3)
	if _, err := s.Read(buf); err != nil {
		t.Fatal(err)
	}
	for i := 0; i+4 <= len(buf); i += 4 {
		if buf[i] != buf[i+2] || buf[i+1] != buf[i+3] {
			t.Fatalf("stereo mismatch at byte %d", i)
		}
	}
}

func TestSynthDeterministic(t *testing.T) {
	gen := func() []byte {
		g := NewGame()
		s := NewSynth(g)
		g.sndStart(1, sndWeeooh)
		for i := 0; i < 10; i++ {
			g.sndTick()
		}
		buf := make([]byte, SamplesPerTick*bytesPerSample*4)
		if _, err := s.Read(buf); err != nil {
			t.Fatal(err)
		}
		return buf
	}
	a, b := gen(), gen()
	for i := range a {
		if a[i] != b[i] {
			t.Fatalf("synth output differs at byte %d", i)
		}
	}
}
