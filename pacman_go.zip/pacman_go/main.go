// main.go -- entry point and ebiten wiring.
// Corresponds to pacman.c lines 716-825 (sokol_main and callbacks),
// with the sokol accumulator replaced by Ebitengine's fixed TPS
// (SPEC H1/H2): one Update is one tick.
package main

import (
	"fmt"
	"os"
	"strconv"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/audio"
)

// app is the ebiten game object. The game logic lives in Game; the
// renderer, input reader and synth are attached here so the logic
// files never import ebiten.
type app struct {
	game     *Game
	renderer *Renderer
	reader   *InputReader
	synth    *Synth
	player   *audio.Player

	frames      int
	smokeFrames int  // >0: exit after this many updates (headless smoke)
	smokePlay   bool // smoke: press "any key" at frame 120 to start a game
}

func (a *app) Update() error {
	if a.reader != nil {
		a.reader.Read(&a.game.Input)
	}
	if a.smokePlay && a.frames == 120 {
		a.game.Input.Anykey = true
	}
	a.game.Tick()
	a.game.Input.Anykey = false
	a.frames++
	if a.smokeFrames > 0 && a.frames >= a.smokeFrames {
		fmt.Printf("smoke: %d frames done, scene=%v score=%d tick=%d\n",
			a.frames, a.game.Scene, a.game.Play.Score, a.game.Timing.Tick)
		return ebiten.Termination
	}
	return nil
}

func (a *app) Draw(screen *ebiten.Image) {
	a.renderer.Draw(screen)
}

func (a *app) Layout(outsideWidth, outsideHeight int) (int, int) {
	return DisplayPixelsX, DisplayPixelsY
}

// setupAudio attaches the synth to an Ebitengine audio player.
// Audio is optional (Phase 0 finding): creating a player initializes
// the audio driver, and on a machine without an audio device that
// error makes RunGame return immediately. Set PACMAN_AUDIO=off to
// skip audio entirely on such machines.
func setupAudio(a *app) {
	if os.Getenv("PACMAN_AUDIO") == "off" {
		return
	}
	a.synth = NewSynth(a.game)
	ctx := audio.NewContext(SampleRate)
	player, err := ctx.NewPlayer(a.synth)
	if err != nil {
		fmt.Fprintln(os.Stderr, "audio unavailable, continuing silently:", err)
		a.synth = nil
		return
	}
	a.player = player
	player.Play()
}

func main() {
	a := &app{game: NewGame()}
	a.renderer = newRenderer(a.game)
	a.reader = &InputReader{}
	setupAudio(a)
	if v := os.Getenv("PACMAN_SMOKE_FRAMES"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			a.smokeFrames = n
		}
	}
	a.smokePlay = os.Getenv("PACMAN_SMOKE_PLAY") != ""

	ebiten.SetTPS(60)
	ebiten.SetWindowSize(DisplayPixelsX*2, DisplayPixelsY*2)
	ebiten.SetWindowTitle("pacman.c")
	ebiten.SetWindowResizingMode(ebiten.WindowResizingModeEnabled)
	if err := ebiten.RunGame(a); err != nil && err != ebiten.Termination {
		fmt.Fprintln(os.Stderr, err)
		if a.player != nil {
			fmt.Fprintln(os.Stderr,
				"hint: if this is the audio initialization error, "+
					"this machine may have no audio device; "+
					"try PACMAN_AUDIO=off")
		}
		os.Exit(1)
	}
}
