# pacman.c の Go 移植 ― 設計スケッチ（仮定の検討）

（仕様としての正は `SPEC.md` です。この文書は
設計の背景とコードスケッチを置く場所です。）

floooh/pacman.c（4,303行）を、ゲームのデザインとルールは
そのままに、プログラミングの構成は C から離れて
「Go らしく」書いたらどうなるか、という仮定の検討メモです。
実装の計画書ではなく、設計のスケッチです。

前提:

- ルール、数値、表、ティックの仕組みは原典どおり
- 土台は sokol ではなく Go の流儀のものを使う
- 比較の基準は C 版（コード部分 約3,256行）と
  Nim 版（コード部分 2,226行、シェーダー込み）

---

## 1. 土台の選択

| 候補 | 性質 | 評価 |
|---|---|---|
| **Ebitengine** | Go 製の2Dエンジン。cgo なしが基本、WASM は Go 標準の出力 | 「Go らしく」の本命。入り口がインターフェース実装になる |
| go-sdl2 | SDL2 のバインディング（cgo） | C 版の構造にいちばん近いが、それは「Go らしく」から遠い |
| raylib-go | raylib のバインディング（cgo） | 手軽だが、やはり C の道具を持ち込む形 |

このスケッチは Ebitengine を前提にします。理由は2つ。
1つは、入り口の形が Go の流儀（インターフェースを満たす
型を作る）になること。もう1つは、ビルドと配布が
Go の道具だけで完結することです。

なお、この VM には Go 1.22.2 が入っています。
`//go:embed` もジェネリクスも使える世代です。

## 2. 入り口と全体の形

Ebitengine では、`Update` / `Draw` / `Layout` の
3メソッドを持つ型を渡します。C の「コールバック登録」と
似ていますが、状態は大域変数ではなく、その型の中に
持ちます。

```go
package main

// Game はゲーム全体の状態と振る舞いを持つ型。
// C の大域 state が、ここに引っ越してくる。
type Game struct {
    scene Scene // INTRO / GAME
    tick  uint32

    play   PlayState
    input  Input
    synth  *Synth
    render *Renderer
}

func (g *Game) Update() error {
    g.readInput()
    // Ebitengine は Update を TPS（既定60）で呼ぶので、
    // C の「先に払って後で精算する」蓄積方式は
    // 「1回の Update = 1ティック」に姿を変える
    g.tick++
    switch g.scene {
    case SceneIntro:
        g.introTick()
    case SceneGame:
        g.gameTick()
    }
    g.synth.Tick(g)
    return nil
}

func (g *Game) Draw(screen *ebiten.Image)          { g.render.Draw(g, screen) }
func (g *Game) Layout(w, h int) (int, int)         { return 448, 576 }

func main() {
    if err := ebiten.RunGame(NewGame()); err != nil {
        log.Fatal(err)
    }
}
```

ポイント:

- `game_tick(&state)` のような自由関数は、
  `func (g *Game) gameTick()` のメソッドになる
- エラーは `Update() error` の戻り値で外に出る。
  C の「失敗しない前提」から、Go の「失敗を返す前提」へ
- letterbox（画面の中央寄せと拡縮）は Ebitengine の
  Layout の仕組みに任せるので、Nim 版にあった
  ビューポート計算の区画はほぼ消える

## 3. パッケージとファイル構成

Go では、1パッケージに複数ファイルを置くのが普通です。
区画は C 版教科書の分け方をそのまま写し、ファイル名だけ
Go の流儀（小文字）にします。

```
pacman_go/
  main.go      入り口と Game 型（C の 716〜825）
  state.go     定数・列挙型・状態・表（C の 142〜678）
  timing.go    Trigger と入力（C の 826〜943）
  geom.go      幾何と盤面の問い合わせ（C の 1230〜1361）
  ghost.go     ゴースト（C の 1750〜2087）
  rules.go     ルール（C の 1377〜1583、2089〜2403）
  render.go    描画（C の 993〜1229、1584〜1732、2404〜3124）
  audio.go     音（C の 3125〜3388）
  data.go      ROM データ（生成、C の 3389〜4303）
  ghost_test.go、rules_test.go など テスト
```

パッケージを細かく割る（internal/game など）ことも
できますが、この規模では1パッケージが素直です。
公開・非公開は、名前の先頭の大文字・小文字で決まります
（Nim の `*`、C の `static` の有無にあたる区別）。

## 4. 要所のコードスケッチ

### 4.1 Trigger ― 小さな型とメソッド

```go
// Trigger は「未来のティック」を1つ覚える型（C の trigger_t）。
type Trigger struct{ tick uint32 }

const triggerDisabled = ^uint32(0) // C の 0xFFFFFFFF

func (t *Trigger) Start(now uint32)           { t.tick = now + 1 } // +1 の約束はそのまま
func (t *Trigger) After(now uint32, n uint32) { t.tick = now + n }
func (t *Trigger) Disable()                   { t.tick = triggerDisabled }
func (t Trigger) Due(now uint32) bool         { return now >= t.tick }
func (t Trigger) Since(now uint32) uint32     { return now - t.tick }
```

C では `start(&state.game.ready_started)` のように
住所を渡していましたが、Go ではフィールドそのものが
メソッドを持ちます。呼び出しは
`g.play.readyStarted.Start(g.tick)` の形になります。

### 4.2 Freeze ― ビットフラグにメソッドを持たせる

Go に集合型はないので、Nim の `set[FreezeType]` は
そのまま写せません。Go の流儀は、ビットフラグの型に
名前とメソッドを与えることです。

```go
type Freeze uint8

const (
    FreezePrelude Freeze = 1 << iota
    FreezeReady
    FreezeEatGhost
    FreezeDead
    FreezeWon
)

func (f Freeze) Has(o Freeze) bool { return f&o != 0 }
func (f *Freeze) Add(o Freeze)     { *f |= o }
func (f *Freeze) Clear(o Freeze)   { *f &^= o } // C の &= ~ は Go では &^=
func (f Freeze) Empty() bool       { return f == 0 }
```

使う側は `if g.play.freeze.Empty() { g.updateActors() }`、
`g.play.freeze.Add(FreezeWon)` のように、出来事の言葉で
読めます。中身は C と同じビット演算でも、外側の顔は
Nim の集合型に近づきます。

### 4.3 Int2 ― 演算子ではなくメソッドの連鎖

Go には演算子の自作がないので、Inky の狙いは
メソッドの連鎖になります。題材（Nim 版 ghost.nim
101〜105行）の形をそのまま写すと、こうなります。

```go
type Int2 struct{ X, Y int16 }

func (v Int2) Add(o Int2) Int2    { return Int2{v.X + o.X, v.Y + o.Y} }
func (v Int2) Sub(o Int2) Int2    { return Int2{v.X - o.X, v.Y - o.Y} }
func (v Int2) Scale(s int16) Int2 { return Int2{v.X * s, v.Y * s} }

// Inky: パックマンの2マス先を支点に、Blinky の位置を反転する
p := pacTile.Add(dirVec(pac.Dir).Scale(2))
d := p.Sub(blinkyTile)
target := blinkyTile.Add(d.Scale(2))
```

C の `add_i2` の入れ子よりは読みやすく、Nim の
`blinkyPos + d * 2` よりは少し長くなります。
ここは Go が素直に負ける場所で、無理に隠しません。

### 4.4 音 ― io.Reader として引っ張られる

sokol-audio は「作ったサンプルを押し出す」push 型
でした。Go の音は「読み手に引っ張られる」pull 型が
標準で、合成器は `Read` を実装する型になります。

```go
// Synth は3つの声を持つ音源（C の音源再現そのまま）。
// io.Reader を満たすので、Ebitengine の音の受け口にそのまま渡せる。
type Synth struct {
    voices [3]Voice
    sounds [3]Sound
    // ティック単位で合成したサンプルの蓄え
    pending []byte
}

func (s *Synth) Read(p []byte) (int, error) {
    for len(s.pending) < len(p) {
        s.sampleTick() // 1ティック分を合成して pending に足す
    }
    n := copy(p, s.pending)
    s.pending = s.pending[n:]
    return n, nil
}
```

効果音の開始・停止（`Start(slot, desc)`）や、ダンプ
再生と手続き型の2種類の作り方は C のままです。
変わるのは外側の顔だけで、「音を作る側が主導権を
持つ」から「再生する側が主導権を持つ」に替わります。
サンプルレートの違い（原典の時計と再生側の 44.1kHz
など）は、Synth の内側で吸収します。

### 4.5 テスト ― 本体の隣に住む

C にはテストがなく、Nim 版では検証プログラムを
別に作りました。Go では、テストは同じパッケージの
`*_test.go` に置くのが文化で、表駆動が標準形です。
再点検のプローブは、最初からこの形にできます。

```go
func TestHouseDotCounters(t *testing.T) {
    tests := []struct {
        name  string
        ghost GhostType
        dots  int // この数だけドットを食べさせる
        want  GhostState
    }{
        {"Inkyは29ドットでは出ない", GhostInky, 29, GhostHouse},
        {"Inkyは30ドットで家を出る", GhostInky, 30, GhostLeaveHouse},
        {"Clydeは90ドットで家を出る", GhostClyde, 90, GhostLeaveHouse},
    }
    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            g := newTestGame()
            g.eatDots(tt.dots)
            if got := g.ghost(tt.ghost).State; got != tt.want {
                t.Errorf("dots=%d: got %v, want %v", tt.dots, got, tt.want)
            }
        })
    }
}
```

（スケッチです。実際のテストは、家のカウンタの
仕組みに合わせて組み立てます。）

## 5. 描画の作り方 ― 3案

C の描画は「タイル番号と色コードの表（VRAM 相当）を
書き換え、GPU 側で2段デコードする」方式でした。
Ebitengine では画像が基本単位なので、作り直しが要ります。

| 案 | 中身 | 長短 |
|---|---|---|
| A. 表をそのまま持ち、画像に焼き直す | VRAM 相当の配列を保ち、変わったマスだけオフスクリーン画像に描き直して、それを画面に出す | C の工夫（差分更新）が生きる。構造がいちばん C に近い |
| B. タイル×色を先に焼く | 起動時に「タイル絵×色の組み合わせ」を全部画像化しておき、毎フレーム並べる | 毎フレーム 28×36 回の描画。Ebitengine では十分速い。コードは単純 |
| C. スプライトだけ分ける | 盤面は B、キャラクターはアトラスからの切り出しで毎フレーム描く | いちばん Ebitengine らしい形。盤面の色替え（青フラッシュなど）は盤面側の再焼きで受ける |

おすすめは A と C の中間で、「盤面は表＋差分更新（A）、
キャラクターは毎フレーム描画（C）」です。理由は、
面クリア時の盤面フラッシュや色の反転が「表の書き換え」
で表現されている原典の設計を、そのまま受けられる
からです。

## 6. 行数の見積もり（推定）

コード部分だけの、区画ごとの推定です。実測ではなく、
増える理由と減る理由からの見積もりとして読んでください。

| 区画 | C | Nim | Go（推定） | 主な増減の理由 |
|---|---|---|---|---|
| 状態・定数・表 | 約540 | 376 | 約430 | 構造体定義は C より短いが、Nim よりは型を書く分だけ増える |
| 時間・入力 | 約165 | 85 | 約110 | メソッド化で呼び出しは短く、定義は少し増える |
| 幾何 | 約130 | 96 | 約120 | 演算子が作れずメソッドになる分、Nim より増える |
| ゴースト | 約340 | 193 | 約240 | 同上。case は同程度 |
| ルール | 約540 | 367 | 約440 | エラーを返す場所は少ないが、明示的な分岐が増える |
| 描画 | 約1,110 | 818 | 約700 | letterbox が消える。シェーダーは事前焼きに替わり短くなる |
| 音 | 約330 | 212 | 約260 | Read の受け口の分だけ増える |
| 入り口 | 約110 | 79 | 約90 | 同程度 |
| **合計（コード部分）** | **約3,256** | **2,226** | **約2,390** | |

見込みとしては、Nim より 1割弱多く、C より 25% ほど
少ない、というあたりです。あなたの amezo 移植の実測
（Go は Python や Lisp より増える側だった）とも、
傾向は合います。ROM データとテストは、この見積もりの
外です（データは持ち運び方で大きく変わり、テストは
C に存在しなかった分が純増になります）。

## 7. 変わらないもの、未決のもの

変わらないもの:

- 固定ティックとトリガー（+1 の約束を含む）
- レベル仕様、速度のパターン、家のカウンタ、全体カウンタ
- ゴーストの思考（目標＋貪欲）、散らばり/追跡の時刻表
- 効果音の2種類の作り方とスロット配分
- 決定性（乱数は xorshift を小さな型で持ち運ぶ）

未決のもの（実装するなら決める必要があるもの）:

- 描画方式（5 の A/B/C）
- 音のサンプルレート変換を Synth の内側のどこで受けるか
- ROM データの持ち方（`//go:embed` のバイナリか、
  生成した Go の配列か）
- パッケージ分割（1パッケージか、internal を使うか）

並行処理（goroutine とチャネル）は、この設計では
使いません。ティックの決定性が大事なゲームでは、
シミュレーションを単一スレッドに保つのが Go でも
正解です。

## 8. 入力の設計 ― キーボード、タッチ、ゲームパッド

対応する入力機器は3種類です。設計の要点は、C 版が
`input_dir` で既にやっていた分離を、そのまま広げる
ことです。つまり、**機器ごとに「意図」を読み取り、
最後は1つの `Input` に合流させる**。ルール側は
`Input` だけを見て、どの機器から来たかを知りません。

| 機器 | 読む API（Ebitengine） | 意図への直し方 |
|---|---|---|
| キーボード | `IsKeyPressed` | 矢印キーと WASD（原典どおり両方）。押している間が意図 |
| ゲームパッド | `IsStandardGamepadButtonPressed`、`StandardGamepadAxisValue` | 十字キーと左スティック。スティックはデッドゾーン 0.5 を超えたら、大きい方の軸を採用 |
| タッチ | `AppendJustPressedTouchIDs`、`TouchPosition` | スワイプ。指の移動が閾値（24論理ピクセル、約3タイル）を超えたら、その方向を「ラッチ」する |

機器ごとの性格の違いは、タッチだけにあります。
キーボードとパッドは「押している間」が意図ですが、
スワイプは一瞬の動作なので、**決めた方向を保持
（ラッチ）して、次のスワイプまで効かせ続ける**
形にします。これはモバイル版 Pac-Man の定番の
操作感でもあります。仮想パッドは、盤面を隠すのと
誤タッチの問題があるので採りません。

合流の規則は単純です。

1. このティックに「押されている」方向（キーボードと
   パッド）があれば、原典の優先順（上 > 下 > 右 > 左）で
   1つに決める
2. なければ、タッチのラッチを使う
3. それもなければ、現在の方向のまま（原典の
   `default_dir` と同じ）

ゲームの開始（イントロでの「何か押して」）は、
3機器とも対象です。キーの押し下げ、パッドの
ボタンの押し下げ、画面のタップ、のどれでも
始まります。

```go
// Input は入力の合流点。ルール側はこの型だけを見る。
type Input struct {
    Dir    Dir  // このティックに向けたい方向（解決済み）
    AnyKey bool // 何か押された（イントロの開始用）
}

// InputReader は3機器を読んで Input に直す係。
type InputReader struct {
    pads        []ebiten.GamepadID
    touching    bool
    touchID     ebiten.TouchID
    swipeOrigin image.Point
    latched     Dir
    hasLatch    bool
}

const (
    stickDeadzone  = 0.5
    swipeThreshold = 24 // 論理ピクセル（約3タイル分）
)

func absInt(v int) int {
    if v < 0 {
        return -v
    }
    return v
}

func (r *InputReader) Read(current Dir) Input {
    var held [4]bool // 添字は Dir の値そのもの
    any := false

    // キーボード（矢印と WASD）
    if ebiten.IsKeyPressed(ebiten.KeyArrowUp) || ebiten.IsKeyPressed(ebiten.KeyW) {
        held[DirUp] = true
    }
    if ebiten.IsKeyPressed(ebiten.KeyArrowDown) || ebiten.IsKeyPressed(ebiten.KeyS) {
        held[DirDown] = true
    }
    if ebiten.IsKeyPressed(ebiten.KeyArrowRight) || ebiten.IsKeyPressed(ebiten.KeyD) {
        held[DirRight] = true
    }
    if ebiten.IsKeyPressed(ebiten.KeyArrowLeft) || ebiten.IsKeyPressed(ebiten.KeyA) {
        held[DirLeft] = true
    }
    if len(inpututil.AppendJustPressedKeys(nil)) > 0 {
        any = true // このティックで新しく押されたキーがあれば開始の合図
    }

    // ゲームパッド（最初の1つだけ使う。1人プレイのため）
    r.pads = ebiten.AppendGamepadIDs(r.pads[:0])
    if len(r.pads) > 0 {
        id := r.pads[0]
        if ebiten.IsStandardGamepadButtonPressed(id, ebiten.StandardGamepadButtonLeftTop) {
            held[DirUp] = true
        }
        if ebiten.IsStandardGamepadButtonPressed(id, ebiten.StandardGamepadButtonLeftBottom) {
            held[DirDown] = true
        }
        if ebiten.IsStandardGamepadButtonPressed(id, ebiten.StandardGamepadButtonLeftLeft) {
            held[DirLeft] = true
        }
        if ebiten.IsStandardGamepadButtonPressed(id, ebiten.StandardGamepadButtonLeftRight) {
            held[DirRight] = true
        }
        x := ebiten.StandardGamepadAxisValue(id, ebiten.StandardGamepadAxisLeftStickHorizontal)
        y := ebiten.StandardGamepadAxisValue(id, ebiten.StandardGamepadAxisLeftStickVertical)
        if math.Abs(x) > math.Abs(y) {
            if x < -stickDeadzone {
                held[DirLeft] = true
            } else if x > stickDeadzone {
                held[DirRight] = true
            }
        } else {
            if y < -stickDeadzone {
                held[DirUp] = true
            } else if y > stickDeadzone {
                held[DirDown] = true
            }
        }
    }

    // タッチ（スワイプでラッチを更新する）
    if ids := inpututil.AppendJustPressedTouchIDs(nil); len(ids) > 0 {
        r.touchID = ids[0]
        r.touching = true
        x, y := ebiten.TouchPosition(r.touchID)
        r.swipeOrigin = image.Pt(x, y)
        any = true // タップは開始の合図
    }
    if r.touching {
        x, y := ebiten.TouchPosition(r.touchID)
        if x == 0 && y == 0 {
            r.touching = false // 指が離れた（位置が (0,0) に戻る）
        } else {
            dx, dy := x-r.swipeOrigin.X, y-r.swipeOrigin.Y
            if max(absInt(dx), absInt(dy)) >= swipeThreshold {
                if absInt(dx) > absInt(dy) {
                    if dx < 0 {
                        r.latched = DirLeft
                    } else {
                        r.latched = DirRight
                    }
                } else {
                    if dy < 0 {
                        r.latched = DirUp
                    } else {
                        r.latched = DirDown
                    }
                }
                r.hasLatch = true
                r.swipeOrigin = image.Pt(x, y) // 離さず続けて曲がれるよう起点を進める
            }
        }
    }

    // 解決: 押されている方向を原典の優先順で。
    // なければラッチ、それもなければ現在の方向。
    for _, d := range [4]Dir{DirUp, DirDown, DirRight, DirLeft} {
        if held[d] {
            return Input{Dir: d, AnyKey: any}
        }
    }
    if r.hasLatch {
        return Input{Dir: r.latched, AnyKey: any}
    }
    return Input{Dir: current, AnyKey: any}
}
```

注記:

- この節のコード（`InputReader.Read`）は、実際の
  Ebitengine v2 を相手にコンパイルが通ることを
  確認済みです（API 名と型の照合。動作確認では
  ありません）
- 解決の優先順は原典どおり 上 > 下 > 右 > 左 です。
  `held` の添字は Dir の値そのものなので、優先順は
  解決側の列挙（`{DirUp, DirDown, DirRight, DirLeft}`）で
  明示します
- パッドの AnyKey は、標準レイアウトのボタンを
  一巡して「新しく押されたものがあるか」で判定する
  想定です（スケッチでは省略）
- マウス操作には対応しません（決定）。
  デスクトップの入力はキーボードとゲームパッド
  のみです。タッチのスワイプ判定は、実機の
  タッチでのみ効きます
- 入力の有効・無効（プレリュード中は受け付けない等）は
  原典どおりルール側の `enabled` で扱い、Reader は
  常に読み続けます
- 振動（`VibrateGamepad` / `Vibrate`）は
  入れません（決定）。原典にない演出であり、
  対応機器でも使わないことにしました
