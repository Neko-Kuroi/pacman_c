// input.go -- merge keyboard, gamepad and touch into the game's
// InputState (SPEC H8). The rules only ever see the resolved input;
// which device produced it is known only here.
//
//   - keyboard: arrow keys and WASD, held state is the intent
//   - gamepad: first pad, standard layout D-pad and left stick
//     (deadzone 0.5, the larger axis wins)
//   - touch: swipe with a latch -- the direction persists until the
//     next swipe; a tap counts as "any key"
//   - no mouse, no vibration (decided 2026-11-20)
//
// Held directions are resolved with the original's priority
// (up, down, right, left); the latched touch direction is used only
// when nothing is held. The F key toggles fullscreen, as in the
// original. Like the original's event callback, nothing is written
// while input is disabled.
package main

import (
	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/inpututil"
)

const (
	touchSwipeThreshold = 24 // logical pixels, about 3 tiles
	stickDeadzone       = 0.5
)

// InputReader holds the cross-tick input state (the touch latch and
// the active swipe).
type InputReader struct {
	latched  Dir
	hasLatch bool
	activeID ebiten.TouchID
	tracking bool
	swiped   bool
	originX  int
	originY  int
}

// Read polls the devices and writes the resolved input.
func (r *InputReader) Read(in *InputState) {
	if !in.Enabled {
		return
	}

	// fullscreen toggle (the original's F key handling)
	if inpututil.IsKeyJustPressed(ebiten.KeyF) {
		ebiten.SetFullscreen(!ebiten.IsFullscreen())
	}

	// --- held directions: keyboard ---
	up := ebiten.IsKeyPressed(ebiten.KeyArrowUp) || ebiten.IsKeyPressed(ebiten.KeyW)
	down := ebiten.IsKeyPressed(ebiten.KeyArrowDown) || ebiten.IsKeyPressed(ebiten.KeyS)
	right := ebiten.IsKeyPressed(ebiten.KeyArrowRight) || ebiten.IsKeyPressed(ebiten.KeyD)
	left := ebiten.IsKeyPressed(ebiten.KeyArrowLeft) || ebiten.IsKeyPressed(ebiten.KeyA)

	// --- held directions: gamepad (first pad, standard layout) ---
	padAny := false
	var ids []ebiten.GamepadID
	ids = ebiten.AppendGamepadIDs(ids)
	if len(ids) > 0 {
		id := ids[0]
		if ebiten.IsStandardGamepadLayoutAvailable(id) {
			up = up || ebiten.IsStandardGamepadButtonPressed(id, ebiten.StandardGamepadButtonLeftTop)
			down = down || ebiten.IsStandardGamepadButtonPressed(id, ebiten.StandardGamepadButtonLeftBottom)
			right = right || ebiten.IsStandardGamepadButtonPressed(id, ebiten.StandardGamepadButtonLeftRight)
			left = left || ebiten.IsStandardGamepadButtonPressed(id, ebiten.StandardGamepadButtonLeftLeft)
			x := ebiten.StandardGamepadAxisValue(id, ebiten.StandardGamepadAxisLeftStickHorizontal)
			y := ebiten.StandardGamepadAxisValue(id, ebiten.StandardGamepadAxisLeftStickVertical)
			if absF(x) > absF(y) {
				if x < -stickDeadzone {
					left = true
				} else if x > stickDeadzone {
					right = true
				}
			} else {
				if y < -stickDeadzone {
					up = true
				} else if y > stickDeadzone {
					down = true
				}
			}
			// any standard button just pressed counts as "any key"
			for b := ebiten.StandardGamepadButton(0); b < ebiten.StandardGamepadButtonMax; b++ {
				if inpututil.IsStandardGamepadButtonJustPressed(id, b) {
					padAny = true
					break
				}
			}
		}
	}

	// --- touch: swipe with latch, tap is "any key" ---
	tap := false
	var justIDs []ebiten.TouchID
	justIDs = inpututil.AppendJustPressedTouchIDs(justIDs)
	for _, id := range justIDs {
		if !r.tracking {
			r.tracking = true
			r.swiped = false
			r.activeID = id
			r.originX, r.originY = ebiten.TouchPosition(id)
		}
	}
	if r.tracking {
		if inpututil.IsTouchJustReleased(r.activeID) {
			if !r.swiped {
				tap = true
			}
			r.tracking = false
		} else {
			x, y := ebiten.TouchPosition(r.activeID)
			dx, dy := x-r.originX, y-r.originY
			if max(abs(dx), abs(dy)) >= touchSwipeThreshold {
				if abs(dx) > abs(dy) {
					if dx > 0 {
						r.latched = DirRight
					} else {
						r.latched = DirLeft
					}
				} else {
					if dy > 0 {
						r.latched = DirDown
					} else {
						r.latched = DirUp
					}
				}
				r.hasLatch = true
				r.swiped = true
				// advance the origin so a long swipe keeps
				// producing directions
				r.originX, r.originY = x, y
			}
		}
	}

	// --- resolve: held first (original priority), then the latch ---
	if !(up || down || right || left) && r.hasLatch {
		switch r.latched {
		case DirUp:
			up = true
		case DirDown:
			down = true
		case DirRight:
			right = true
		case DirLeft:
			left = true
		}
	}
	in.Up, in.Down, in.Right, in.Left = up, down, right, left
	in.Esc = ebiten.IsKeyPressed(ebiten.KeyEscape)

	// --- "any key": key edges, pad button edges, taps ---
	var keys []ebiten.Key
	keys = inpututil.AppendJustPressedKeys(keys)
	in.Anykey = len(keys) > 0 || padAny || tap
}

func abs(v int) int {
	if v < 0 {
		return -v
	}
	return v
}

func absF(v float64) float64 {
	if v < 0 {
		return -v
	}
	return v
}
