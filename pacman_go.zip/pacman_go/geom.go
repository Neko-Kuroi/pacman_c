// geom.go -- geometry and playfield queries.
// Corresponds to pacman.c lines 988-991 and 1230-1361.
//
// Go's % and / truncate toward zero just like C, so the Nim version's
// cmod helper is not needed here; negative positions in the teleport
// tunnel behave identically by construction.
package main

// Add returns v + o.
func (v Int2) Add(o Int2) Int2 { return I2(v.X+o.X, v.Y+o.Y) }

// Sub returns v - o.
func (v Int2) Sub(o Int2) Int2 { return I2(v.X-o.X, v.Y-o.Y) }

// Scale returns v * s.
func (v Int2) Scale(s int16) Int2 { return I2(v.X*s, v.Y*s) }

// SquaredDistance returns the squared distance between v and o.
func (v Int2) SquaredDistance(o Int2) int32 {
	dx := int32(o.X - v.X)
	dy := int32(o.Y - v.Y)
	return dx*dx + dy*dy
}

// NearEqual reports whether v and o are within tolerance on both axes.
func (v Int2) NearEqual(o Int2, tolerance int16) bool {
	return abs16(o.X-v.X) <= tolerance && abs16(o.Y-v.Y) <= tolerance
}

func abs16(v int16) int16 {
	if v < 0 {
		return -v
	}
	return v
}

// ActorToSpritePos converts an actor position to a sprite position.
func (v Int2) ActorToSpritePos() Int2 {
	return I2(v.X-SpriteWidth/2, v.Y-SpriteHeight/2)
}

// distToTileMid returns the distance from a pixel position to the
// middle of its tile (pacman.c 988-991).
func distToTileMid(pos Int2) Int2 {
	return I2(TileWidth/2-pos.X%TileWidth, TileHeight/2-pos.Y%TileHeight)
}

// pixelToTilePos converts a pixel position to a tile position.
func pixelToTilePos(pixPos Int2) Int2 {
	return I2(pixPos.X/TileWidth, pixPos.Y/TileHeight)
}

// clampedTilePos clamps a tile position to valid playfield coords.
func clampedTilePos(tilePos Int2) Int2 {
	r := tilePos
	if r.X < 0 {
		r.X = 0
	} else if r.X >= DisplayTilesX {
		r.X = DisplayTilesX - 1
	}
	if r.Y < 3 {
		r.Y = 3
	} else if r.Y >= DisplayTilesY-2 {
		r.Y = DisplayTilesY - 3
	}
	return r
}

var dirMap = [4]Int2{I2(+1, 0), I2(0, +1), I2(-1, 0), I2(0, -1)}

// dirToVec converts a direction to a unit vector.
func dirToVec(dir Dir) Int2 {
	if dir < DirRight || dir >= NumDirs {
		panic("dirToVec: invalid dir")
	}
	return dirMap[dir]
}

// reverseDir returns the opposite direction.
func reverseDir(dir Dir) Dir {
	switch dir {
	case DirRight:
		return DirLeft
	case DirDown:
		return DirUp
	case DirLeft:
		return DirRight
	default:
		return DirDown
	}
}

// tileCodeAt returns the tile code at a tile position.
func (g *Game) tileCodeAt(tilePos Int2) uint8 {
	if tilePos.X < 0 || tilePos.X >= DisplayTilesX ||
		tilePos.Y < 0 || tilePos.Y >= DisplayTilesY {
		panic("tileCodeAt: out of range")
	}
	return g.Gfx.VideoRAM[tilePos.Y][tilePos.X]
}

// isBlockingTile reports whether a tile blocks movement.
func (g *Game) isBlockingTile(tilePos Int2) bool {
	return g.tileCodeAt(tilePos) >= 0xC0
}

// isDot reports whether a tile holds a dot.
func (g *Game) isDot(tilePos Int2) bool { return g.tileCodeAt(tilePos) == TileDot }

// isPill reports whether a tile holds a power pill.
func (g *Game) isPill(tilePos Int2) bool { return g.tileCodeAt(tilePos) == TilePill }

// isTunnel reports whether a tile is in the teleport tunnel.
func isTunnel(tilePos Int2) bool {
	return tilePos.Y == 17 && (tilePos.X <= 5 || tilePos.X >= 22)
}

// isRedzone reports whether a tile forbids upward movement for ghosts.
func isRedzone(tilePos Int2) bool {
	return tilePos.X >= 11 && tilePos.X <= 16 && (tilePos.Y == 14 || tilePos.Y == 26)
}

// canMove tests whether movement from a pixel position in a wanted
// direction is possible (pacman.c 1304-1331).
func (g *Game) canMove(pos Int2, wantedDir Dir, allowCornering bool) bool {
	dirVec := dirToVec(wantedDir)
	distMid := distToTileMid(pos)
	var moveDistMid, perpDistMid int16
	if dirVec.Y != 0 {
		moveDistMid = distMid.Y
		perpDistMid = distMid.X
	} else {
		moveDistMid = distMid.X
		perpDistMid = distMid.Y
	}
	tilePos := pixelToTilePos(pos)
	checkPos := clampedTilePos(tilePos.Add(dirVec))
	blocked := g.isBlockingTile(checkPos)
	return !((!allowCornering && perpDistMid != 0) ||
		(blocked && moveDistMid == 0))
}

// move computes a new pixel position along a direction, without a
// blocking check (pacman.c 1334-1361).
func move(pos Int2, dir Dir, allowCornering bool) Int2 {
	dirVec := dirToVec(dir)
	r := pos.Add(dirVec)
	if allowCornering {
		distMid := distToTileMid(r)
		if dirVec.X != 0 {
			if distMid.Y < 0 {
				r.Y--
			} else if distMid.Y > 0 {
				r.Y++
			}
		} else if dirVec.Y != 0 {
			if distMid.X < 0 {
				r.X--
			} else if distMid.X > 0 {
				r.X++
			}
		}
	}
	if r.X < 0 {
		r.X = DisplayPixelsX - 1
	} else if r.X >= DisplayPixelsX {
		r.X = 0
	}
	return r
}
