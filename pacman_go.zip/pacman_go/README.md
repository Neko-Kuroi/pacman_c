# pacman-go ― pacman.c の Go 移植

floooh/pacman.c（C99、4,303行）を Go + Ebitengine へ
移植したもの。同一仕様でプログラミング言語を比べる
研究の一環で、C、Python、Nim に続く4つ目の実装。

- 仕様: `SPEC.md`（原典の踏襲範囲と、Go ではみ出す
  箇所 H1〜H9 の決定）
- 計画: `PLAN.md`
- 設計の背景: `DESIGN_SKETCH.md`
- 検証の記録: `REPORT.md`

## 動かし方

必要なもの: Go 1.27.4（`go.mod` で固定）、
Ebitengine v2.10.6（`go.sum` で固定）。

```
make build     # ./pacman-go ができる
./pacman-go
make test      # ヘッドレス検証とプローブを含む全テスト
make wasm      # pacman-go.wasm（ブラウザ用）
make check     # test + vet
make data      # data.go を pacman.c から再生成
```

操作:

- 移動: 矢印キー / WASD / ゲームパッド（十字キーと
  左スティック）/ タッチのスワイプ
- ゲーム開始: 何かキーを押す、パッドのボタンを押す、
  画面をタップ
- F キー: フルスクリーン切り替え
- マウス操作と振動はない（仕様書 H8 の決定）

音響装置のない環境では、環境変数で音を無効化する:

```
PACMAN_AUDIO=off ./pacman-go
```

（音の初期化に失敗すると Ebitengine の RunGame が
エラーを返して終了するため。Phase 0 の知見）

Xvfb などでの無人スモーク実行:

```
PACMAN_AUDIO=off PACMAN_SMOKE_FRAMES=600 ./pacman-go
PACMAN_AUDIO=off PACMAN_SMOKE_FRAMES=3600 PACMAN_SMOKE_PLAY=1 ./pacman-go
```

（`PACMAN_SMOKE_PLAY=1` で 120 フレーム目に開始キーを
押したことにして、ゲーム画面まで進める）

## 構成

1パッケージ（`package main`）、ファイルは C 版教科書の
区画に対応する。

| ファイル | 内容 | pacman.c の対応 |
|---|---|---|
| main.go | 入り口と Ebitengine の配線 | 716〜825 |
| state.go | 定数・列挙型・状態・表 | 142〜678 |
| timing.go | Trigger と時計、入力の語彙 | 826〜943 |
| geom.go | 幾何と盤面の問い合わせ | 988〜991、1230〜1361 |
| ghost.go | ゴーストの思考 | 1750〜2087 |
| rules.go | ルールと場面 | 1377〜1583、2089〜2403 |
| render.go | 描画（パレットを焼いた画像） | 993〜1229、1584〜1732、2404〜3124 |
| audio.go | 音（pull 型の合成器） | 638〜678、3125〜3388 |
| input.go | 入力3機器の合流（追加） | なし |
| data.go | ROM データ（生成） | 3389〜4303 |
| tools/extract.go | data.go の生成器 | ― |

ルール側（rules.go、ghost.go など）は Ebitengine に
依存せず、`Game.Tick()` を直接呼ぶヘッドレス検証が
テストに含まれている。
