package main

import "testing"

func TestROMDataCountsAndSums(t *testing.T) {
	cases := []struct {
		name string
		sum  uint64
		want uint64
	}{
		{"romTiles", sumU8(romTiles[:]), 267889},
		{"romSprites", sumU8(romSprites[:]), 227290},
		{"romHWColors", sumU8(romHWColors[:]), 1852},
		{"romPalette", sumU8(romPalette[:]), 589},
		{"romWavetable", sumU8(romWavetable[:]), 1856},
		{"sndDumpPrelude", sumU32(sndDumpPrelude[:]), 1523003578600},
		{"sndDumpDead", sumU32(sndDumpDead[:]), 275197360640},
	}
	for _, c := range cases {
		if c.sum != c.want {
			t.Errorf("%s: sum = %d, want %d", c.name, c.sum, c.want)
		}
	}
	if len(romTiles) != 4096 || len(romSprites) != 4096 || len(romHWColors) != 32 ||
		len(romPalette) != 256 || len(romWavetable) != 256 ||
		len(sndDumpPrelude) != 490 || len(sndDumpDead) != 90 {
		t.Error("array length mismatch")
	}
}

func sumU8(a []uint8) uint64 {
	var s uint64
	for _, v := range a {
		s += uint64(v)
	}
	return s
}

func sumU32(a []uint32) uint64 {
	var s uint64
	for _, v := range a {
		s += uint64(v)
	}
	return s
}
