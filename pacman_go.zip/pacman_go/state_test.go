package main

import "testing"

func TestLevelSpec(t *testing.T) {
	if ls := levelSpec(0); ls.BonusFruit != FruitCherries || ls.FrightTicks != 360 || ls.BonusScore != 10 {
		t.Errorf("round 0: got %+v", ls)
	}
	if ls := levelSpec(16); ls.FrightTicks != 1 {
		t.Errorf("round 16 fright: got %d, want 1", ls.FrightTicks)
	}
	// clamped to the last entry beyond the table
	if levelSpec(21) != levelSpec(20) || levelSpec(100) != levelSpec(20) {
		t.Error("levelSpec must clamp to the last entry")
	}
	if ls := levelSpec(12); ls.BonusFruit != FruitKey || ls.BonusScore != 500 {
		t.Errorf("round 12: got %+v", ls)
	}
}

func TestFreezeMethods(t *testing.T) {
	var f Freeze
	if !f.Empty() {
		t.Fatal("zero Freeze must be empty")
	}
	f.Add(FreezePrelude)
	f.Add(FreezeReady)
	if !f.Has(FreezePrelude) || !f.Has(FreezeReady) || f.Has(FreezeDead) {
		t.Error("Has/Add wrong")
	}
	f.Clear(FreezePrelude)
	if f.Has(FreezePrelude) || f.Empty() {
		t.Error("Clear wrong")
	}
	f.Clear(FreezeReady)
	if !f.Empty() {
		t.Error("Freeze must be empty after clearing all")
	}
}
