// rules.go -- playfield setup, round setup, actor updates, the game tick
// and the intro tick. Corresponds to pacman.c lines 1377-1583, 1733-1748,
// 2089-2403.
package main

// gameInitPlayfield initializes the playfield tiles from the ASCII map
// (pacman.c 1377-1432).
func (g *Game) gameInitPlayfield() {
	g.vidColorPlayfield(ColorDot)
	const tiles = "0UUUUUUUUUUUU45UUUUUUUUUUUU1" +
		"L............rl............R" +
		"L.ebbf.ebbbf.rl.ebbbf.ebbf.R" +
		"LPr  l.r   l.rl.r   l.r  lPR" +
		"L.guuh.guuuh.gh.guuuh.guuh.R" +
		"L..........................R" +
		"L.ebbf.ef.ebbbbbbf.ef.ebbf.R" +
		"L.guuh.rl.guuyxuuh.rl.guuh.R" +
		"L......rl....rl....rl......R" +
		"2BBBBf.rzbbf rl ebbwl.eBBBB3" +
		"     L.rxuuh gh guuyl.R     " +
		"     L.rl          rl.R     " +
		"     L.rl mjs--tjn rl.R     " +
		"UUUUUh.gh i      q gh.gUUUUU" +
		"      .   i      q   .      " +
		"BBBBBf.ef i      q ef.eBBBBB" +
		"     L.rl okkkkkkp rl.R     " +
		"     L.rl          rl.R     " +
		"     L.rl ebbbbbbf rl.R     " +
		"0UUUUh.gh guuyxuuh gh.gUUUU1" +
		"L............rl............R" +
		"L.ebbf.ebbbf.rl.ebbbf.ebbf.R" +
		"L.guyl.guuuh.gh.guuuh.rxuh.R" +
		"LP..rl.......  .......rl..PR" +
		"6bf.rl.ef.ebbbbbbf.ef.rl.eb8" +
		"7uh.gh.rl.guuyxuuh.rl.gh.gu9" +
		"L......rl....rl....rl......R" +
		"L.ebbbbwzbbf.rl.ebbwzbbbbf.R" +
		"L.guuuuuuuuh.gh.guuuuuuuuh.R" +
		"L..........................R" +
		"2BBBBBBBBBBBBBBBBBBBBBBBBBB3"
	var t [128]uint8
	for i := range t {
		t[i] = TileDot
	}
	t[' '] = 0x40
	t['0'] = 0xD1
	t['1'] = 0xD0
	t['2'] = 0xD5
	t['3'] = 0xD4
	t['4'] = 0xFB
	t['5'] = 0xFA
	t['6'] = 0xD7
	t['7'] = 0xD9
	t['8'] = 0xD6
	t['9'] = 0xD8
	t['U'] = 0xDB
	t['L'] = 0xD3
	t['R'] = 0xD2
	t['B'] = 0xDC
	t['b'] = 0xDF
	t['e'] = 0xE7
	t['f'] = 0xE6
	t['g'] = 0xEB
	t['h'] = 0xEA
	t['l'] = 0xE8
	t['r'] = 0xE9
	t['u'] = 0xE5
	t['w'] = 0xF5
	t['x'] = 0xF2
	t['y'] = 0xF3
	t['z'] = 0xF4
	t['m'] = 0xED
	t['n'] = 0xEC
	t['o'] = 0xEF
	t['p'] = 0xEE
	t['j'] = 0xDD
	t['i'] = 0xD2
	t['k'] = 0xDB
	t['q'] = 0xD3
	t['s'] = 0xF1
	t['t'] = 0xF0
	t['-'] = TileDoor
	t['P'] = TilePill
	i := 0
	for y := 3; y <= 33; y++ {
		for x := 0; x < 28; x++ {
			g.Gfx.VideoRAM[y][x] = t[tiles[i]&127]
			i++
		}
	}
	// ghost house gate colors
	g.vidColor(I2(13, 15), 0x18)
	g.vidColor(I2(14, 15), 0x18)
}

// gameDisableTimers disables all game loop timers.
func (g *Game) gameDisableTimers() {
	g.Play.RoundWon.Disable()
	g.Play.GameOver.Disable()
	g.Play.DotEaten.Disable()
	g.Play.PillEaten.Disable()
	g.Play.GhostEaten.Disable()
	g.Play.PacmanEaten.Disable()
	g.Play.FruitEaten.Disable()
	g.Play.ForceLeaveHouse.Disable()
	g.Play.FruitActive.Disable()
}

// gameInit is the one-time init at start of game state.
func (g *Game) gameInit() {
	g.Input.Enable()
	g.gameDisableTimers()
	g.Play.Round = 0
	g.Play.Freeze = FreezePrelude
	g.Play.NumLives = NumLives
	g.Play.GlobalDotCounterActive = false
	g.Play.GlobalDotCounter = 0
	g.Play.NumDotsEaten = 0
	g.Play.Score = 0
	g.vidClear(TileSpace, ColorDot)
	g.vidColorText(I2(9, 0), ColorDefault, "HIGH SCORE")
	g.gameInitPlayfield()
	g.vidColorText(I2(9, 14), 0x5, "PLAYER ONE")
	g.vidColorText(I2(11, 20), 0x9, "READY!")
}

// gameRoundInit sets up the state at start of a game round.
func (g *Game) gameRoundInit() {
	g.sprClear()
	g.vidColorText(I2(9, 14), 0x10, "          ")
	if g.Play.NumDotsEaten == NumDots {
		// round won: redraw the playfield, reset the global dot counter
		g.Play.Round++
		g.Play.NumDotsEaten = 0
		g.gameInitPlayfield()
		g.Play.GlobalDotCounterActive = false
	} else {
		if g.Play.NumLives != NumLives {
			g.Play.GlobalDotCounterActive = true
			g.Play.GlobalDotCounter = 0
		}
		g.Play.NumLives--
	}
	if g.Play.NumLives < 0 {
		panic("gameRoundInit: numLives < 0")
	}

	g.Play.ActiveFruit = FruitNone
	g.Play.Freeze = FreezeReady
	g.Play.Xorshift = 0x12345678 // random-number-generator seed
	g.Play.NumGhostsEaten = 0
	g.gameDisableTimers()
	g.vidColorText(I2(11, 20), 0x9, "READY!")
	g.Play.ForceLeaveHouse.Start(g.Timing.Tick)

	g.Play.Pacman = Pacman{Actor: Actor{
		Dir: DirLeft, Pos: I2(14*8, 26*8+4)}}
	g.Gfx.Sprite[SpritePacman] = Sprite{
		Enabled: true, Color: ColorPacman}

	g.Play.Ghost[GhostBlinky] = Ghost{
		Actor: Actor{Dir: DirLeft, Pos: ghostStartingPos[GhostBlinky]},
		Typ:   GhostBlinky, NextDir: DirLeft, State: GhostStateScatter,
		Frightened: DisabledTrigger(), Eaten: DisabledTrigger(),
		DotCounter: 0, DotLimit: 0}
	g.Gfx.Sprite[SpriteBlinky] = Sprite{
		Enabled: true, Color: ColorBlinky}

	g.Play.Ghost[GhostPinky] = Ghost{
		Actor: Actor{Dir: DirDown, Pos: ghostStartingPos[GhostPinky]},
		Typ:   GhostPinky, NextDir: DirDown, State: GhostStateHouse,
		Frightened: DisabledTrigger(), Eaten: DisabledTrigger(),
		DotCounter: 0, DotLimit: 0}
	g.Gfx.Sprite[SpritePinky] = Sprite{
		Enabled: true, Color: ColorPinky}

	g.Play.Ghost[GhostInky] = Ghost{
		Actor: Actor{Dir: DirUp, Pos: ghostStartingPos[GhostInky]},
		Typ:   GhostInky, NextDir: DirUp, State: GhostStateHouse,
		Frightened: DisabledTrigger(), Eaten: DisabledTrigger(),
		DotCounter: 0, DotLimit: 30}
	g.Gfx.Sprite[SpriteInky] = Sprite{
		Enabled: true, Color: ColorInky}

	g.Play.Ghost[GhostClyde] = Ghost{
		Actor: Actor{Dir: DirUp, Pos: ghostStartingPos[GhostClyde]},
		Typ:   GhostClyde, NextDir: DirUp, State: GhostStateHouse,
		Frightened: DisabledTrigger(), Eaten: DisabledTrigger(),
		DotCounter: 0, DotLimit: 60}
	g.Gfx.Sprite[SpriteClyde] = Sprite{
		Enabled: true, Color: ColorClyde}
}

// pacmanShouldMove returns true if Pacman should move in this tick.
func (g *Game) pacmanShouldMove() bool {
	now := g.Timing.Tick
	switch {
	case g.Play.DotEaten.Now(now):
		return false // eating a dot stops Pacman for 1 tick
	case g.Play.PillEaten.Since(now) < 3:
		return false // eating a pill stops Pacman for 3 ticks
	default:
		return (g.Timing.Tick % 8) != 0
	}
}

// gameUpdateDotsEaten is called when a dot or pill has been eaten.
func (g *Game) gameUpdateDotsEaten() {
	g.Play.NumDotsEaten++
	if g.Play.NumDotsEaten == NumDots {
		g.Play.RoundWon.Start(g.Timing.Tick)
		g.sndClear()
	} else if g.Play.NumDotsEaten == 70 || g.Play.NumDotsEaten == 170 {
		g.Play.FruitActive.Start(g.Timing.Tick)
	}
	// alternating crunch sound effect
	if (g.Play.NumDotsEaten & 1) != 0 {
		g.sndStart(2, sndEatdot1)
	} else {
		g.sndStart(2, sndEatdot2)
	}
}

// gameUpdateActors is the central Pacman and ghost behaviour function,
// called once per game tick.
func (g *Game) gameUpdateActors() {
	now := g.Timing.Tick
	// Pacman "AI"
	if g.pacmanShouldMove() {
		actor := &g.Play.Pacman.Actor
		wantedDir := g.Input.DirOr(actor.Dir)
		if g.canMove(actor.Pos, wantedDir, true) {
			actor.Dir = wantedDir
		}
		if g.canMove(actor.Pos, actor.Dir, true) {
			actor.Pos = move(actor.Pos, actor.Dir, true)
			actor.AnimTick++
		}
		tilePos := pixelToTilePos(actor.Pos)
		if g.isDot(tilePos) {
			g.vidTile(tilePos, TileSpace)
			g.Play.Score++
			g.Play.DotEaten.Start(now)
			g.Play.ForceLeaveHouse.Start(now)
			g.gameUpdateDotsEaten()
			g.updateGhosthouseDotCounters()
		}
		if g.isPill(tilePos) {
			g.vidTile(tilePos, TileSpace)
			g.Play.Score += 5
			g.gameUpdateDotsEaten()
			g.Play.PillEaten.Start(now)
			g.Play.NumGhostsEaten = 0
			for i := range g.Play.Ghost {
				g.Play.Ghost[i].Frightened.Start(now)
			}
			g.sndStart(1, sndFrightened)
		}
		// check if Pacman eats the bonus fruit
		if g.Play.ActiveFruit != FruitNone {
			testPos := pixelToTilePos(actor.Pos.Add(I2(TileWidth/2, 0)))
			if testPos == I2(14, 20) {
				g.Play.FruitEaten.Start(now)
				g.Play.Score += uint32(levelSpec(int(g.Play.Round)).BonusScore)
				g.vidFruitScore(g.Play.ActiveFruit)
				g.Play.ActiveFruit = FruitNone
				g.sndStart(2, sndEatfruit)
			}
		}
		// check if Pacman collides with any ghost
		for i := range g.Play.Ghost {
			ghost := &g.Play.Ghost[i]
			ghostTilePos := pixelToTilePos(ghost.Actor.Pos)
			if tilePos == ghostTilePos {
				if ghost.State == GhostStateFrightened {
					ghost.State = GhostStateEyes
					ghost.Eaten.Start(now)
					g.Play.GhostEaten.Start(now)
					g.Play.NumGhostsEaten++
					// increase score by 20, 40, 80, 160 (in 10-point units)
					g.Play.Score += uint32(10 * (1 << g.Play.NumGhostsEaten))
					g.Play.Freeze.Add(FreezeEatGhost)
					g.sndStart(2, sndEatghost)
				} else if ghost.State == GhostStateChase ||
					ghost.State == GhostStateScatter {
					g.sndClear()
					g.Play.PacmanEaten.Start(now)
					g.Play.Freeze.Add(FreezeDead)
					if g.Play.NumLives > 0 {
						g.Play.ReadyStarted.StartAfter(now,
							PacmanEatenTicks+PacmanDeathTicks)
					} else {
						g.Play.GameOver.StartAfter(now,
							PacmanEatenTicks+PacmanDeathTicks)
					}
				}
			}
		}
	}

	// Ghost "AIs"
	for i := range g.Play.Ghost {
		ghost := &g.Play.Ghost[i]
		g.updateGhostState(ghost)
		g.updateGhostTarget(ghost)
		numMoveTicks := g.ghostSpeed(ghost)
		for j := 0; j < numMoveTicks; j++ {
			forceMove := g.updateGhostDir(ghost)
			if forceMove || g.canMove(ghost.Actor.Pos, ghost.Actor.Dir, false) {
				ghost.Actor.Pos = move(ghost.Actor.Pos, ghost.Actor.Dir, false)
				ghost.Actor.AnimTick++
			}
		}
	}
}

// NewGame creates a game in its initial state: the intro scene is
// started at the first tick (pacman.c's init callback starts the
// intro trigger before the first frame).
func NewGame() *Game {
	g := &Game{}
	g.Intro.Started.Start(g.Timing.Tick)
	return g
}

// Tick advances the whole game by one tick. It is the headless entry
// point: main.go's Update calls it once per Ebiten tick (SPEC H1),
// and the tests call it directly. The order mirrors pacman.c's frame
// callback: advance the tick, tick the sound, switch scenes on the
// started triggers, then run the scene's tick.
func (g *Game) Tick() {
	g.Timing.Tick++
	g.sndTick()
	now := g.Timing.Tick
	if g.Intro.Started.Now(now) {
		g.Scene = SceneIntro
	}
	if g.Play.Started.Now(now) {
		g.Scene = SceneGame
	}
	switch g.Scene {
	case SceneIntro:
		g.introTick()
	case SceneGame:
		g.gameTick()
	}
}

// gameTick is the central game tick function, called at 60 Hz.
func (g *Game) gameTick() {
	now := g.Timing.Tick
	if g.Play.Started.Now(now) {
		g.Gfx.Fadein.Start(now)
		g.Play.ReadyStarted.StartAfter(now, 2*60)
		g.sndStart(0, sndPrelude)
		g.gameInit()
	}
	if g.Play.ReadyStarted.Now(now) {
		g.gameRoundInit()
		g.Play.RoundStarted.StartAfter(now, 2*60+10)
	}
	if g.Play.RoundStarted.Now(now) {
		g.Play.Freeze.Clear(FreezeReady)
		g.vidColorText(I2(11, 20), 0x10, "      ")
		g.sndStart(1, sndWeeooh)
	}

	// activate/deactivate bonus fruit
	if g.Play.FruitActive.Now(now) {
		g.Play.ActiveFruit = levelSpec(int(g.Play.Round)).BonusFruit
	} else if g.Play.FruitActive.AfterOnce(now, FruitactiveTicks) {
		g.Play.ActiveFruit = FruitNone
	}

	// stop frightened sound and restart the weeooh sound
	if g.Play.PillEaten.AfterOnce(now,
		uint32(levelSpec(int(g.Play.Round)).FrightTicks)) {
		g.sndStart(1, sndWeeooh)
	}

	// unfreeze after Pacman ate a ghost
	if g.Play.Freeze.Has(FreezeEatGhost) {
		if g.Play.GhostEaten.AfterOnce(now, GhostEatenFreezeTicks) {
			g.Play.Freeze.Clear(FreezeEatGhost)
		}
	}

	// play the pacman-death sound
	if g.Play.PacmanEaten.AfterOnce(now, PacmanEatenTicks) {
		g.sndStart(2, sndDead)
	}

	if g.Play.Freeze.Empty() {
		g.gameUpdateActors()
	}
	g.gameUpdateTiles()
	g.gameUpdateSprites()

	if g.Play.Score > g.Play.Hiscore {
		g.Play.Hiscore = g.Play.Score
	}

	// check for end-of-round conditions
	if g.Play.RoundWon.Now(now) {
		g.Play.Freeze.Add(FreezeWon)
		g.Play.ReadyStarted.StartAfter(now, RoundwonTicks)
	}
	if g.Play.GameOver.Now(now) {
		g.vidColorText(I2(9, 20), 0x01, "GAME  OVER")
		g.Input.Disable()
		g.Gfx.Fadeout.StartAfter(now, GameoverTicks)
		g.Intro.Started.StartAfter(now, GameoverTicks+FadeTicks)
	}
}

// introTick is the intro screen tick function.
func (g *Game) introTick() {
	now := g.Timing.Tick
	if g.Intro.Started.Now(now) {
		g.sndClear()
		g.sprClear()
		g.Gfx.Fadein.Start(now)
		g.Input.Enable()
		g.vidClear(TileSpace, ColorDefault)
		g.vidText(I2(3, 0), "1UP   HIGH SCORE   2UP")
		g.vidColorScore(I2(6, 1), ColorDefault, 0)
		if g.Play.Hiscore > 0 {
			g.vidColorScore(I2(16, 1), ColorDefault, g.Play.Hiscore)
		}
		g.vidText(I2(7, 5), "CHARACTER / NICKNAME")
		g.vidText(I2(3, 35), "CREDIT  0")
	}

	delay := uint32(30)
	names := [4]string{"-SHADOW", "-SPEEDY", "-BASHFUL", "-POKEY"}
	nicknames := [4]string{"BLINKY", "PINKY", "INKY", "CLYDE"}
	for i := 0; i < 4; i++ {
		color := uint8(2*i + 1)
		y := int16(3*i + 6)
		delay += 30
		if g.Intro.Started.AfterOnce(now, delay) {
			g.vidColorTile(I2(4, y+0), color, TileGhost+0)
			g.vidColorTile(I2(5, y+0), color, TileGhost+1)
			g.vidColorTile(I2(4, y+1), color, TileGhost+2)
			g.vidColorTile(I2(5, y+1), color, TileGhost+3)
			g.vidColorTile(I2(4, y+2), color, TileGhost+4)
			g.vidColorTile(I2(5, y+2), color, TileGhost+5)
		}
		delay += 60
		if g.Intro.Started.AfterOnce(now, delay) {
			g.vidColorText(I2(7, y+1), color, names[i])
		}
		delay += 30
		if g.Intro.Started.AfterOnce(now, delay) {
			g.vidColorText(I2(17, y+1), color, nicknames[i])
		}
	}

	delay += 60
	if g.Intro.Started.AfterOnce(now, delay) {
		g.vidColorTile(I2(10, 24), ColorDot, TileDot)
		g.vidText(I2(12, 24), "10 \x5D\x5E\x5F")
		g.vidColorTile(I2(10, 26), ColorDot, TilePill)
		g.vidText(I2(12, 26), "50 \x5D\x5E\x5F")
	}

	delay += 60
	if g.Intro.Started.After(now, delay) {
		if (g.Intro.Started.Since(now) & 0x20) != 0 {
			g.vidColorText(I2(3, 31), 3, "                       ")
		} else {
			g.vidColorText(I2(3, 31), 3, "PRESS ANY KEY TO START!")
		}
	}

	if g.Input.Anykey {
		g.Input.Disable()
		g.Gfx.Fadeout.Start(now)
		g.Play.Started.StartAfter(now, FadeTicks)
	}
}
