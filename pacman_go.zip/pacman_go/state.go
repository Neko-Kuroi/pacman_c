// state.go -- constants, types and the single game state object.
// Corresponds to pacman.c lines 142-678 (config, enums, structs, data tables).
// Inside this file the writing follows Go conventions where the C code's
// intent allows it (e.g. freeze flags are a small int type with methods,
// not a raw uint8 bitfield at the call sites).
package main

// --- config (pacman.c 144-152) ---
const AudioVolume = 0.5

// --- global constants (pacman.c 161-193) ---
const (
	TickDurationNs  = 16_666_666
	TickToleranceNs = 1_000_000
	NumVoices       = 3
	NumSounds       = 3
	DisabledTicks   = 0xFFFFFFFF
	TileWidth       = 8
	TileHeight      = 8
	SpriteWidth     = 16
	SpriteHeight    = 16
	DisplayTilesX   = 28
	DisplayTilesY   = 36
	DisplayPixelsX  = DisplayTilesX * TileWidth
	DisplayPixelsY  = DisplayTilesY * TileHeight
	NumSprites      = 8
	NumDebugMarkers = 16
	FadeTicks       = 30
	NumLives        = 3
	NumStatusFruits = 7
	NumDots         = 244
	NumPills        = 4

	AnteportasX = 14 * TileWidth
	AnteportasY = 14*TileHeight + TileHeight/2

	GhostEatenFreezeTicks = 60
	PacmanEatenTicks      = 60
	PacmanDeathTicks      = 150
	GameoverTicks         = 3 * 60
	RoundwonTicks         = 4 * 60
	FruitactiveTicks      = 10 * 60
)

// --- tile, sprite and color codes (pacman.c 198-248) ---
const (
	TileSpace      = 0x40
	TileDot        = 0x10
	TilePill       = 0x14
	TileGhost      = 0xB0
	TileLife       = 0x20
	TileCherries   = 0x90
	TileStrawberry = 0x94
	TilePeach      = 0x98
	TileBell       = 0x9C
	TileApple      = 0xA0
	TileGrapes     = 0xA4
	TileGalaxian   = 0xA8
	TileKey        = 0xAC
	TileDoor       = 0xCF
)

const (
	SpritetileInvisible         = 30
	SpritetileScore200          = 40
	SpritetileScore400          = 41
	SpritetileScore800          = 42
	SpritetileScore1600         = 43
	SpritetileCherries          = 0
	SpritetileStrawberry        = 1
	SpritetilePeach             = 2
	SpritetileBell              = 3
	SpritetileApple             = 4
	SpritetileGrapes            = 5
	SpritetileGalaxian          = 6
	SpritetileKey               = 7
	SpritetilePacmanClosedMouth = 48
)

const (
	ColorBlank              = 0x00
	ColorDefault            = 0x0F
	ColorDot                = 0x10
	ColorPacman             = 0x09
	ColorBlinky             = 0x01
	ColorPinky              = 0x03
	ColorInky               = 0x05
	ColorClyde              = 0x07
	ColorFrightened         = 0x11
	ColorFrightenedBlinking = 0x12
	ColorGhostScore         = 0x18
	ColorEyes               = 0x19
	ColorCherries           = 0x14
	ColorStrawberry         = 0x0F
	ColorPeach              = 0x15
	ColorBell               = 0x16
	ColorApple              = 0x14
	ColorGrapes             = 0x17
	ColorGalaxian           = 0x09
	ColorKey                = 0x16
	ColorWhiteBorder        = 0x1F
	ColorFruitScore         = 0x03
)

// --- enums (pacman.c 254-320) ---

// Scene is the top-level game state (C: gamestate_t).
type Scene int

const (
	SceneIntro Scene = iota
	SceneGame
)

// Dir is a movement direction (C: dir_t).
// NOTE: bit0==0: horizontal movement, bit0==1: vertical movement.
type Dir int

const (
	DirRight Dir = iota
	DirDown
	DirLeft
	DirUp
	NumDirs
)

// Fruit is a bonus fruit kind (C: fruit_t).
type Fruit int

const (
	FruitNone Fruit = iota
	FruitCherries
	FruitStrawberry
	FruitPeach
	FruitApple
	FruitGrapes
	FruitGalaxian
	FruitBell
	FruitKey
	NumFruits
)

// SpriteIndex identifies a hardware sprite slot.
type SpriteIndex int

const (
	SpritePacman SpriteIndex = iota
	SpriteBlinky
	SpritePinky
	SpriteInky
	SpriteClyde
	SpriteFruit
)

// GhostType identifies one of the four ghosts.
type GhostType int

const (
	GhostBlinky GhostType = iota
	GhostPinky
	GhostInky
	GhostClyde
	NumGhosts
)

// GhostState is a ghost's movement state (C: ghoststate_t).
type GhostState int

const (
	GhostStateNone GhostState = iota
	GhostStateChase
	GhostStateScatter
	GhostStateFrightened
	GhostStateEyes
	GhostStateHouse
	GhostStateLeaveHouse
	GhostStateEnterHouse
)

// Freeze is the set of reasons the game is frozen (C: freezetype_t).
// In C these are (1<<n) bit values in a uint8; here the bit operations
// are hidden behind methods so call sites read as events.
type Freeze uint8

const (
	FreezePrelude Freeze = 1 << iota
	FreezeReady
	FreezeEatGhost
	FreezeDead
	FreezeWon
)

// Has reports whether the given freeze reason is present.
func (f Freeze) Has(o Freeze) bool { return f&o != 0 }

// Add sets the given freeze reason.
func (f *Freeze) Add(o Freeze) { *f |= o }

// Clear removes the given freeze reason (C: freeze &= ~o).
func (f *Freeze) Clear(o Freeze) { *f &^= o }

// Empty reports whether no freeze reason is present.
func (f Freeze) Empty() bool { return f == 0 }

// SoundFlags records which voices a playing sound uses (C: voice flags).
type SoundFlags uint8

const (
	SoundVoice0 SoundFlags = 1 << iota
	SoundVoice1
	SoundVoice2
	SoundAllVoices = SoundVoice0 | SoundVoice1 | SoundVoice2
)

// --- basic types (pacman.c 323-352) ---

// Trigger remembers one future tick (C: trigger_t).
// The methods live in timing.go.
type Trigger struct {
	Tick uint32
}

// Int2 is a 2D integer vector (C: int2_t).
// Arithmetic methods live in geom.go.
type Int2 struct {
	X int16
	Y int16
}

// I2 constructs an Int2.
func I2(x, y int16) Int2 { return Int2{X: x, Y: y} }

// Actor is anything that moves on the playfield.
type Actor struct {
	Dir      Dir
	Pos      Int2
	AnimTick uint32
}

// Ghost is one ghost and its house/thinking state.
type Ghost struct {
	Actor      Actor
	Typ        GhostType
	NextDir    Dir
	TargetPos  Int2
	State      GhostState
	Frightened Trigger
	Eaten      Trigger
	DotCounter uint16
	DotLimit   uint16
}

// Pacman is the player character.
type Pacman struct {
	Actor Actor
}

// --- renderer data types (pacman.c 360-385) ---

// Sprite is one sprite slot's data (the pixels live in render.go).
type Sprite struct {
	Enabled bool
	Tile    uint8
	Color   uint8
	FlipX   bool
	FlipY   bool
	Pos     Int2
}

// DebugMarker is a debug overlay marker.
type DebugMarker struct {
	Enabled bool
	Tile    uint8
	Color   uint8
	TilePos Int2
}

// --- sound types (pacman.c 388-418) ---

// SoundFunc is a procedural sound generator (C: sound_func_t).
// It receives the game because Go has no globals to reach for.
type SoundFunc func(g *Game, slot int32)

// SoundDesc describes a sound effect (C: snddesc_t).
// Data is a register dump (nil for procedural sounds); its length in
// uint32 words replaces the C byte-size field.
type SoundDesc struct {
	Fn    SoundFunc
	Data  []uint32
	Voice [3]bool
}

// Voice is one Namco-style sound voice.
type Voice struct {
	Counter   uint32
	Frequency uint32
	Waveform  uint8
	Volume    uint8
	SampleAcc float32
	SampleDiv float32
}

// Sound is one playing sound slot.
type Sound struct {
	CurTick  uint32
	Fn       SoundFunc
	NumTicks uint32
	Stride   uint32
	Data     []uint32
	Flags    SoundFlags
}

// --- the game state (pacman.c 420-540) ---

// TimingState holds the tick counter. The C accumulator fields are
// gone: Ebitengine calls Update once per tick (SPEC H1).
type TimingState struct {
	Tick uint32
}

// IntroState holds the intro scene's state.
type IntroState struct {
	Started Trigger
}

// PlayState is the state of one game in progress (C: state.game).
type PlayState struct {
	Xorshift        uint32
	Hiscore         uint32
	Started         Trigger
	ReadyStarted    Trigger
	RoundStarted    Trigger
	RoundWon        Trigger
	GameOver        Trigger
	DotEaten        Trigger
	PillEaten       Trigger
	GhostEaten      Trigger
	PacmanEaten     Trigger
	FruitEaten      Trigger
	ForceLeaveHouse Trigger
	FruitActive     Trigger
	Freeze          Freeze
	Round           uint8
	Score           uint32
	NumLives        int8
	NumGhostsEaten  uint8
	NumDotsEaten    uint8

	GlobalDotCounterActive bool
	GlobalDotCounter       uint8

	Ghost       [4]Ghost
	Pacman      Pacman
	ActiveFruit Fruit
}

// InputState is the resolved input (C: state.input).
// input.go fills this from the actual devices each tick.
type InputState struct {
	Enabled bool
	Up      bool
	Down    bool
	Left    bool
	Right   bool
	Esc     bool
	Anykey  bool
}

// AudioState holds the sound hardware state (C: state.audio).
// The sample output bookkeeping lives in audio.go's Synth.
type AudioState struct {
	Voice [NumVoices]Voice
	Sound [NumSounds]Sound
}

// GfxState holds the playfield data the renderer reads (C: state.gfx,
// minus the GPU resources, which live in render.go).
type GfxState struct {
	Fadein  Trigger
	Fadeout Trigger
	Fade    uint8

	VideoRAM    [DisplayTilesY][DisplayTilesX]uint8
	ColorRAM    [DisplayTilesY][DisplayTilesX]uint8
	Sprite      [NumSprites]Sprite
	DebugMarker [NumDebugMarkers]DebugMarker

	ColorPalette [256]uint32
}

// Game is the whole game state and the ebiten-facing game object.
// Behavior lives in rules.go (gameTick/introTick) and friends;
// the ebiten wiring lives in main.go.
type Game struct {
	Scene  Scene
	Timing TimingState
	Intro  IntroState
	Play   PlayState
	Input  InputState
	Audio  AudioState
	Gfx    GfxState
}

// --- data tables (pacman.c 542-623) ---

var ghostScatterTargets = [4]Int2{
	I2(25, 0), I2(2, 0), I2(27, 34), I2(0, 34),
}

// starting positions for ghosts (pixel coords), pacman.c 548-553
var ghostStartingPos = [4]Int2{
	I2(14*8, 14*8+4), I2(14*8, 17*8+4),
	I2(12*8, 17*8+4), I2(16*8, 17*8+4),
}

// target positions for ghosts entering the ghost house, pacman.c 556-561
var ghostHouseTargetPos = [4]Int2{
	I2(14*8, 17*8+4), I2(14*8, 17*8+4),
	I2(12*8, 17*8+4), I2(16*8, 17*8+4),
}

var fruitTilesColors = [9][3]uint8{
	{0, 0, 0},
	{TileCherries, SpritetileCherries, ColorCherries},
	{TileStrawberry, SpritetileStrawberry, ColorStrawberry},
	{TilePeach, SpritetilePeach, ColorPeach},
	{TileApple, SpritetileApple, ColorApple},
	{TileGrapes, SpritetileGrapes, ColorGrapes},
	{TileGalaxian, SpritetileGalaxian, ColorGalaxian},
	{TileBell, SpritetileBell, ColorBell},
	{TileKey, SpritetileKey, ColorKey},
}

var fruitScoreTiles = [9][4]uint8{
	{0x40, 0x40, 0x40, 0x40},
	{0x40, 0x81, 0x85, 0x40},
	{0x40, 0x82, 0x85, 0x40},
	{0x40, 0x83, 0x85, 0x40},
	{0x40, 0x84, 0x85, 0x40},
	{0x40, 0x86, 0x8D, 0x8E},
	{0x87, 0x88, 0x8D, 0x8E},
	{0x89, 0x8A, 0x8D, 0x8E},
	{0x8B, 0x8C, 0x8D, 0x8E},
}

// LevelSpec is one row of the level table (C: levelspec_t).
type LevelSpec struct {
	BonusFruit  Fruit
	BonusScore  uint16
	FrightTicks uint16
}

const maxLevelSpec = 21

var levelSpecTable = [maxLevelSpec]LevelSpec{
	{FruitCherries, 10, 6 * 60},
	{FruitStrawberry, 30, 5 * 60},
	{FruitPeach, 50, 4 * 60},
	{FruitPeach, 50, 3 * 60},
	{FruitApple, 70, 2 * 60},
	{FruitApple, 70, 5 * 60},
	{FruitGrapes, 100, 2 * 60},
	{FruitGrapes, 100, 2 * 60},
	{FruitGalaxian, 200, 1 * 60},
	{FruitGalaxian, 200, 5 * 60},
	{FruitBell, 300, 2 * 60},
	{FruitBell, 300, 1 * 60},
	{FruitKey, 500, 1 * 60},
	{FruitKey, 500, 3 * 60},
	{FruitKey, 500, 1 * 60},
	{FruitKey, 500, 1 * 60},
	{FruitKey, 500, 1},
	{FruitKey, 500, 1 * 60},
	{FruitKey, 500, 1},
	{FruitKey, 500, 1},
	{FruitKey, 500, 1},
}

// levelSpec returns the level spec for a round, clamped to the last
// table entry (pacman.c 835-843).
func levelSpec(round int) LevelSpec {
	if round < 0 {
		panic("levelSpec: negative round")
	}
	if round > maxLevelSpec-1 {
		round = maxLevelSpec - 1
	}
	return levelSpecTable[round]
}
