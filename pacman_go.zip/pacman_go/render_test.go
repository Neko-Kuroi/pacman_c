package main

import "testing"

// The decode half of the renderer works on plain buffers, so it can
// be verified without a graphics context: known tiles decode to
// known shapes, and the palette follows the hardware rules.

func TestDecodeTilesAndPalette(t *testing.T) {
	g := NewGame()
	r := &Renderer{g: g}
	r.gfxDecodeTiles()
	g.gfxDecodeColorPalette()

	// the space tile (0x40) is entirely blank
	for y := 0; y < TileHeight; y++ {
		for x := 0; x < TileWidth; x++ {
			if r.tilePixels[y][TileSpace*TileWidth+x] != 0 {
				t.Fatalf("space tile not blank at (%d,%d)", x, y)
			}
		}
	}
	// the dot tile (0x10) has non-zero pixels, the closed-mouth
	// pacman sprite (48) has non-zero pixels
	nonzero := 0
	for y := 0; y < TileHeight; y++ {
		for x := 0; x < TileWidth; x++ {
			if r.tilePixels[y][TileDot*TileWidth+x] != 0 {
				nonzero++
			}
		}
	}
	if nonzero == 0 {
		t.Error("dot tile decoded to nothing")
	}
	nonzero = 0
	for y := 0; y < SpriteHeight; y++ {
		for x := 0; x < SpriteWidth; x++ {
			if r.tilePixels[TileHeight+y][48*SpriteWidth+x] != 0 {
				nonzero++
			}
		}
	}
	if nonzero == 0 {
		t.Error("pacman sprite decoded to nothing")
	}
	// palette: index 0 of each group of 4 is transparent, the rest
	// are opaque
	for i := 0; i < 256; i += 4 {
		if got := g.Gfx.ColorPalette[i] >> 24; got != 0 {
			t.Errorf("palette[%d] alpha = %d, want 0", i, got)
		}
	}
	for _, i := range []int{1, 2, 3} {
		if got := g.Gfx.ColorPalette[i] >> 24; got != 0xFF {
			t.Errorf("palette[%d] alpha = %d, want 0xFF", i, got)
		}
	}
}
