// ghost.go -- ghost speed, state machine, target selection and steering.
// Corresponds to pacman.c lines 1750-2087.
package main

// ghostSpeed returns how many pixels the ghost moves this tick
// (pacman.c 1750-1775).
func (g *Game) ghostSpeed(ghost *Ghost) int {
	tick := g.Timing.Tick
	switch ghost.State {
	case GhostStateHouse, GhostStateLeaveHouse, GhostStateFrightened:
		// inside house / frightened: half speed
		return int(tick & 1)
	case GhostStateEyes, GhostStateEnterHouse:
		// estimated 1.5x in eye state
		if tick&1 != 0 {
			return 1
		}
		return 2
	default:
		if isTunnel(pixelToTilePos(ghost.Actor.Pos)) {
			if (tick*2)%4 != 0 {
				return 1
			}
			return 0
		}
		if tick%7 != 0 {
			return 1
		}
		return 0
	}
}

// scatterChasePhase returns the current global scatter or chase phase.
func (g *Game) scatterChasePhase() GhostState {
	t := g.Play.RoundStarted.Since(g.Timing.Tick)
	switch {
	case t < 7*60:
		return GhostStateScatter
	case t < 27*60:
		return GhostStateChase
	case t < 34*60:
		return GhostStateScatter
	case t < 54*60:
		return GhostStateChase
	case t < 59*60:
		return GhostStateScatter
	case t < 79*60:
		return GhostStateChase
	case t < 84*60:
		return GhostStateScatter
	default:
		return GhostStateChase
	}
}

// updateGhostState takes care of switching a ghost into a new state.
func (g *Game) updateGhostState(ghost *Ghost) {
	now := g.Timing.Tick
	newState := ghost.State
	switch ghost.State {
	case GhostStateEyes:
		if ghost.Actor.Pos.NearEqual(I2(AnteportasX, AnteportasY), 1) {
			newState = GhostStateEnterHouse
		}
	case GhostStateEnterHouse:
		if ghost.Actor.Pos.NearEqual(ghostHouseTargetPos[ghost.Typ], 1) {
			newState = GhostStateLeaveHouse
		}
	case GhostStateHouse:
		if g.Play.ForceLeaveHouse.AfterOnce(now, 4*60) {
			newState = GhostStateLeaveHouse
			g.Play.ForceLeaveHouse.Start(now)
		} else if g.Play.GlobalDotCounterActive {
			switch {
			case ghost.Typ == GhostPinky && g.Play.GlobalDotCounter == 7:
				newState = GhostStateLeaveHouse
			case ghost.Typ == GhostInky && g.Play.GlobalDotCounter == 17:
				newState = GhostStateLeaveHouse
			case ghost.Typ == GhostClyde && g.Play.GlobalDotCounter == 32:
				newState = GhostStateLeaveHouse
				// the global dot counter is deactivated when Clyde leaves at 32
				g.Play.GlobalDotCounterActive = false
			}
		} else if ghost.DotCounter == ghost.DotLimit {
			newState = GhostStateLeaveHouse
		}
	case GhostStateLeaveHouse:
		if ghost.Actor.Pos.Y == AnteportasY {
			newState = GhostStateScatter
		}
	default:
		if ghost.Frightened.Before(now, uint32(levelSpec(int(g.Play.Round)).FrightTicks)) {
			newState = GhostStateFrightened
		} else {
			newState = g.scatterChasePhase()
		}
	}
	// handle state transitions
	if newState != ghost.State {
		switch ghost.State {
		case GhostStateLeaveHouse:
			ghost.NextDir = DirLeft
			ghost.Actor.Dir = DirLeft
		case GhostStateEnterHouse:
			// a ghost that was eaten is immune to frighten until the next pill
			ghost.Frightened.Disable()
		case GhostStateFrightened:
			// don't reverse direction when leaving frightened state
		case GhostStateScatter, GhostStateChase:
			// any transition from scatter/chase causes a reversal of direction
			ghost.NextDir = reverseDir(ghost.Actor.Dir)
		}
		ghost.State = newState
	}
}

// updateGhostTarget updates the ghost's target position.
func (g *Game) updateGhostTarget(ghost *Ghost) {
	pos := ghost.TargetPos
	switch ghost.State {
	case GhostStateScatter:
		pos = ghostScatterTargets[ghost.Typ]
	case GhostStateChase:
		pm := g.Play.Pacman.Actor
		pmPos := pixelToTilePos(pm.Pos)
		pmDir := dirToVec(pm.Dir)
		switch ghost.Typ {
		case GhostBlinky:
			pos = pmPos
		case GhostPinky:
			// 4 tiles ahead of Pacman (without the arcade 'diagonal overflow')
			pos = pmPos.Add(pmDir.Scale(4))
		case GhostInky:
			blinkyPos := pixelToTilePos(g.Play.Ghost[GhostBlinky].Actor.Pos)
			p := pmPos.Add(pmDir.Scale(2))
			d := p.Sub(blinkyPos)
			pos = blinkyPos.Add(d.Scale(2))
		case GhostClyde:
			if ghost.Actor.Pos.pixelToTile().SquaredDistance(pmPos) > 64 {
				pos = pmPos
			} else {
				pos = ghostScatterTargets[GhostClyde]
			}
		}
	case GhostStateFrightened:
		// random target position (random direction at each intersection)
		pos = I2(int16(g.Play.xorshift32()%DisplayTilesX),
			int16(g.Play.xorshift32()%DisplayTilesY))
	case GhostStateEyes:
		pos = I2(13, 14)
	}
	ghost.TargetPos = pos
}

// pixelToTile is shorthand for pixelToTilePos on an actor position.
func (v Int2) pixelToTile() Int2 { return pixelToTilePos(v) }

// updateGhostDir computes the next ghost direction; it returns true if
// the resulting movement should always happen (movement inside the
// ghost house).
func (g *Game) updateGhostDir(ghost *Ghost) bool {
	switch ghost.State {
	case GhostStateHouse:
		if ghost.Actor.Pos.Y <= 17*TileHeight {
			ghost.NextDir = DirDown
		} else if ghost.Actor.Pos.Y >= 18*TileHeight {
			ghost.NextDir = DirUp
		}
		ghost.Actor.Dir = ghost.NextDir
		return true
	case GhostStateLeaveHouse:
		pos := ghost.Actor.Pos
		if pos.X == AnteportasX {
			if pos.Y > AnteportasY {
				ghost.NextDir = DirUp
			}
		} else {
			const midY = 17*TileHeight + TileHeight/2
			switch {
			case pos.Y > midY:
				ghost.NextDir = DirUp
			case pos.Y < midY:
				ghost.NextDir = DirDown
			case pos.X > AnteportasX:
				ghost.NextDir = DirLeft
			default:
				ghost.NextDir = DirRight
			}
		}
		ghost.Actor.Dir = ghost.NextDir
		return true
	case GhostStateEnterHouse:
		pos := ghost.Actor.Pos
		tilePos := pixelToTilePos(pos)
		tgtPos := ghostHouseTargetPos[ghost.Typ]
		if tilePos.Y == 14 {
			if pos.X != AnteportasX {
				if pos.X < AnteportasX {
					ghost.NextDir = DirRight
				} else {
					ghost.NextDir = DirLeft
				}
			} else {
				ghost.NextDir = DirDown
			}
		} else if pos.Y == tgtPos.Y {
			if pos.X < tgtPos.X {
				ghost.NextDir = DirRight
			} else {
				ghost.NextDir = DirLeft
			}
		}
		ghost.Actor.Dir = ghost.NextDir
		return true
	default:
		// scatter/chase/frightened: head towards the current target point
		distToMid := distToTileMid(ghost.Actor.Pos)
		if distToMid.X == 0 && distToMid.Y == 0 {
			ghost.Actor.Dir = ghost.NextDir
			dirVec := dirToVec(ghost.Actor.Dir)
			lookaheadPos := pixelToTilePos(ghost.Actor.Pos).Add(dirVec)
			dirs := [4]Dir{DirUp, DirLeft, DirDown, DirRight}
			minDist := int32(100000)
			for _, dir := range dirs {
				// in the two 'red zones', upward movement is forbidden (except eyes)
				if isRedzone(lookaheadPos) && dir == DirUp && ghost.State != GhostStateEyes {
					continue
				}
				revdir := reverseDir(dir)
				testPos := clampedTilePos(lookaheadPos.Add(dirToVec(dir)))
				if revdir != ghost.Actor.Dir && !g.isBlockingTile(testPos) {
					dist := testPos.SquaredDistance(ghost.TargetPos)
					if dist < minDist {
						minDist = dist
						ghost.NextDir = dir
					}
				}
			}
		}
		return false
	}
}

// updateGhosthouseDotCounters updates the dot counters used to decide
// whether ghosts must leave the house (called each time Pacman eats
// a dot).
func (g *Game) updateGhosthouseDotCounters() {
	if g.Play.GlobalDotCounterActive {
		g.Play.GlobalDotCounter++
	} else {
		for i := range g.Play.Ghost {
			if g.Play.Ghost[i].DotCounter < g.Play.Ghost[i].DotLimit {
				g.Play.Ghost[i].DotCounter++
				break
			}
		}
	}
}
