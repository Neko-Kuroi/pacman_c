package main

import "testing"

func TestDistToTileMidNegative(t *testing.T) {
	// In the tunnel, positions go negative; C's % truncates toward
	// zero, and Go's % does the same, so no cmod helper is needed.
	if got := distToTileMid(I2(-13, 20)); got != I2(9, 0) {
		t.Errorf("distToTileMid(-13,20) = %v, want (9,0)", got)
	}
	if got := pixelToTilePos(I2(-1, 0)); got != I2(0, 0) {
		t.Errorf("pixelToTilePos(-1,0) = %v, want (0,0)", got)
	}
}

func TestClampedTilePos(t *testing.T) {
	if got := clampedTilePos(I2(30, 35)); got != I2(27, 33) {
		t.Errorf("got %v, want (27,33)", got)
	}
	if got := clampedTilePos(I2(-2, 0)); got != I2(0, 3) {
		t.Errorf("got %v, want (0,3)", got)
	}
}

func TestInt2Chain(t *testing.T) {
	// The Inky pivot computation, in method-chain form.
	pmPos, blinkyPos := I2(100, 100), I2(90, 92)
	p := pmPos.Add(dirToVec(DirRight).Scale(2))
	d := p.Sub(blinkyPos)
	pos := blinkyPos.Add(d.Scale(2))
	if pos != I2(114, 108) {
		t.Errorf("Inky target = %v, want (114,108)", pos)
	}
	if reverseDir(DirRight) != DirLeft || reverseDir(DirUp) != DirDown {
		t.Error("reverseDir wrong")
	}
}
