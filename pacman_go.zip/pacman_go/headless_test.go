package main

import "testing"

// Headless drivers: the same scenarios as the Nim port's
// tests/headless.nim, driving Game.Tick directly (no graphics, no
// audio output).

func pressAnyKey(g *Game) {
	g.Input.Anykey = true
	g.Tick()
	g.Input.Anykey = false
}

func countDots(g *Game) int {
	n := 0
	for y := 0; y < DisplayTilesY; y++ {
		for x := 0; x < DisplayTilesX; x++ {
			if g.Gfx.VideoRAM[y][x] == TileDot || g.Gfx.VideoRAM[y][x] == TilePill {
				n++
			}
		}
	}
	return n
}

// steerDir does a BFS over non-blocking tiles to the nearest dot/pill
// and returns the first step direction.
func steerDir(g *Game) Dir {
	startT := pixelToTilePos(g.Play.Pacman.Actor.Pos)
	var visited [DisplayTilesY][DisplayTilesX]bool
	var firstStep [DisplayTilesY][DisplayTilesX]Dir
	queue := []Int2{startT}
	visited[startT.Y][startT.X] = true
	dirs := [4]Dir{DirUp, DirLeft, DirDown, DirRight}
	for len(queue) > 0 {
		cur := queue[0]
		queue = queue[1:]
		if cur != startT && (g.isDot(cur) || g.isPill(cur)) {
			return firstStep[cur.Y][cur.X]
		}
		for _, d := range dirs {
			n := cur.Add(dirToVec(d))
			if n.X >= 0 && n.X < DisplayTilesX && n.Y >= 0 && n.Y < DisplayTilesY &&
				!visited[n.Y][n.X] && !g.isBlockingTile(n) {
				visited[n.Y][n.X] = true
				if cur == startT {
					firstStep[n.Y][n.X] = d
				} else {
					firstStep[n.Y][n.X] = firstStep[cur.Y][cur.X]
				}
				queue = append(queue, n)
			}
		}
	}
	return g.Play.Pacman.Actor.Dir
}

func setInput(g *Game, d Dir) {
	g.Input.Up = d == DirUp
	g.Input.Down = d == DirDown
	g.Input.Left = d == DirLeft
	g.Input.Right = d == DirRight
}

// toGameplay boots a fresh game and advances to running gameplay.
func toGameplay(t *testing.T) *Game {
	t.Helper()
	g := NewGame()
	for i := 0; i < 100; i++ {
		g.Tick()
	}
	pressAnyKey(g)
	for i := 0; i < 2000; i++ {
		g.Tick()
		if g.Scene == SceneGame && g.Play.Freeze.Empty() {
			return g
		}
	}
	t.Fatal("never reached gameplay")
	return nil
}

func TestHeadlessPlay(t *testing.T) {
	g := NewGame()
	for i := 0; i < 100; i++ {
		g.Tick()
	}
	if g.Scene != SceneIntro {
		t.Fatalf("scene = %v, want intro", g.Scene)
	}
	pressAnyKey(g)
	sawGame := false
	inkyLeftHouse := false
	maxGhostsOut := 0
	for i := 0; i < 60000; i++ {
		g.Tick()
		if g.Scene == SceneGame {
			if !sawGame {
				sawGame = true
				if n := countDots(g); n != 244 {
					t.Fatalf("playfield starts with %d dots/pills, want 244", n)
				}
			}
			if g.Play.Freeze.Empty() {
				setInput(g, steerDir(g))
			}
			outCount := 0
			for _, gh := range g.Play.Ghost {
				if gh.State != GhostStateHouse {
					outCount++
				}
			}
			if outCount > maxGhostsOut {
				maxGhostsOut = outCount
			}
			if g.Play.Ghost[GhostInky].State != GhostStateHouse {
				inkyLeftHouse = true
			}
		}
	}
	if !sawGame {
		t.Fatal("never entered the game scene")
	}
	t.Logf("score=%d dotsEaten=%d lives=%d round=%d scene=%v maxGhostsOut=%d inkyLeft=%v",
		g.Play.Score, g.Play.NumDotsEaten, g.Play.NumLives, g.Play.Round,
		g.Scene, maxGhostsOut, inkyLeftHouse)
	if g.Play.Score == 0 {
		t.Error("score must be > 0 after 60000 ticks of autopilot")
	}
	if maxGhostsOut < 3 {
		t.Errorf("maxGhostsOut = %d, want >= 3", maxGhostsOut)
	}
}

func TestDeterminism(t *testing.T) {
	runShort := func() [6]int64 {
		g := NewGame()
		for i := 0; i < 100; i++ {
			g.Tick()
		}
		pressAnyKey(g)
		for i := 0; i < 20000; i++ {
			g.Tick()
			if g.Scene == SceneGame && g.Play.Freeze.Empty() {
				setInput(g, steerDir(g))
			}
		}
		return [6]int64{
			int64(g.Play.Score), int64(g.Play.NumDotsEaten),
			int64(g.Play.Pacman.Actor.Pos.X), int64(g.Play.Pacman.Actor.Pos.Y),
			int64(g.Play.Ghost[0].Actor.Pos.X), int64(g.Play.Ghost[0].Actor.Pos.Y),
		}
	}
	r1, r2 := runShort(), runShort()
	if r1 != r2 {
		t.Errorf("determinism broken: %v vs %v", r1, r2)
	}
}

func TestWinScenario(t *testing.T) {
	g := NewGame()
	for i := 0; i < 100; i++ {
		g.Tick()
	}
	pressAnyKey(g)
	for i := 0; i < 1000; i++ {
		g.Tick()
		if g.Scene == SceneGame &&
			!g.Play.Freeze.Has(FreezeReady) && !g.Play.Freeze.Has(FreezePrelude) {
			break
		}
	}
	// remove all dots except the one at (1,4) and pretend 243 were eaten
	for y := 0; y < DisplayTilesY; y++ {
		for x := 0; x < DisplayTilesX; x++ {
			if g.Gfx.VideoRAM[y][x] == TileDot || g.Gfx.VideoRAM[y][x] == TilePill {
				g.Gfx.VideoRAM[y][x] = TileSpace
			}
		}
	}
	g.Gfx.VideoRAM[4][1] = TileDot
	g.Play.NumDotsEaten = 243
	// place Pacman just right of the dot, heading left
	g.Play.Pacman.Actor.Pos = I2(2*8+4, 4*8+4)
	g.Play.Pacman.Actor.Dir = DirLeft
	setInput(g, DirLeft)
	won := false
	for i := 0; i < 2000; i++ {
		g.Tick()
		if g.Play.Freeze.Has(FreezeWon) {
			won = true
		}
		if won && g.Play.Round == 1 && countDots(g) == 244 {
			break
		}
	}
	if !won {
		t.Error("round was not won")
	}
	if g.Play.Round != 1 {
		t.Errorf("round = %d, want 1", g.Play.Round)
	}
	if n := countDots(g); n != 244 {
		t.Errorf("dots after win = %d, want 244", n)
	}
	if g.Play.GlobalDotCounterActive {
		t.Error("global dot counter must be inactive after a win")
	}
}
