// timing.go -- the time-trigger vocabulary and input helpers.
// Corresponds to pacman.c lines 826-943 (xorshift, triggers, input).
//
// Unlike the C and Nim versions, Trigger methods here take the current
// tick as an argument instead of reading a global, which keeps the
// vocabulary usable from headless tests.
package main

// xorshift32 is the xorshift random number generator (pacman.c 827-833).
func (p *PlayState) xorshift32() uint32 {
	x := p.Xorshift
	x ^= x << 13
	x ^= x >> 17
	x ^= x << 5
	p.Xorshift = x
	return x
}

// Start sets the trigger to the next game tick.
func (t *Trigger) Start(now uint32) { t.Tick = now + 1 }

// StartAfter sets the trigger to a future tick.
func (t *Trigger) StartAfter(now, ticks uint32) { t.Tick = now + ticks }

// Disable deactivates the trigger.
func (t *Trigger) Disable() { t.Tick = DisabledTicks }

// DisabledTrigger returns a deactivated trigger.
func DisabledTrigger() Trigger { return Trigger{Tick: DisabledTicks} }

// Now reports whether the trigger fires at the given tick.
func (t Trigger) Now(now uint32) bool { return t.Tick == now }

// Since returns the number of ticks since the trigger fired.
func (t Trigger) Since(now uint32) uint32 {
	if now >= t.Tick {
		return now - t.Tick
	}
	return DisabledTicks
}

// Between reports whether the trigger fired between begin and end
// ticks ago (begin <= since < end).
func (t Trigger) Between(now, begin, end uint32) bool {
	if begin >= end {
		panic("Trigger.Between: begin must be < end")
	}
	if t.Tick == DisabledTicks {
		return false
	}
	s := t.Since(now)
	return s >= begin && s < end
}

// AfterOnce reports whether the trigger fired exactly n ticks ago.
func (t Trigger) AfterOnce(now, n uint32) bool { return t.Since(now) == n }

// After reports whether the trigger fired at least n ticks ago.
func (t Trigger) After(now, n uint32) bool {
	s := t.Since(now)
	if s != DisabledTicks {
		return s >= n
	}
	return false
}

// Before reports whether the trigger fired less than n ticks ago.
func (t Trigger) Before(now, n uint32) bool {
	s := t.Since(now)
	if s != DisabledTicks {
		return s < n
	}
	return false
}

// Disable clears the input state and disables input (C: input_disable).
func (in *InputState) Disable() { *in = InputState{} }

// Enable enables input again (C: input_enable).
func (in *InputState) Enable() { in.Enabled = true }

// DirOr returns the currently wanted direction, or the given default
// (C: input_dir). Priority is up, down, right, left.
func (in InputState) DirOr(def Dir) Dir {
	switch {
	case in.Up:
		return DirUp
	case in.Down:
		return DirDown
	case in.Right:
		return DirRight
	case in.Left:
		return DirLeft
	default:
		return def
	}
}
