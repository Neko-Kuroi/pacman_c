# pacman.c TypeScript 移植

floooh/pacman.c（C99、4,303行）を TypeScript へ移植し、
ブラウザで動かす実装。構造は Nim 版移植のモジュール分割に倣い、
土台はブラウザ標準 API（Canvas 2D / WebAudio / DOM）のみで、
ゲーム用ライブラリは使わない。仕様の決定は SPEC.md（T1〜T10）。

## 動かし方

ビルドには Node.js と npm が要る（TypeScript 5.9.3 を使用）。

```
npm install
npm run build
```

そのあと、フォルダを静的サーバーで配信して index.html を開く
（ES モジュールと AudioWorklet のため file:// では動かない）。

```
npx serve .
# または
python3 -m http.server
```

操作: 何かキーを押すと開始。矢印キー（または WASD）で移動、
F で全画面。タッチでも遊べる（タップで開始、
スワイプで移動、方向は次のスワイプまで持続）。
音は最初のキー操作やタップのあとに出る
（ブラウザの自動再生ポリシーのため）。

## テスト

```
npm test
```

Node 上で全テストを実行する（基礎・ヘッドレス検証・
挙動プローブ・音響・入力・描画・同着レースの 27 件）。ヘッドレス検証は
60,000 ティックの自動プレイで、Nim 版・Go 版と同じ
スコア 350・ドット 66 になることを合格条件にしている。

## データの再生成

ROM データ（src/romdata.ts）は pacman.c から機械生成する。
手で編集しないこと。

```
npm run data    # ../floooh-pacman-c/pacman.c から再生成
```

## 構成

| ファイル | 役割 |
|---|---|
| src/state.ts | 定数・型・状態オブジェクト |
| src/timing.ts | トリガー、乱数、入力の語彙 |
| src/geom.ts | 座標と盤面の問い合わせ |
| src/ghost.ts | ゴーストの思考 |
| src/rules.ts | ルールと場面、1ティックの実行 |
| src/render.ts | 描画（状態層 + Canvas） |
| src/sound.ts | 音（レジスタ層） |
| src/synth.ts | 音の合成コア（Worklet と共用） |
| src/worklet.ts | AudioWorklet プロセッサ |
| src/input.ts | 入力（キーボード、合流点） |
| src/main.ts | 入り口（rAF の蓄積ループ） |
| src/romdata.ts | ROM データ（生成） |
