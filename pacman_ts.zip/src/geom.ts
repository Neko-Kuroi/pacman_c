// geom.ts -- geometry and playfield queries.
// Corresponds to pacman.c lines 988-991 and 1230-1361.

import {
  state,
  i2,
  add,
  TILE_WIDTH,
  TILE_HEIGHT,
  DISPLAY_TILES_X,
  DISPLAY_TILES_Y,
  DISPLAY_PIXELS_X,
  TILE_DOT,
  TILE_PILL,
  Dir,
  type Int2,
} from './state.js';

// Integer division truncating toward zero, matching C and Nim's div.
// (JavaScript's / is floating-point division; Math.trunc restores the
// integer semantics where the original relies on them, SPEC T5.)
export function idiv(a: number, b: number): number {
  return Math.trunc(a / b);
}

// Note: no cmod helper is needed here. JavaScript's % operator already
// truncates toward zero exactly like C's %, unlike Python's %.
export function distToTileMid(pos: Int2): Int2 {
  return i2(
    (TILE_WIDTH >> 1) - (pos.x % TILE_WIDTH),
    (TILE_HEIGHT >> 1) - (pos.y % TILE_HEIGHT),
  );
}

export function pixelToTilePos(pixPos: Int2): Int2 {
  return i2(idiv(pixPos.x, TILE_WIDTH), idiv(pixPos.y, TILE_HEIGHT));
}

// clamp tile pos to valid playfield coords
export function clampedTilePos(tilePos: Int2): Int2 {
  const result = i2(tilePos.x, tilePos.y);
  if (result.x < 0) {
    result.x = 0;
  } else if (result.x >= DISPLAY_TILES_X) {
    result.x = DISPLAY_TILES_X - 1;
  }
  if (result.y < 3) {
    result.y = 3;
  } else if (result.y >= DISPLAY_TILES_Y - 2) {
    result.y = DISPLAY_TILES_Y - 3;
  }
  return result;
}

const dirMap: Int2[] = [i2(1, 0), i2(0, 1), i2(-1, 0), i2(0, -1)];
// dirToVec hands out these vectors by reference; freeze them (and
// the table) so a stray in-place write cannot corrupt every caller.
for (const v of dirMap) Object.freeze(v);
Object.freeze(dirMap);

export function dirToVec(dir: Dir): Int2 {
  if (!(dir >= Dir.DIR_RIGHT && dir < Dir.NUM_DIRS)) throw new Error('dirToVec: bad dir');
  return dirMap[dir]!;
}

export function reverseDir(dir: Dir): Dir {
  switch (dir) {
    case Dir.DIR_RIGHT:
      return Dir.DIR_LEFT;
    case Dir.DIR_DOWN:
      return Dir.DIR_UP;
    case Dir.DIR_LEFT:
      return Dir.DIR_RIGHT;
    default:
      return Dir.DIR_DOWN;
  }
}

export function tileCodeAt(tilePos: Int2): number {
  if (
    !(tilePos.x >= 0 && tilePos.x < DISPLAY_TILES_X) ||
    !(tilePos.y >= 0 && tilePos.y < DISPLAY_TILES_Y)
  ) {
    throw new Error('tileCodeAt: out of range');
  }
  return state.gfx.videoRam[tilePos.y]![tilePos.x]!;
}

export function isBlockingTile(tilePos: Int2): boolean {
  return tileCodeAt(tilePos) >= 0xc0;
}

export function isDot(tilePos: Int2): boolean {
  return tileCodeAt(tilePos) === TILE_DOT;
}

export function isPill(tilePos: Int2): boolean {
  return tileCodeAt(tilePos) === TILE_PILL;
}

export function isTunnel(tilePos: Int2): boolean {
  return tilePos.y === 17 && (tilePos.x <= 5 || tilePos.x >= 22);
}

// positions where upward movement is forbidden for ghosts
export function isRedzone(tilePos: Int2): boolean {
  return tilePos.x >= 11 && tilePos.x <= 16 && (tilePos.y === 14 || tilePos.y === 26);
}

// test if movement from a pixel position in a wanted direction is possible
export function canMove(pos: Int2, wantedDir: Dir, allowCornering: boolean): boolean {
  const dirVec = dirToVec(wantedDir);
  const distMid = distToTileMid(pos);
  let moveDistMid: number;
  let perpDistMid: number;
  if (dirVec.y !== 0) {
    moveDistMid = distMid.y;
    perpDistMid = distMid.x;
  } else {
    moveDistMid = distMid.x;
    perpDistMid = distMid.y;
  }
  const tilePos = pixelToTilePos(pos);
  const checkPos = clampedTilePos(add(tilePos, dirVec));
  const blocked = isBlockingTile(checkPos);
  return !((!allowCornering && perpDistMid !== 0) || (blocked && moveDistMid === 0));
}

// compute a new pixel position along a direction (without blocking check)
export function move(pos: Int2, dir: Dir, allowCornering: boolean): Int2 {
  const dirVec = dirToVec(dir);
  const result = add(pos, dirVec);
  if (allowCornering) {
    const distMid = distToTileMid(result);
    if (dirVec.x !== 0) {
      if (distMid.y < 0) result.y -= 1;
      else if (distMid.y > 0) result.y += 1;
    } else if (dirVec.y !== 0) {
      if (distMid.x < 0) result.x -= 1;
      else if (distMid.x > 0) result.x += 1;
    }
  }
  if (result.x < 0) {
    result.x = DISPLAY_PIXELS_X - 1;
  } else if (result.x >= DISPLAY_PIXELS_X) {
    result.x = 0;
  }
  return result;
}
