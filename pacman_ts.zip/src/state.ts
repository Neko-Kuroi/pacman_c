// state.ts -- constants, types and the single global state object.
// Corresponds to pacman.c lines 142-678 (config, enums, structs, data tables).
// Inside this module the writing follows TypeScript conventions where the
// C code's intent allows it (e.g. freeze flags are a Set, not a bitfield).
// See SPEC.md (T5) for the numeric-semantics rules: values that are
// integers by design pass through |0 / >>>0 at the boundaries.

// --- config (pacman.c 144-152) ---
export const AUDIO_VOLUME = 0.5;

// --- global constants (pacman.c 161-193) ---
export const TICK_DURATION_NS = 16_666_666;
export const TICK_TOLERANCE_NS = 1_000_000;
export const NUM_VOICES = 3;
export const NUM_SOUNDS = 3;
export const NUM_SAMPLES = 128;
export const DISABLED_TICKS = 0xFFFFFFFF;
export const TILE_WIDTH = 8;
export const TILE_HEIGHT = 8;
export const SPRITE_WIDTH = 16;
export const SPRITE_HEIGHT = 16;
export const DISPLAY_TILES_X = 28;
export const DISPLAY_TILES_Y = 36;
export const DISPLAY_PIXELS_X = DISPLAY_TILES_X * TILE_WIDTH;
export const DISPLAY_PIXELS_Y = DISPLAY_TILES_Y * TILE_HEIGHT;
export const NUM_SPRITES = 8;
export const NUM_DEBUG_MARKERS = 16;
export const TILE_TEXTURE_WIDTH = 256 * TILE_WIDTH;
export const TILE_TEXTURE_HEIGHT = TILE_HEIGHT + SPRITE_HEIGHT;
export const FADE_TICKS = 30;
export const NUM_LIVES = 3;
export const NUM_STATUS_FRUITS = 7;
export const NUM_DOTS = 244;
export const NUM_PILLS = 4;
export const ANTEPORTAS_X = 14 * TILE_WIDTH;
export const ANTEPORTAS_Y = 14 * TILE_HEIGHT + (TILE_HEIGHT >> 1);
export const GHOST_EATEN_FREEZE_TICKS = 60;
export const PACMAN_EATEN_TICKS = 60;
export const PACMAN_DEATH_TICKS = 150;
export const GAMEOVER_TICKS = 3 * 60;
export const ROUNDWON_TICKS = 4 * 60;
export const FRUITACTIVE_TICKS = 10 * 60;

// --- tile, sprite and color codes (pacman.c 198-248) ---
export const TILE_SPACE = 0x40;
export const TILE_DOT = 0x10;
export const TILE_PILL = 0x14;
export const TILE_GHOST = 0xB0;
export const TILE_LIFE = 0x20;
export const TILE_CHERRIES = 0x90;
export const TILE_STRAWBERRY = 0x94;
export const TILE_PEACH = 0x98;
export const TILE_BELL = 0x9C;
export const TILE_APPLE = 0xA0;
export const TILE_GRAPES = 0xA4;
export const TILE_GALAXIAN = 0xA8;
export const TILE_KEY = 0xAC;
export const TILE_DOOR = 0xCF;

export const SPRITETILE_INVISIBLE = 30;
export const SPRITETILE_SCORE_200 = 40;
export const SPRITETILE_SCORE_400 = 41;
export const SPRITETILE_SCORE_800 = 42;
export const SPRITETILE_SCORE_1600 = 43;
export const SPRITETILE_CHERRIES = 0;
export const SPRITETILE_STRAWBERRY = 1;
export const SPRITETILE_PEACH = 2;
export const SPRITETILE_BELL = 3;
export const SPRITETILE_APPLE = 4;
export const SPRITETILE_GRAPES = 5;
export const SPRITETILE_GALAXIAN = 6;
export const SPRITETILE_KEY = 7;
export const SPRITETILE_PACMAN_CLOSED_MOUTH = 48;

export const COLOR_BLANK = 0x00;
export const COLOR_DEFAULT = 0x0F;
export const COLOR_DOT = 0x10;
export const COLOR_PACMAN = 0x09;
export const COLOR_BLINKY = 0x01;
export const COLOR_PINKY = 0x03;
export const COLOR_INKY = 0x05;
export const COLOR_CLYDE = 0x07;
export const COLOR_FRIGHTENED = 0x11;
export const COLOR_FRIGHTENED_BLINKING = 0x12;
export const COLOR_GHOST_SCORE = 0x18;
export const COLOR_EYES = 0x19;
export const COLOR_CHERRIES = 0x14;
export const COLOR_STRAWBERRY = 0x0F;
export const COLOR_PEACH = 0x15;
export const COLOR_BELL = 0x16;
export const COLOR_APPLE = 0x14;
export const COLOR_GRAPES = 0x17;
export const COLOR_GALAXIAN = 0x09;
export const COLOR_KEY = 0x16;
export const COLOR_WHITE_BORDER = 0x1F;
export const COLOR_FRUIT_SCORE = 0x03;

// --- enums (pacman.c 254-320) ---
export enum GameState {
  GAMESTATE_INTRO,
  GAMESTATE_GAME,
}

// NOTE: bit0==0: horizontal movement, bit0==1: vertical movement
export enum Dir {
  DIR_RIGHT,
  DIR_DOWN,
  DIR_LEFT,
  DIR_UP,
  NUM_DIRS,
}

export enum Fruit {
  FRUIT_NONE,
  FRUIT_CHERRIES,
  FRUIT_STRAWBERRY,
  FRUIT_PEACH,
  FRUIT_APPLE,
  FRUIT_GRAPES,
  FRUIT_GALAXIAN,
  FRUIT_BELL,
  FRUIT_KEY,
  NUM_FRUITS,
}

export enum SpriteIndex {
  SPRITE_PACMAN,
  SPRITE_BLINKY,
  SPRITE_PINKY,
  SPRITE_INKY,
  SPRITE_CLYDE,
  SPRITE_FRUIT,
}

export enum GhostType {
  GHOSTTYPE_BLINKY,
  GHOSTTYPE_PINKY,
  GHOSTTYPE_INKY,
  GHOSTTYPE_CLYDE,
  NUM_GHOSTS,
}

export enum GhostState {
  GHOSTSTATE_NONE,
  GHOSTSTATE_CHASE,
  GHOSTSTATE_SCATTER,
  GHOSTSTATE_FRIGHTENED,
  GHOSTSTATE_EYES,
  GHOSTSTATE_HOUSE,
  GHOSTSTATE_LEAVEHOUSE,
  GHOSTSTATE_ENTERHOUSE,
}

// In C these are (1<<n) bit values in a uint8. Here they are the members
// of a Set, so the enum values are just distinct tags (SPEC T6).
export enum FreezeType {
  FREEZETYPE_PRELUDE,
  FREEZETYPE_READY,
  FREEZETYPE_EAT_GHOST,
  FREEZETYPE_DEAD,
  FREEZETYPE_WON,
}

export enum SoundFlag {
  SOUNDFLAG_VOICE0,
  SOUNDFLAG_VOICE1,
  SOUNDFLAG_VOICE2,
}

export const SOUNDFLAG_ALL_VOICES: ReadonlySet<SoundFlag> = new Set([
  SoundFlag.SOUNDFLAG_VOICE0,
  SoundFlag.SOUNDFLAG_VOICE1,
  SoundFlag.SOUNDFLAG_VOICE2,
]);

// --- basic types (pacman.c 323-352) ---
export interface Trigger {
  tick: number; // uint32 by design (DISABLED_TICKS when inactive)
}

export function newTrigger(): Trigger {
  return { tick: 0 };
}

export interface Int2 {
  x: number; // int16 by design
  y: number;
}

export function i2(x: number, y: number): Int2 {
  return { x, y };
}

export function add(v0: Int2, v1: Int2): Int2 {
  return i2(v0.x + v1.x, v0.y + v1.y);
}

export function sub(v0: Int2, v1: Int2): Int2 {
  return i2(v0.x - v1.x, v0.y - v1.y);
}

export function scale(v: Int2, s: number): Int2 {
  return i2(v.x * s, v.y * s);
}

export function squaredDistance(v0: Int2, v1: Int2): number {
  const dx = v1.x - v0.x;
  const dy = v1.y - v0.y;
  return dx * dx + dy * dy;
}

export function nearEqual(v0: Int2, v1: Int2, tolerance: number): boolean {
  return Math.abs(v1.x - v0.x) <= tolerance && Math.abs(v1.y - v0.y) <= tolerance;
}

export function actorToSpritePos(pos: Int2): Int2 {
  return i2(pos.x - (SPRITE_WIDTH >> 1), pos.y - (SPRITE_HEIGHT >> 1));
}

export interface Actor {
  dir: Dir;
  pos: Int2;
  animTick: number; // uint32
}

export function newActor(): Actor {
  return { dir: Dir.DIR_RIGHT, pos: i2(0, 0), animTick: 0 };
}

export interface Ghost {
  actor: Actor;
  typ: GhostType;
  nextDir: Dir;
  targetPos: Int2;
  state: GhostState;
  frightened: Trigger;
  eaten: Trigger;
  dotCounter: number; // uint16
  dotLimit: number; // uint16
}

export function newGhost(): Ghost {
  return {
    actor: newActor(),
    typ: GhostType.GHOSTTYPE_BLINKY,
    nextDir: Dir.DIR_RIGHT,
    targetPos: i2(0, 0),
    state: GhostState.GHOSTSTATE_NONE,
    frightened: newTrigger(),
    eaten: newTrigger(),
    dotCounter: 0,
    dotLimit: 0,
  };
}

export interface Pacman {
  actor: Actor;
}

// --- renderer types (pacman.c 360-385) ---
export interface Sprite {
  enabled: boolean;
  tile: number; // uint8
  color: number; // uint8
  flipx: boolean;
  flipy: boolean;
  pos: Int2;
}

export function newSprite(): Sprite {
  return { enabled: false, tile: 0, color: 0, flipx: false, flipy: false, pos: i2(0, 0) };
}

export interface DebugMarker {
  enabled: boolean;
  tile: number; // uint8
  color: number; // uint8
  tilePos: Int2;
}

export function newDebugMarker(): DebugMarker {
  return { enabled: false, tile: 0, color: 0, tilePos: i2(0, 0) };
}

// --- sound types (pacman.c 388-418) ---
// A sound generator is identified by its index into the generator table
// in synth.ts, so that sound state stays serializable for the
// AudioWorklet boundary (SPEC T3). -1 means "no generator".
export type SoundFuncId = number;
export const NO_SOUND_FUNC: SoundFuncId = -1;

export interface SoundDesc {
  fn: SoundFuncId;
  data: Uint32Array | null; // register dump data (null for procedural sounds)
  size: number; // byte size of register dump data
  voice: [boolean, boolean, boolean];
}

export interface Voice {
  counter: number; // uint32
  frequency: number; // uint32
  waveform: number; // uint8
  volume: number; // uint8
  sampleAcc: number; // float32 by design
  sampleDiv: number; // float32 by design
}

export function newVoice(): Voice {
  return { counter: 0, frequency: 0, waveform: 0, volume: 0, sampleAcc: 0, sampleDiv: 0 };
}

export interface Sound {
  curTick: number; // uint32
  fn: SoundFuncId;
  numTicks: number; // uint32
  stride: number; // uint32
  data: Uint32Array | null;
  flags: Set<SoundFlag>;
}

export function newSound(): Sound {
  return {
    curTick: 0,
    fn: NO_SOUND_FUNC,
    numTicks: 0,
    stride: 0,
    data: null,
    flags: new Set<SoundFlag>(),
  };
}

// --- the global state (pacman.c 420-540) ---
export interface TimingState {
  tick: number; // uint32
  laptimeStore: number; // milliseconds from performance.now()
  tickAccum: number; // nanoseconds remainder (exact in float64 here)
}

export interface IntroState {
  started: Trigger;
}

export interface Game {
  xorshift: number; // uint32
  hiscore: number; // uint32
  started: Trigger;
  readyStarted: Trigger;
  roundStarted: Trigger;
  roundWon: Trigger;
  gameOver: Trigger;
  dotEaten: Trigger;
  pillEaten: Trigger;
  ghostEaten: Trigger;
  pacmanEaten: Trigger;
  fruitEaten: Trigger;
  forceLeaveHouse: Trigger;
  fruitActive: Trigger;
  freeze: Set<FreezeType>;
  round: number; // uint8
  score: number; // uint32, in 10-point units
  numLives: number; // int8
  numGhostsEaten: number; // uint8
  numDotsEaten: number; // uint8
  globalDotCounterActive: boolean;
  globalDotCounter: number; // uint8
  ghost: Ghost[];
  pacman: Pacman;
  activeFruit: Fruit;
}

export function newGame(): Game {
  return {
    xorshift: 0,
    hiscore: 0,
    started: newTrigger(),
    readyStarted: newTrigger(),
    roundStarted: newTrigger(),
    roundWon: newTrigger(),
    gameOver: newTrigger(),
    dotEaten: newTrigger(),
    pillEaten: newTrigger(),
    ghostEaten: newTrigger(),
    pacmanEaten: newTrigger(),
    fruitEaten: newTrigger(),
    forceLeaveHouse: newTrigger(),
    fruitActive: newTrigger(),
    freeze: new Set<FreezeType>(),
    round: 0,
    score: 0,
    numLives: 0,
    numGhostsEaten: 0,
    numDotsEaten: 0,
    globalDotCounterActive: false,
    globalDotCounter: 0,
    ghost: [newGhost(), newGhost(), newGhost(), newGhost()],
    pacman: { actor: newActor() },
    activeFruit: Fruit.FRUIT_NONE,
  };
}

export interface InputState {
  enabled: boolean;
  up: boolean;
  down: boolean;
  left: boolean;
  right: boolean;
  esc: boolean;
  anykey: boolean;
}

export function newInputState(): InputState {
  return { enabled: false, up: false, down: false, left: false, right: false, esc: false, anykey: false };
}

export interface AudioState {
  voice: Voice[];
  sound: Sound[];
}

export function newAudioState(): AudioState {
  return {
    voice: [newVoice(), newVoice(), newVoice()],
    sound: [newSound(), newSound(), newSound()],
  };
}

export interface GfxState {
  fadein: Trigger;
  fadeout: Trigger;
  fade: number; // uint8
  videoRam: number[][]; // [DISPLAY_TILES_Y][DISPLAY_TILES_X] of uint8
  colorRam: number[][];
  sprite: Sprite[];
  debugMarker: DebugMarker[];
  tilePixels: Uint8Array; // [TILE_TEXTURE_HEIGHT * TILE_TEXTURE_WIDTH]
  colorPalette: Uint32Array; // [256]
}

export function newGfxState(): GfxState {
  const ram = () =>
    Array.from({ length: DISPLAY_TILES_Y }, () => new Array<number>(DISPLAY_TILES_X).fill(0));
  return {
    fadein: newTrigger(),
    fadeout: newTrigger(),
    fade: 0,
    videoRam: ram(),
    colorRam: ram(),
    sprite: Array.from({ length: NUM_SPRITES }, () => newSprite()),
    debugMarker: Array.from({ length: NUM_DEBUG_MARKERS }, () => newDebugMarker()),
    tilePixels: new Uint8Array(TILE_TEXTURE_WIDTH * TILE_TEXTURE_HEIGHT),
    colorPalette: new Uint32Array(256),
  };
}

export interface State {
  gamestate: GameState;
  timing: TimingState;
  intro: IntroState;
  game: Game;
  input: InputState;
  audio: AudioState;
  gfx: GfxState;
}

export function newState(): State {
  return {
    gamestate: GameState.GAMESTATE_INTRO,
    timing: { tick: 0, laptimeStore: 0, tickAccum: 0 },
    intro: { started: newTrigger() },
    game: newGame(),
    input: newInputState(),
    audio: newAudioState(),
    gfx: newGfxState(),
  };
}

export const state: State = newState();

// --- data tables (pacman.c 542-623) ---
export const ghostScatterTargets: Int2[] = [i2(25, 0), i2(2, 0), i2(27, 34), i2(0, 34)];

// starting positions for ghosts (pixel coords), pacman.c 548-553
export const ghostStartingPos: Int2[] = [
  i2(14 * 8, 14 * 8 + 4),
  i2(14 * 8, 17 * 8 + 4),
  i2(12 * 8, 17 * 8 + 4),
  i2(16 * 8, 17 * 8 + 4),
];

// target positions for ghosts entering the ghost house, pacman.c 556-561
export const ghostHouseTargetPos: Int2[] = [
  i2(14 * 8, 17 * 8 + 4),
  i2(14 * 8, 17 * 8 + 4),
  i2(12 * 8, 17 * 8 + 4),
  i2(16 * 8, 17 * 8 + 4),
];

// The position tables above are shared by reference (a ghost's
// targetPos or starting pos IS the table entry until movement
// replaces it with a fresh object). In C these are static const and
// in Nim value copies; here they are frozen instead, so an
// accidental in-place write throws instead of silently corrupting
// the table for everyone.
for (const table of [ghostScatterTargets, ghostStartingPos, ghostHouseTargetPos]) {
  for (const p of table) Object.freeze(p);
  Object.freeze(table);
}

export const fruitTilesColors: number[][] = [
  [0, 0, 0],
  [TILE_CHERRIES, SPRITETILE_CHERRIES, COLOR_CHERRIES],
  [TILE_STRAWBERRY, SPRITETILE_STRAWBERRY, COLOR_STRAWBERRY],
  [TILE_PEACH, SPRITETILE_PEACH, COLOR_PEACH],
  [TILE_APPLE, SPRITETILE_APPLE, COLOR_APPLE],
  [TILE_GRAPES, SPRITETILE_GRAPES, COLOR_GRAPES],
  [TILE_GALAXIAN, SPRITETILE_GALAXIAN, COLOR_GALAXIAN],
  [TILE_BELL, SPRITETILE_BELL, COLOR_BELL],
  [TILE_KEY, SPRITETILE_KEY, COLOR_KEY],
];

export const fruitScoreTiles: number[][] = [
  [0x40, 0x40, 0x40, 0x40],
  [0x40, 0x81, 0x85, 0x40],
  [0x40, 0x82, 0x85, 0x40],
  [0x40, 0x83, 0x85, 0x40],
  [0x40, 0x84, 0x85, 0x40],
  [0x40, 0x86, 0x8d, 0x8e],
  [0x87, 0x88, 0x8d, 0x8e],
  [0x89, 0x8a, 0x8d, 0x8e],
  [0x8b, 0x8c, 0x8d, 0x8e],
];

export interface LevelSpec {
  bonusFruit: Fruit;
  bonusScore: number; // uint16
  frightTicks: number; // uint16
}

export const MAX_LEVELSPEC = 21;
export const levelspecTable: LevelSpec[] = [
  { bonusFruit: Fruit.FRUIT_CHERRIES, bonusScore: 10, frightTicks: 6 * 60 },
  { bonusFruit: Fruit.FRUIT_STRAWBERRY, bonusScore: 30, frightTicks: 5 * 60 },
  { bonusFruit: Fruit.FRUIT_PEACH, bonusScore: 50, frightTicks: 4 * 60 },
  { bonusFruit: Fruit.FRUIT_PEACH, bonusScore: 50, frightTicks: 3 * 60 },
  { bonusFruit: Fruit.FRUIT_APPLE, bonusScore: 70, frightTicks: 2 * 60 },
  { bonusFruit: Fruit.FRUIT_APPLE, bonusScore: 70, frightTicks: 5 * 60 },
  { bonusFruit: Fruit.FRUIT_GRAPES, bonusScore: 100, frightTicks: 2 * 60 },
  { bonusFruit: Fruit.FRUIT_GRAPES, bonusScore: 100, frightTicks: 2 * 60 },
  { bonusFruit: Fruit.FRUIT_GALAXIAN, bonusScore: 200, frightTicks: 1 * 60 },
  { bonusFruit: Fruit.FRUIT_GALAXIAN, bonusScore: 200, frightTicks: 5 * 60 },
  { bonusFruit: Fruit.FRUIT_BELL, bonusScore: 300, frightTicks: 2 * 60 },
  { bonusFruit: Fruit.FRUIT_BELL, bonusScore: 300, frightTicks: 1 * 60 },
  { bonusFruit: Fruit.FRUIT_KEY, bonusScore: 500, frightTicks: 1 * 60 },
  { bonusFruit: Fruit.FRUIT_KEY, bonusScore: 500, frightTicks: 3 * 60 },
  { bonusFruit: Fruit.FRUIT_KEY, bonusScore: 500, frightTicks: 1 * 60 },
  { bonusFruit: Fruit.FRUIT_KEY, bonusScore: 500, frightTicks: 1 * 60 },
  { bonusFruit: Fruit.FRUIT_KEY, bonusScore: 500, frightTicks: 1 },
  { bonusFruit: Fruit.FRUIT_KEY, bonusScore: 500, frightTicks: 1 * 60 },
  { bonusFruit: Fruit.FRUIT_KEY, bonusScore: 500, frightTicks: 1 },
  { bonusFruit: Fruit.FRUIT_KEY, bonusScore: 500, frightTicks: 1 },
  { bonusFruit: Fruit.FRUIT_KEY, bonusScore: 500, frightTicks: 1 },
];

// levelspec() hands out rows by reference; freeze them like the
// position tables above (callers only read).
for (const row of levelspecTable) Object.freeze(row);
Object.freeze(levelspecTable);

export function levelspec(round: number): LevelSpec {
  if (round < 0) throw new Error('levelspec: round < 0');
  const r = Math.min(round, MAX_LEVELSPEC - 1);
  return levelspecTable[r]!;
}
