// worklet.ts -- the AudioWorklet processor (SPEC T3). Runs on the
// audio rendering thread. The game side posts a voice register
// snapshot (sound.ts voiceSnapshot) once per game tick; this
// processor turns the snapshots into samples via Synth. Ambient
// declarations for this scope live in worklet.d.ts.

/// <reference path="./worklet.d.ts" />

import { Synth } from './synth.js';
import type { VoiceRegs } from './sound.js';

class PacmanSynthProcessor extends AudioWorkletProcessor {
  private readonly synth: Synth;

  constructor() {
    super();
    this.synth = new Synth(sampleRate);
    this.port.onmessage = (event: MessageEvent) => {
      this.synth.setVoices(event.data as VoiceRegs[]);
    };
  }

  process(
    _inputs: Float32Array[][],
    outputs: Float32Array[][],
  ): boolean {
    const channels = outputs[0]!;
    const left = channels[0]!;
    this.synth.render(left);
    if (channels.length > 1) {
      channels[1]!.set(left);
    }
    return true;
  }
}

registerProcessor('pacman-synth', PacmanSynthProcessor);
