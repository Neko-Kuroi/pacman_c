// render.ts -- video RAM writes, sprite animation, and the Canvas renderer.
// Corresponds to pacman.c lines 993-1229 (vid/spr), 1584-1732 (tile/sprite
// updates) and 2404-3124 (gfx subsystem; the sokol part is replaced by
// Canvas 2D pre-rendered images, SPEC T1).

import {
  state,
  i2,
  levelspec,
  TILE_WIDTH,
  TILE_HEIGHT,
  SPRITE_WIDTH,
  SPRITE_HEIGHT,
  DISPLAY_TILES_X,
  DISPLAY_TILES_Y,
  DISPLAY_PIXELS_X,
  DISPLAY_PIXELS_Y,
  NUM_SPRITES,
  NUM_DEBUG_MARKERS,
  NUM_PILLS,
  NUM_LIVES,
  NUM_STATUS_FRUITS,
  TILE_TEXTURE_WIDTH,
  TILE_TEXTURE_HEIGHT,
  TILE_LIFE,
  COLOR_DEFAULT,
  COLOR_DOT,
  COLOR_PACMAN,
  COLOR_BLINKY,
  COLOR_FRIGHTENED,
  COLOR_FRIGHTENED_BLINKING,
  COLOR_GHOST_SCORE,
  COLOR_EYES,
  COLOR_FRUIT_SCORE,
  COLOR_WHITE_BORDER,
  SPRITETILE_INVISIBLE,
  SPRITETILE_PACMAN_CLOSED_MOUTH,
  SPRITETILE_SCORE_200,
  FADE_TICKS,
  PACMAN_EATEN_TICKS,
  GHOST_EATEN_FREEZE_TICKS,
  Dir,
  Fruit,
  GhostType,
  GhostState,
  SpriteIndex,
  FreezeType,
  fruitScoreTiles,
  fruitTilesColors,
  actorToSpritePos,
  type Int2,
  type Sprite,
  type Trigger,
} from './state.js';
import { afterOnce, after, before, since, disable, between } from './timing.js';
import { idiv } from './geom.js';
import { romTiles, romSprites, romHWColors, romPalette } from './romdata.js';

// --- vid: writes into the tile/color buffers (pacman.c 993-1133) ---

export function vidClear(tileCode: number, colorCode: number): void {
  for (let y = 0; y < DISPLAY_TILES_Y; y++) {
    for (let x = 0; x < DISPLAY_TILES_X; x++) {
      state.gfx.videoRam[y]![x] = tileCode;
      state.gfx.colorRam[y]![x] = colorCode;
    }
  }
}

export function vidColorPlayfield(colorCode: number): void {
  for (let y = 3; y < DISPLAY_TILES_Y - 2; y++) {
    for (let x = 0; x < DISPLAY_TILES_X; x++) {
      state.gfx.colorRam[y]![x] = colorCode;
    }
  }
}

function validTilePos(tilePos: Int2): boolean {
  return (
    tilePos.x >= 0 &&
    tilePos.x < DISPLAY_TILES_X &&
    tilePos.y >= 0 &&
    tilePos.y < DISPLAY_TILES_Y
  );
}

export function vidColor(tilePos: Int2, colorCode: number): void {
  if (!validTilePos(tilePos)) throw new Error('vidColor: bad pos');
  state.gfx.colorRam[tilePos.y]![tilePos.x] = colorCode;
}

export function vidTile(tilePos: Int2, tileCode: number): void {
  if (!validTilePos(tilePos)) throw new Error('vidTile: bad pos');
  state.gfx.videoRam[tilePos.y]![tilePos.x] = tileCode;
}

export function vidColorTile(tilePos: Int2, colorCode: number, tileCode: number): void {
  if (!validTilePos(tilePos)) throw new Error('vidColorTile: bad pos');
  state.gfx.videoRam[tilePos.y]![tilePos.x] = tileCode;
  state.gfx.colorRam[tilePos.y]![tilePos.x] = colorCode;
}

// translate ASCII char into "NAMCO char"
function convChar(c: string): number {
  switch (c) {
    case ' ':
      return 0x40;
    case '/':
      return 58;
    case '-':
      return 59;
    case '"':
      return 38;
    case '!':
      return 'Z'.charCodeAt(0) + 1;
    default:
      return c.charCodeAt(0);
  }
}

function vidColorChar(tilePos: Int2, colorCode: number, chr: string): void {
  if (!validTilePos(tilePos)) throw new Error('vidColorChar: bad pos');
  state.gfx.videoRam[tilePos.y]![tilePos.x] = convChar(chr);
  state.gfx.colorRam[tilePos.y]![tilePos.x] = colorCode;
}

function vidChar(tilePos: Int2, chr: string): void {
  if (!validTilePos(tilePos)) throw new Error('vidChar: bad pos');
  state.gfx.videoRam[tilePos.y]![tilePos.x] = convChar(chr);
}

export function vidColorText(tilePos: Int2, colorCode: number, text: string): void {
  if (!validTilePos(tilePos)) throw new Error('vidColorText: bad pos');
  const tp = i2(tilePos.x, tilePos.y);
  for (const chr of text) {
    if (tp.x < DISPLAY_TILES_X) {
      vidColorChar(tp, colorCode, chr);
      tp.x += 1;
    } else {
      break;
    }
  }
}

export function vidText(tilePos: Int2, text: string): void {
  if (!validTilePos(tilePos)) throw new Error('vidText: bad pos');
  const tp = i2(tilePos.x, tilePos.y);
  for (const chr of text) {
    if (tp.x < DISPLAY_TILES_X) {
      vidChar(tp, chr);
      tp.x += 1;
    } else {
      break;
    }
  }
}

// print a score (scores are /10, printed right to left, last digit always 0)
export function vidColorScore(tilePos: Int2, colorCode: number, score: number): void {
  const tp = i2(tilePos.x, tilePos.y);
  let s = score;
  vidColorChar(tp, colorCode, '0');
  tp.x -= 1;
  for (let digit = 0; digit < 8; digit++) {
    const chr = String.fromCharCode((s % 10) + '0'.charCodeAt(0));
    if (validTilePos(tp)) {
      vidColorChar(tp, colorCode, chr);
      tp.x -= 1;
      s = idiv(s, 10);
      if (s === 0) break;
    }
  }
}

// draw a 2x2 tile quad (used for lives and status fruits)
export function vidDrawTileQuad(tilePos: Int2, colorCode: number, tileCode: number): void {
  for (let yy = 0; yy < 2; yy++) {
    for (let xx = 0; xx < 2; xx++) {
      const t = tileCode + (yy * 2 + (1 - xx));
      vidColorTile(i2(xx + tilePos.x, yy + tilePos.y), colorCode, t);
    }
  }
}

// draw the fruit bonus score tiles (when Pacman has eaten the bonus fruit)
export function vidFruitScore(fruitType: Fruit): void {
  if (!(fruitType >= Fruit.FRUIT_NONE && fruitType < Fruit.NUM_FRUITS))
    throw new Error('vidFruitScore: bad fruit');
  const colorCode = fruitType === Fruit.FRUIT_NONE ? COLOR_DOT : COLOR_FRUIT_SCORE;
  for (let i = 0; i < 4; i++) {
    vidColorTile(i2(12 + i, 20), colorCode, fruitScoreTiles[fruitType]![i]!);
  }
}

// --- spr: sprite state and animation (pacman.c 1134-1229) ---

export function sprClear(): void {
  for (let i = 0; i < NUM_SPRITES; i++) {
    const s = state.gfx.sprite[i]!;
    s.enabled = false;
    s.tile = 0;
    s.color = 0;
    s.flipx = false;
    s.flipy = false;
    s.pos = i2(0, 0);
  }
}

export function sprPacman(): Sprite {
  return state.gfx.sprite[SpriteIndex.SPRITE_PACMAN]!;
}

export function sprGhost(typ: GhostType): Sprite {
  if (!(typ >= GhostType.GHOSTTYPE_BLINKY && typ < GhostType.NUM_GHOSTS))
    throw new Error('sprGhost: bad type');
  return state.gfx.sprite[SpriteIndex.SPRITE_BLINKY + typ]!;
}

export function sprFruit(): Sprite {
  return state.gfx.sprite[SpriteIndex.SPRITE_FRUIT]!;
}

export function sprAnimPacman(dir: Dir, tick: number): void {
  const tiles: number[][] = [
    [44, 46, 48, 46], // horizontal (needs flipx)
    [45, 47, 48, 47], // vertical (needs flipy)
  ];
  const spr = sprPacman();
  const phase = idiv(tick, 2) & 3;
  spr.tile = tiles[dir & 1]![phase]!;
  spr.color = COLOR_PACMAN;
  spr.flipx = dir === Dir.DIR_LEFT;
  spr.flipy = dir === Dir.DIR_UP;
}

export function sprAnimPacmanDeath(tick: number): void {
  const spr = sprPacman();
  let tile = 52 + idiv(tick, 8);
  if (tile > 63) tile = 63;
  spr.tile = tile;
  spr.flipx = false;
  spr.flipy = false;
}

export function sprAnimGhost(ghostType: GhostType, dir: Dir, tick: number): void {
  if (!(dir >= Dir.DIR_RIGHT && dir < Dir.NUM_DIRS)) throw new Error('sprAnimGhost: bad dir');
  const tiles: number[][] = [
    [32, 33],
    [34, 35],
    [36, 37],
    [38, 39],
  ];
  const phase = idiv(tick, 8) & 1;
  const spr = sprGhost(ghostType);
  spr.tile = tiles[dir]![phase]!;
  spr.color = COLOR_BLINKY + 2 * ghostType;
  spr.flipx = false;
  spr.flipy = false;
}

export function sprAnimGhostFrightened(ghostType: GhostType, tick: number): void {
  const tiles: number[] = [28, 29];
  const phase = idiv(tick, 4) & 1;
  const spr = sprGhost(ghostType);
  spr.tile = tiles[phase]!;
  // towards the end of the frightened period, start blinking (the C code
  // casts the possibly negative difference to uint32, replicated here
  // with >>>0, SPEC T5)
  if (tick > ((levelspec(state.game.round).frightTicks - 60) >>> 0)) {
    spr.color = (tick & 0x10) !== 0 ? COLOR_FRIGHTENED : COLOR_FRIGHTENED_BLINKING;
  } else {
    spr.color = COLOR_FRIGHTENED;
  }
  spr.flipx = false;
  spr.flipy = false;
}

export function sprAnimGhostEyes(ghostType: GhostType, dir: Dir): void {
  if (!(dir >= Dir.DIR_RIGHT && dir < Dir.NUM_DIRS)) throw new Error('sprAnimGhostEyes: bad dir');
  const tiles: number[] = [32, 34, 36, 38];
  const spr = sprGhost(ghostType);
  spr.tile = tiles[dir]!;
  spr.color = COLOR_EYES;
  spr.flipx = false;
  spr.flipy = false;
}

// --- dynamic tile and sprite updates (pacman.c 1584-1732) ---

export function gameUpdateTiles(): void {
  vidColorScore(i2(6, 1), COLOR_DEFAULT, state.game.score);
  if (state.game.hiscore > 0) {
    vidColorScore(i2(16, 1), COLOR_DEFAULT, state.game.hiscore);
  }

  const pillPos: Int2[] = [i2(1, 6), i2(26, 6), i2(1, 26), i2(26, 26)];
  for (let i = 0; i < NUM_PILLS; i++) {
    if (state.game.freeze.size !== 0) {
      vidColor(pillPos[i]!, COLOR_DOT);
    } else {
      vidColor(pillPos[i]!, (state.timing.tick & 0x8) !== 0 ? 0x10 : 0x00);
    }
  }

  if (afterOnce(state.game.fruitEaten, 2 * 60)) {
    vidFruitScore(Fruit.FRUIT_NONE);
  }

  for (let i = 0; i < NUM_LIVES; i++) {
    const color = i < state.game.numLives ? COLOR_PACMAN : 0;
    vidDrawTileQuad(i2(2 + 2 * i, 34), color, TILE_LIFE);
  }

  // bonus fruit list in the bottom-right corner
  {
    let x = 24;
    const round = state.game.round;
    for (let i = round - NUM_STATUS_FRUITS + 1; i <= round; i++) {
      if (i >= 0) {
        const fruit = levelspec(i).bonusFruit;
        vidDrawTileQuad(i2(x, 34), fruitTilesColors[fruit]![2]!, fruitTilesColors[fruit]![0]!);
        x -= 2;
      }
    }
  }

  // if the round was won, blink the whole playfield blue/white
  if (after(state.game.roundWon, 1 * 60)) {
    if ((since(state.game.roundWon) & 0x10) !== 0) {
      vidColorPlayfield(COLOR_DOT);
    } else {
      vidColorPlayfield(COLOR_WHITE_BORDER);
    }
  }
}

export function gameUpdateSprites(): void {
  // Pacman sprite
  {
    const spr = sprPacman();
    if (spr.enabled) {
      const actor = state.game.pacman.actor;
      spr.pos = actorToSpritePos(actor.pos);
      if (state.game.freeze.has(FreezeType.FREEZETYPE_EAT_GHOST)) {
        spr.tile = SPRITETILE_INVISIBLE;
      } else if (
        state.game.freeze.has(FreezeType.FREEZETYPE_PRELUDE) ||
        state.game.freeze.has(FreezeType.FREEZETYPE_READY)
      ) {
        spr.tile = SPRITETILE_PACMAN_CLOSED_MOUTH;
      } else if (state.game.freeze.has(FreezeType.FREEZETYPE_DEAD)) {
        if (after(state.game.pacmanEaten, PACMAN_EATEN_TICKS)) {
          sprAnimPacmanDeath(since(state.game.pacmanEaten) - PACMAN_EATEN_TICKS);
        }
      } else {
        sprAnimPacman(actor.dir, actor.animTick);
      }
    }
  }

  // ghost sprites
  for (let i = 0; i < state.game.ghost.length; i++) {
    const sprite = sprGhost(i as GhostType);
    if (sprite.enabled) {
      const ghost = state.game.ghost[i]!;
      sprite.pos = actorToSpritePos(ghost.actor.pos);
      if (state.game.freeze.has(FreezeType.FREEZETYPE_DEAD)) {
        if (after(state.game.pacmanEaten, PACMAN_EATEN_TICKS)) {
          sprite.tile = SPRITETILE_INVISIBLE;
        }
      } else if (state.game.freeze.has(FreezeType.FREEZETYPE_WON)) {
        sprite.tile = SPRITETILE_INVISIBLE;
      } else {
        switch (ghost.state) {
          case GhostState.GHOSTSTATE_EYES:
            if (before(ghost.eaten, GHOST_EATEN_FREEZE_TICKS)) {
              // show the score number for the just-eaten ghost
              sprite.tile = SPRITETILE_SCORE_200 + state.game.numGhostsEaten - 1;
              sprite.color = COLOR_GHOST_SCORE;
            } else {
              sprAnimGhostEyes(i as GhostType, ghost.nextDir);
            }
            break;
          case GhostState.GHOSTSTATE_ENTERHOUSE:
            sprAnimGhostEyes(i as GhostType, ghost.actor.dir);
            break;
          case GhostState.GHOSTSTATE_FRIGHTENED:
            sprAnimGhostFrightened(i as GhostType, since(ghost.frightened));
            break;
          default:
            sprAnimGhost(i as GhostType, ghost.nextDir, ghost.actor.animTick);
            break;
        }
      }
    }
  }

  // bonus fruit sprite
  if (state.game.activeFruit === Fruit.FRUIT_NONE) {
    sprFruit().enabled = false;
  } else {
    const spr = sprFruit();
    spr.enabled = true;
    spr.pos = i2(13 * TILE_WIDTH, 19 * TILE_HEIGHT + (TILE_HEIGHT >> 1));
    spr.tile = fruitTilesColors[state.game.activeFruit]![1]!;
    spr.color = fruitTilesColors[state.game.activeFruit]![2]!;
  }
}

// --- gfx decode: ROM data into the tile texture and palette (pacman.c 2404-2640) ---

function gfxDecodeTile8x4(
  texX: number,
  texY: number,
  tileBase: Uint8Array,
  tileStride: number,
  tileOffset: number,
  tileCode: number,
): void {
  for (let tx = 0; tx < TILE_WIDTH; tx++) {
    const ti = tileCode * tileStride + tileOffset + (7 - tx);
    for (let ty = 0; ty < TILE_HEIGHT >> 1; ty++) {
      const pHi = (tileBase[ti]! >> (7 - ty)) & 1;
      const pLo = (tileBase[ti]! >> (3 - ty)) & 1;
      const p = (pHi << 1) | pLo;
      state.gfx.tilePixels[(texY + ty) * TILE_TEXTURE_WIDTH + (texX + tx)] = p;
    }
  }
}

function gfxDecodeTile(tileCode: number): void {
  const x = tileCode * TILE_WIDTH;
  gfxDecodeTile8x4(x, 0, romTiles, 16, 8, tileCode);
  gfxDecodeTile8x4(x, TILE_HEIGHT >> 1, romTiles, 16, 0, tileCode);
}

function gfxDecodeSprite(spriteCode: number): void {
  const x0 = spriteCode * SPRITE_WIDTH;
  const x1 = x0 + TILE_WIDTH;
  const y0 = TILE_HEIGHT;
  const y1 = y0 + (TILE_HEIGHT >> 1);
  const y2 = y1 + (TILE_HEIGHT >> 1);
  const y3 = y2 + (TILE_HEIGHT >> 1);
  gfxDecodeTile8x4(x0, y0, romSprites, 64, 40, spriteCode);
  gfxDecodeTile8x4(x1, y0, romSprites, 64, 8, spriteCode);
  gfxDecodeTile8x4(x0, y1, romSprites, 64, 48, spriteCode);
  gfxDecodeTile8x4(x1, y1, romSprites, 64, 16, spriteCode);
  gfxDecodeTile8x4(x0, y2, romSprites, 64, 56, spriteCode);
  gfxDecodeTile8x4(x1, y2, romSprites, 64, 24, spriteCode);
  gfxDecodeTile8x4(x0, y3, romSprites, 64, 32, spriteCode);
  gfxDecodeTile8x4(x1, y3, romSprites, 64, 0, spriteCode);
}

function gfxDecodeTiles(): void {
  for (let tileCode = 0; tileCode < 256; tileCode++) {
    gfxDecodeTile(tileCode);
  }
  for (let spriteCode = 0; spriteCode < 64; spriteCode++) {
    gfxDecodeSprite(spriteCode);
  }
  // a special opaque 16x16 block used for the fade effect (sprite tile 64)
  for (let y = TILE_HEIGHT; y < TILE_TEXTURE_HEIGHT; y++) {
    for (let x = 64 * SPRITE_WIDTH; x < 65 * SPRITE_WIDTH; x++) {
      state.gfx.tilePixels[y * TILE_TEXTURE_WIDTH + x] = 1;
    }
  }
}

function gfxDecodeColorPalette(): void {
  const hwColors = new Array<number>(32).fill(0);
  for (let i = 0; i < 32; i++) {
    const rgb = romHWColors[i]!;
    const r = ((rgb >> 0) & 1) * 0x21 + ((rgb >> 1) & 1) * 0x47 + ((rgb >> 2) & 1) * 0x97;
    const g = ((rgb >> 3) & 1) * 0x21 + ((rgb >> 4) & 1) * 0x47 + ((rgb >> 5) & 1) * 0x97;
    const b = ((rgb >> 6) & 1) * 0x47 + ((rgb >> 7) & 1) * 0x97;
    hwColors[i] = (0xff000000 | (b << 16) | (g << 8) | r) >>> 0;
  }
  for (let i = 0; i < 256; i++) {
    state.gfx.colorPalette[i] = hwColors[romPalette[i]! & 0xf]!;
    if ((i & 3) === 0) {
      state.gfx.colorPalette[i] = (state.gfx.colorPalette[i]! & 0x00ffffff) >>> 0;
    }
  }
}

// State-side gfx initialization (decode ROM graphics). The Canvas-side
// resources are created separately by the Canvas layer in this module.
export function gfxInit(): void {
  disable(state.gfx.fadein);
  disable(state.gfx.fadeout);
  state.gfx.fade = 0xff;
  sprClear();
  gfxDecodeTiles();
  gfxDecodeColorPalette();
}

// The fade value for the current frame (pacman.c gfx_fade), used by the
// Canvas layer.
export function gfxFade(): void {
  // The original computes in float32; Math.fround at each step
  // reproduces its rounding exactly (in float64, six of the fadein
  // steps would come out one unit brighter).
  if (between(state.gfx.fadein, 0, FADE_TICKS)) {
    const t = Math.fround(since(state.gfx.fadein) / FADE_TICKS);
    state.gfx.fade = Math.trunc(Math.fround(255.0 * Math.fround(1.0 - t)));
  }
  if (afterOnce(state.gfx.fadein, FADE_TICKS)) {
    state.gfx.fade = 0;
  }
  if (between(state.gfx.fadeout, 0, FADE_TICKS)) {
    const t = Math.fround(since(state.gfx.fadeout) / FADE_TICKS);
    state.gfx.fade = Math.trunc(Math.fround(255.0 * t));
  }
  if (afterOnce(state.gfx.fadeout, FADE_TICKS)) {
    state.gfx.fade = 255;
  }
}

// --- Canvas renderer (SPEC T1/T2) ---
//
// The sokol version renders indexed pixels through a palette shader.
// Here, as in the Go port, the palette is baked into pre-rendered
// images instead: one offscreen canvas per (tile, color) and
// (sprite, color) pair. The board is a 224x288 offscreen canvas that
// is updated only where cells changed, then blitted to the visible
// canvas, followed by the sprites, the debug markers and the fade
// overlay (the draw order of pacman.c's gfx_draw).

let viewCanvas: HTMLCanvasElement | null = null;
let viewCtx: CanvasRenderingContext2D | null = null;
let boardCanvas: HTMLCanvasElement | null = null;
let boardCtx: CanvasRenderingContext2D | null = null;
let tileImages: HTMLCanvasElement[][] = []; // [256][32]
let spriteImages: HTMLCanvasElement[][] = []; // [64][32]
let prevVideo: number[][] = [];
let prevColor: number[][] = [];
let boardValid = false;

function makeCanvas(width: number, height: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = width;
  c.height = height;
  return c;
}

// Bake one (code, color) image from the decoded pixel buffer.
// Palette indexing mirrors the Go port exactly: the palette entry for
// pixel value p (0..3) under color code c is colorPalette[c*4 + p],
// packed 0xAABBGGRR with the alpha byte cleared for p == 0, so
// transparent pixels let whatever is underneath show through.
function bakeImage(
  texX: number,
  texY: number,
  width: number,
  height: number,
  colorCode: number,
): HTMLCanvasElement {
  const img = makeCanvas(width, height);
  const ctx = img.getContext('2d')!;
  const imageData = ctx.createImageData(width, height);
  const px = imageData.data;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const pix = state.gfx.tilePixels[(texY + y) * TILE_TEXTURE_WIDTH + (texX + x)]!;
      const packed = state.gfx.colorPalette[colorCode * 4 + pix]!;
      const o = (y * width + x) * 4;
      px[o] = packed & 0xff;
      px[o + 1] = (packed >> 8) & 0xff;
      px[o + 2] = (packed >> 16) & 0xff;
      px[o + 3] = (packed >> 24) & 0xff;
    }
  }
  ctx.putImageData(imageData, 0, 0);
  return img;
}

// Set up the Canvas renderer: state-side gfx init, baked tile/sprite
// images, the board offscreen canvas, and reset diff snapshots.
export function initRenderer(canvas: HTMLCanvasElement): void {
  gfxInit();
  viewCanvas = canvas;
  viewCtx = canvas.getContext('2d')!;
  viewCtx.imageSmoothingEnabled = false;

  tileImages = [];
  for (let code = 0; code < 256; code++) {
    const row: HTMLCanvasElement[] = [];
    for (let c = 0; c < 32; c++) {
      row.push(bakeImage(code * TILE_WIDTH, 0, TILE_WIDTH, TILE_HEIGHT, c));
    }
    tileImages.push(row);
  }
  spriteImages = [];
  for (let code = 0; code < 64; code++) {
    const row: HTMLCanvasElement[] = [];
    for (let c = 0; c < 32; c++) {
      row.push(bakeImage(code * SPRITE_WIDTH, TILE_HEIGHT, SPRITE_WIDTH, SPRITE_HEIGHT, c));
    }
    spriteImages.push(row);
  }

  boardCanvas = makeCanvas(DISPLAY_PIXELS_X, DISPLAY_PIXELS_Y);
  boardCtx = boardCanvas.getContext('2d')!;
  boardCtx.fillStyle = '#000';
  boardCtx.fillRect(0, 0, DISPLAY_PIXELS_X, DISPLAY_PIXELS_Y);

  const blank = () =>
    Array.from({ length: DISPLAY_TILES_Y }, () => new Array<number>(DISPLAY_TILES_X).fill(0));
  prevVideo = blank();
  prevColor = blank();
  boardValid = false;
}

// Redraw only the board cells whose tile or color changed.
function updateBoard(): void {
  const ctx = boardCtx!;
  for (let y = 0; y < DISPLAY_TILES_Y; y++) {
    for (let x = 0; x < DISPLAY_TILES_X; x++) {
      const tile = state.gfx.videoRam[y]![x]!;
      const col = state.gfx.colorRam[y]![x]! & 0x1f;
      if (boardValid && tile === prevVideo[y]![x]! && col === (prevColor[y]![x]! & 0x1f)) {
        continue;
      }
      // Clear the cell first: tile images have transparent pixels
      // (palette alpha is 0 for pixel value 0), so compositing the
      // new tile over the old one would leave stale pixels behind
      // (e.g. an eaten dot must disappear completely).
      ctx.fillStyle = '#000';
      ctx.fillRect(x * TILE_WIDTH, y * TILE_HEIGHT, TILE_WIDTH, TILE_HEIGHT);
      ctx.drawImage(tileImages[tile]![col]!, x * TILE_WIDTH, y * TILE_HEIGHT);
      prevVideo[y]![x] = tile;
      prevColor[y]![x] = state.gfx.colorRam[y]![x]!;
    }
  }
  boardValid = true;
}

// Draw one frame (the gfx_draw counterpart): fade value update, board,
// sprites in order, debug markers as tiles, fade overlay.
export function drawFrame(): void {
  if (viewCtx === null || boardCanvas === null) {
    throw new Error('drawFrame: renderer not initialized');
  }
  const ctx = viewCtx;
  gfxFade();
  updateBoard();
  ctx.drawImage(boardCanvas, 0, 0);

  // sprites, in array order
  for (let i = 0; i < NUM_SPRITES; i++) {
    const spr = state.gfx.sprite[i]!;
    if (!spr.enabled) continue;
    const img = spriteImages[spr.tile]![spr.color & 0x1f]!;
    if (!spr.flipx && !spr.flipy) {
      ctx.drawImage(img, spr.pos.x, spr.pos.y);
    } else {
      ctx.save();
      ctx.translate(
        spr.pos.x + (spr.flipx ? SPRITE_WIDTH : 0),
        spr.pos.y + (spr.flipy ? SPRITE_HEIGHT : 0),
      );
      ctx.scale(spr.flipx ? -1 : 1, spr.flipy ? -1 : 1);
      ctx.drawImage(img, 0, 0);
      ctx.restore();
    }
  }

  // debug markers are drawn as playfield tiles (never enabled by the
  // game itself)
  for (let i = 0; i < NUM_DEBUG_MARKERS; i++) {
    const dbg = state.gfx.debugMarker[i]!;
    if (!dbg.enabled) continue;
    ctx.drawImage(
      tileImages[dbg.tile]![dbg.color & 0x1f]!,
      dbg.tilePos.x * TILE_WIDTH,
      dbg.tilePos.y * TILE_HEIGHT,
    );
  }

  // fade: a black overlay whose opacity is the fade value
  if (state.gfx.fade > 0) {
    ctx.fillStyle = `rgba(0, 0, 0, ${state.gfx.fade / 255})`;
    ctx.fillRect(0, 0, DISPLAY_PIXELS_X, DISPLAY_PIXELS_Y);
  }
}
