// synth.ts -- the sample-generation side of the Namco sound board.
// Corresponds to the audio-callback half of pacman.c (snd_voice_tick
// and snd_sample_tick). The register layer in sound.ts updates the
// voice registers at 60 Hz on the game side; this class turns register
// snapshots into samples and runs inside the AudioWorklet (SPEC T3).
// The phase counters (counter, sampleAcc, sampleDiv) live here, not
// in the snapshot, exactly as in the original where they are part of
// the sound-board state driven by the audio callback.

import { AUDIO_VOLUME, NUM_VOICES } from './state.js';
import { romWavetable } from './romdata.js';
import type { VoiceRegs } from './sound.js';

interface SynthVoice {
  // register values, copied in by setVoices()
  frequency: number;
  waveform: number;
  volume: number;
  // phase state, owned by the synth
  counter: number; // uint32 phase accumulator
  sampleAcc: number;
  sampleDiv: number;
}

export class Synth {
  private readonly voiceTickPeriod: number; // in milli-units of a 96 kHz tick
  private voiceTickAccum = 0;
  private readonly voices: SynthVoice[] = [];

  constructor(sampleRate: number) {
    // number of 96 kHz ticks per output sample, times 1000 for
    // precision; integer division like the original's snd_init
    this.voiceTickPeriod = Math.trunc(96_000_000 / sampleRate);
    for (let i = 0; i < NUM_VOICES; i++) {
      this.voices.push({
        frequency: 0,
        waveform: 0,
        volume: 0,
        counter: 0,
        sampleAcc: 0,
        sampleDiv: 0,
      });
    }
  }

  // Copy a register snapshot from the game side (sound.ts
  // voiceSnapshot). Only frequency/waveform/volume cross the
  // boundary; the phase counters stay here.
  setVoices(regs: VoiceRegs[]): void {
    for (let i = 0; i < NUM_VOICES; i++) {
      const v = this.voices[i]!;
      const r = regs[i]!;
      v.frequency = r.frequency;
      v.waveform = r.waveform;
      v.volume = r.volume;
    }
  }

  // Fill out with mono samples at the constructor's sample rate.
  render(out: Float32Array): void {
    for (let i = 0; i < out.length; i++) {
      this.voiceTickAccum -= this.voiceTickPeriod;
      while (this.voiceTickAccum < 0) {
        this.voiceTickAccum += 1000;
        this.voiceTick();
      }
      out[i] = this.sampleTick();
    }
  }

  // updates the Namco sound generator once (must be called at 96 kHz)
  private voiceTick(): void {
    for (const voice of this.voices) {
      voice.counter = (voice.counter + voice.frequency) >>> 0;
      const waveIndex =
        ((voice.waveform << 5) | ((voice.counter >>> 15) & 0x1f)) & 0xff;
      voice.sampleAcc += ((romWavetable[waveIndex]! & 0xf) - 8) * voice.volume;
      voice.sampleDiv += 128;
    }
  }

  // computes one output sample from the per-voice averages
  private sampleTick(): number {
    let sm = 0;
    for (const voice of this.voices) {
      if (voice.sampleDiv > 0) {
        sm += voice.sampleAcc / voice.sampleDiv;
        voice.sampleAcc = 0;
        voice.sampleDiv = 0;
      }
    }
    return sm * 0.333333 * AUDIO_VOLUME;
  }
}
