// timing.ts -- the time-trigger vocabulary and input helpers.
// Corresponds to pacman.c lines 826-943 (xorshift, triggers, input).

import {
  state,
  newInputState,
  DISABLED_TICKS,
  Dir,
  type Trigger,
} from './state.js';

// xorshift random number generator (pacman.c 827-833).
// Bitwise operators coerce to int32, which reproduces the C uint32
// wraparound exactly; the stored value is normalized with >>>0 (SPEC T5).
export function xorshift32(): number {
  let x = state.game.xorshift | 0;
  x ^= x << 13;
  x ^= x >>> 17;
  x ^= x << 5;
  state.game.xorshift = x >>> 0;
  return x >>> 0;
}

// set time trigger to the next game tick
export function start(t: Trigger): void {
  t.tick = state.timing.tick + 1;
}

// set time trigger to a future tick
export function startAfter(t: Trigger, ticks: number): void {
  t.tick = state.timing.tick + ticks;
}

// deactivate a time trigger
export function disable(t: Trigger): void {
  t.tick = DISABLED_TICKS;
}

// return a disabled time trigger
export function disabledTimer(): Trigger {
  return { tick: DISABLED_TICKS };
}

// check if a time trigger is triggered
export function now(t: Trigger): boolean {
  return t.tick === state.timing.tick;
}

// return the number of ticks since a time trigger was triggered
export function since(t: Trigger): number {
  if (state.timing.tick >= t.tick) {
    return state.timing.tick - t.tick;
  }
  return DISABLED_TICKS;
}

// check if a time trigger is between begin and end tick
export function between(t: Trigger, begin: number, end: number): boolean {
  if (!(begin < end)) throw new Error('between: begin < end required');
  if (t.tick !== DISABLED_TICKS) {
    const ticks = since(t);
    return ticks >= begin && ticks < end;
  }
  return false;
}

// check if a time trigger was triggered exactly N ticks ago
export function afterOnce(t: Trigger, ticks: number): boolean {
  return since(t) === ticks;
}

// check if a time trigger was triggered more than N ticks ago
export function after(t: Trigger, ticks: number): boolean {
  const s = since(t);
  if (s !== DISABLED_TICKS) {
    return s >= ticks;
  }
  return false;
}

// same as between(t, 0, ticks)
export function before(t: Trigger, ticks: number): boolean {
  const s = since(t);
  if (s !== DISABLED_TICKS) {
    return s < ticks;
  }
  return false;
}

// clear input state and disable input
export function inputDisable(): void {
  state.input = newInputState();
}

// enable input again
export function inputEnable(): void {
  state.input.enabled = true;
}

// get the current input as Dir
export function inputDir(defaultDir: Dir): Dir {
  if (state.input.up) return Dir.DIR_UP;
  if (state.input.down) return Dir.DIR_DOWN;
  if (state.input.right) return Dir.DIR_RIGHT;
  if (state.input.left) return Dir.DIR_LEFT;
  return defaultDir;
}
