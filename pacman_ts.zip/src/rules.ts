// rules.ts -- playfield setup, round setup, actor updates, the game tick
// and the intro tick. Corresponds to pacman.c lines 1377-1583, 1733-1748,
// 2089-2403. Translation of the Nim port's rules.nim, plus the tick driver
// (runTick) and startup (initGame) mirrored from pacman.nim's frame()/init().

import {
  state,
  i2,
  add,
  newActor,
  newSprite,
  levelspec,
  ghostStartingPos,
  TILE_WIDTH,
  TILE_HEIGHT,
  TILE_SPACE,
  TILE_GHOST,
  TILE_DOT,
  TILE_PILL,
  TILE_DOOR,
  COLOR_DEFAULT,
  COLOR_DOT,
  COLOR_PACMAN,
  COLOR_BLINKY,
  COLOR_PINKY,
  COLOR_INKY,
  COLOR_CLYDE,
  NUM_LIVES,
  NUM_DOTS,
  FADE_TICKS,
  GAMEOVER_TICKS,
  ROUNDWON_TICKS,
  FRUITACTIVE_TICKS,
  GHOST_EATEN_FREEZE_TICKS,
  PACMAN_EATEN_TICKS,
  PACMAN_DEATH_TICKS,
  GameState,
  Dir,
  Fruit,
  SpriteIndex,
  GhostType,
  GhostState,
  FreezeType,
  type Ghost,
} from './state.js';
import {
  start,
  startAfter,
  disable,
  disabledTimer,
  now,
  since,
  afterOnce,
  after,
  inputDir,
  inputEnable,
  inputDisable,
} from './timing.js';
import { idiv, pixelToTilePos, isDot, isPill, canMove, move } from './geom.js';
import {
  ghostSpeed,
  updateGhostState,
  updateGhostTarget,
  updateGhostDir,
  updateGhosthouseDotCounters,
} from './ghost.js';
import {
  vidClear,
  vidColorPlayfield,
  vidColor,
  vidTile,
  vidColorTile,
  vidColorText,
  vidText,
  vidColorScore,
  vidFruitScore,
  sprClear,
  gameUpdateTiles,
  gameUpdateSprites,
  gfxInit,
} from './render.js';
import {
  sndClear,
  sndStart,
  sndTick,
  sndPrelude,
  sndDead,
  sndEatdot1,
  sndEatdot2,
  sndEatghost,
  sndEatfruit,
  sndWeeooh,
  sndFrightened,
} from './sound.js';

// initialize the playfield tiles from the ASCII map (pacman.c 1377-1432)
function gameInitPlayfield(): void {
  vidColorPlayfield(COLOR_DOT);
  const tiles = [
    '0UUUUUUUUUUUU45UUUUUUUUUUUU1',
    'L............rl............R',
    'L.ebbf.ebbbf.rl.ebbbf.ebbf.R',
    'LPr  l.r   l.rl.r   l.r  lPR',
    'L.guuh.guuuh.gh.guuuh.guuh.R',
    'L..........................R',
    'L.ebbf.ef.ebbbbbbf.ef.ebbf.R',
    'L.guuh.rl.guuyxuuh.rl.guuh.R',
    'L......rl....rl....rl......R',
    '2BBBBf.rzbbf rl ebbwl.eBBBB3',
    '     L.rxuuh gh guuyl.R     ',
    '     L.rl          rl.R     ',
    '     L.rl mjs--tjn rl.R     ',
    'UUUUUh.gh i      q gh.gUUUUU',
    '      .   i      q   .      ',
    'BBBBBf.ef i      q ef.eBBBBB',
    '     L.rl okkkkkkp rl.R     ',
    '     L.rl          rl.R     ',
    '     L.rl ebbbbbbf rl.R     ',
    '0UUUUh.gh guuyxuuh gh.gUUUU1',
    'L............rl............R',
    'L.ebbf.ebbbf.rl.ebbbf.ebbf.R',
    'L.guyl.guuuh.gh.guuuh.rxuh.R',
    'LP..rl.......  .......rl..PR',
    '6bf.rl.ef.ebbbbbbf.ef.rl.eb8',
    '7uh.gh.rl.guuyxuuh.rl.gh.gu9',
    'L......rl....rl....rl......R',
    'L.ebbbbwzbbf.rl.ebbwzbbbbf.R',
    'L.guuuuuuuuh.gh.guuuuuuuuh.R',
    'L..........................R',
    '2BBBBBBBBBBBBBBBBBBBBBBBBBB3',
  ].join('');
  const t: number[] = new Array<number>(128).fill(TILE_DOT);
  const set = (ch: string, code: number): void => {
    t[ch.charCodeAt(0)] = code;
  };
  set(' ', 0x40); set('0', 0xd1); set('1', 0xd0);
  set('2', 0xd5); set('3', 0xd4); set('4', 0xfb);
  set('5', 0xfa); set('6', 0xd7); set('7', 0xd9);
  set('8', 0xd6); set('9', 0xd8); set('U', 0xdb);
  set('L', 0xd3); set('R', 0xd2); set('B', 0xdc);
  set('b', 0xdf); set('e', 0xe7); set('f', 0xe6);
  set('g', 0xeb); set('h', 0xea); set('l', 0xe8);
  set('r', 0xe9); set('u', 0xe5); set('w', 0xf5);
  set('x', 0xf2); set('y', 0xf3); set('z', 0xf4);
  set('m', 0xed); set('n', 0xec); set('o', 0xef);
  set('p', 0xee); set('j', 0xdd); set('i', 0xd2);
  set('k', 0xdb); set('q', 0xd3); set('s', 0xf1);
  set('t', 0xf0); set('-', TILE_DOOR); set('P', TILE_PILL);
  let i = 0;
  for (let y = 3; y <= 33; y++) {
    for (let x = 0; x < 28; x++) {
      state.gfx.videoRam[y]![x] = t[tiles.charCodeAt(i) & 127]!;
      i += 1;
    }
  }
  // ghost house gate colors
  vidColor(i2(13, 15), 0x18);
  vidColor(i2(14, 15), 0x18);
}

// disable all game loop timers
function gameDisableTimers(): void {
  disable(state.game.roundWon);
  disable(state.game.gameOver);
  disable(state.game.dotEaten);
  disable(state.game.pillEaten);
  disable(state.game.ghostEaten);
  disable(state.game.pacmanEaten);
  disable(state.game.fruitEaten);
  disable(state.game.forceLeaveHouse);
  disable(state.game.fruitActive);
}

// one-time init at start of game state
function gameInit(): void {
  inputEnable();
  gameDisableTimers();
  state.game.round = 0;
  state.game.freeze = new Set([FreezeType.FREEZETYPE_PRELUDE]);
  state.game.numLives = NUM_LIVES;
  state.game.globalDotCounterActive = false;
  state.game.globalDotCounter = 0;
  state.game.numDotsEaten = 0;
  state.game.score = 0;
  vidClear(TILE_SPACE, COLOR_DOT);
  vidColorText(i2(9, 0), COLOR_DEFAULT, 'HIGH SCORE');
  gameInitPlayfield();
  vidColorText(i2(9, 14), 0x5, 'PLAYER ONE');
  vidColorText(i2(11, 20), 0x9, 'READY!');
}

function makeGhost(
  typ: GhostType,
  dir: Dir,
  ghostState: GhostState,
  dotLimit: number,
): Ghost {
  const actor = newActor();
  actor.dir = dir;
  actor.pos = ghostStartingPos[typ]!;
  return {
    actor,
    typ,
    nextDir: dir,
    targetPos: i2(0, 0),
    state: ghostState,
    frightened: disabledTimer(),
    eaten: disabledTimer(),
    dotCounter: 0,
    dotLimit,
  };
}

function makeSprite(color: number) {
  const s = newSprite();
  s.enabled = true;
  s.color = color;
  return s;
}

// setup state at start of a game round
function gameRoundInit(): void {
  sprClear();
  vidColorText(i2(9, 14), 0x10, '          ');
  if (state.game.numDotsEaten === NUM_DOTS) {
    // round won: redraw the playfield, reset the global dot counter
    state.game.round = (state.game.round + 1) & 0xff;
    state.game.numDotsEaten = 0;
    gameInitPlayfield();
    state.game.globalDotCounterActive = false;
  } else {
    if (state.game.numLives !== NUM_LIVES) {
      state.game.globalDotCounterActive = true;
      state.game.globalDotCounter = 0;
    }
    state.game.numLives -= 1;
  }
  if (state.game.numLives < 0) throw new Error('gameRoundInit: numLives < 0');

  state.game.activeFruit = Fruit.FRUIT_NONE;
  state.game.freeze = new Set([FreezeType.FREEZETYPE_READY]);
  state.game.xorshift = 0x12345678; // random-number-generator seed
  state.game.numGhostsEaten = 0;
  gameDisableTimers();
  vidColorText(i2(11, 20), 0x9, 'READY!');
  start(state.game.forceLeaveHouse);

  const pmActor = newActor();
  pmActor.dir = Dir.DIR_LEFT;
  pmActor.pos = i2(14 * 8, 26 * 8 + 4);
  state.game.pacman = { actor: pmActor };
  state.gfx.sprite[SpriteIndex.SPRITE_PACMAN] = makeSprite(COLOR_PACMAN);

  state.game.ghost[GhostType.GHOSTTYPE_BLINKY] = makeGhost(
    GhostType.GHOSTTYPE_BLINKY, Dir.DIR_LEFT, GhostState.GHOSTSTATE_SCATTER, 0);
  state.gfx.sprite[SpriteIndex.SPRITE_BLINKY] = makeSprite(COLOR_BLINKY);

  state.game.ghost[GhostType.GHOSTTYPE_PINKY] = makeGhost(
    GhostType.GHOSTTYPE_PINKY, Dir.DIR_DOWN, GhostState.GHOSTSTATE_HOUSE, 0);
  state.gfx.sprite[SpriteIndex.SPRITE_PINKY] = makeSprite(COLOR_PINKY);

  state.game.ghost[GhostType.GHOSTTYPE_INKY] = makeGhost(
    GhostType.GHOSTTYPE_INKY, Dir.DIR_UP, GhostState.GHOSTSTATE_HOUSE, 30);
  state.gfx.sprite[SpriteIndex.SPRITE_INKY] = makeSprite(COLOR_INKY);

  state.game.ghost[GhostType.GHOSTTYPE_CLYDE] = makeGhost(
    GhostType.GHOSTTYPE_CLYDE, Dir.DIR_UP, GhostState.GHOSTSTATE_HOUSE, 60);
  state.gfx.sprite[SpriteIndex.SPRITE_CLYDE] = makeSprite(COLOR_CLYDE);
}

// return true if Pacman should move in this tick
function pacmanShouldMove(): boolean {
  if (now(state.game.dotEaten)) {
    return false; // eating a dot stops Pacman for 1 tick
  } else if (since(state.game.pillEaten) < 3) {
    return false; // eating a pill stops Pacman for 3 ticks
  } else {
    return state.timing.tick % 8 !== 0;
  }
}

// called when a dot or pill has been eaten
function gameUpdateDotsEaten(): void {
  state.game.numDotsEaten = (state.game.numDotsEaten + 1) & 0xff;
  if (state.game.numDotsEaten === NUM_DOTS) {
    start(state.game.roundWon);
    sndClear();
  } else if (state.game.numDotsEaten === 70 || state.game.numDotsEaten === 170) {
    start(state.game.fruitActive);
  }
  // alternating crunch sound effect
  if ((state.game.numDotsEaten & 1) !== 0) {
    sndStart(2, sndEatdot1);
  } else {
    sndStart(2, sndEatdot2);
  }
}

// the central Pacman and ghost behaviour function, called once per game tick
function gameUpdateActors(): void {
  // Pacman "AI"
  if (pacmanShouldMove()) {
    const actor = state.game.pacman.actor;
    const wantedDir = inputDir(actor.dir);
    if (canMove(actor.pos, wantedDir, true)) {
      actor.dir = wantedDir;
    }
    if (canMove(actor.pos, actor.dir, true)) {
      actor.pos = move(actor.pos, actor.dir, true);
      actor.animTick += 1;
    }
    const tilePos = pixelToTilePos(actor.pos);
    if (isDot(tilePos)) {
      vidTile(tilePos, TILE_SPACE);
      state.game.score += 1;
      start(state.game.dotEaten);
      start(state.game.forceLeaveHouse);
      gameUpdateDotsEaten();
      updateGhosthouseDotCounters();
    }
    if (isPill(tilePos)) {
      vidTile(tilePos, TILE_SPACE);
      state.game.score += 5;
      gameUpdateDotsEaten();
      start(state.game.pillEaten);
      state.game.numGhostsEaten = 0;
      for (let i = 0; i < state.game.ghost.length; i++) {
        start(state.game.ghost[i]!.frightened);
      }
      sndStart(1, sndFrightened);
    }
    // check if Pacman eats the bonus fruit
    if (state.game.activeFruit !== Fruit.FRUIT_NONE) {
      const testPos = pixelToTilePos(add(actor.pos, i2(idiv(TILE_WIDTH, 2), 0)));
      if (testPos.x === 14 && testPos.y === 20) {
        start(state.game.fruitEaten);
        state.game.score += levelspec(state.game.round).bonusScore;
        vidFruitScore(state.game.activeFruit);
        state.game.activeFruit = Fruit.FRUIT_NONE;
        sndStart(2, sndEatfruit);
      }
    }
    // check if Pacman collides with any ghost
    for (let i = 0; i < state.game.ghost.length; i++) {
      const ghost = state.game.ghost[i]!;
      const ghostTilePos = pixelToTilePos(ghost.actor.pos);
      if (tilePos.x === ghostTilePos.x && tilePos.y === ghostTilePos.y) {
        if (ghost.state === GhostState.GHOSTSTATE_FRIGHTENED) {
          ghost.state = GhostState.GHOSTSTATE_EYES;
          start(ghost.eaten);
          start(state.game.ghostEaten);
          state.game.numGhostsEaten = (state.game.numGhostsEaten + 1) & 0xff;
          // increase score by 20, 40, 80, 160 (in 10-point units)
          state.game.score += 10 * (1 << state.game.numGhostsEaten);
          state.game.freeze.add(FreezeType.FREEZETYPE_EAT_GHOST);
          sndStart(2, sndEatghost);
        } else if (
          ghost.state === GhostState.GHOSTSTATE_CHASE ||
          ghost.state === GhostState.GHOSTSTATE_SCATTER
        ) {
          sndClear();
          start(state.game.pacmanEaten);
          state.game.freeze.add(FreezeType.FREEZETYPE_DEAD);
          if (state.game.numLives > 0) {
            startAfter(state.game.readyStarted, PACMAN_EATEN_TICKS + PACMAN_DEATH_TICKS);
          } else {
            startAfter(state.game.gameOver, PACMAN_EATEN_TICKS + PACMAN_DEATH_TICKS);
          }
        }
      }
    }
  }

  // Ghost "AIs"
  for (let ghostIndex = 0; ghostIndex < state.game.ghost.length; ghostIndex++) {
    const ghost = state.game.ghost[ghostIndex]!;
    updateGhostState(ghost);
    updateGhostTarget(ghost);
    const numMoveTicks = ghostSpeed(ghost);
    for (let i = 0; i < numMoveTicks; i++) {
      const forceMove = updateGhostDir(ghost);
      if (forceMove || canMove(ghost.actor.pos, ghost.actor.dir, false)) {
        ghost.actor.pos = move(ghost.actor.pos, ghost.actor.dir, false);
        ghost.actor.animTick += 1;
      }
    }
  }
}

// the central game tick function, called at 60 Hz
export function gameTick(): void {
  if (now(state.game.started)) {
    start(state.gfx.fadein);
    startAfter(state.game.readyStarted, 2 * 60);
    sndStart(0, sndPrelude);
    gameInit();
  }
  if (now(state.game.readyStarted)) {
    gameRoundInit();
    startAfter(state.game.roundStarted, 2 * 60 + 10);
  }
  if (now(state.game.roundStarted)) {
    state.game.freeze.delete(FreezeType.FREEZETYPE_READY);
    vidColorText(i2(11, 20), 0x10, '      ');
    sndStart(1, sndWeeooh);
  }

  // activate/deactivate bonus fruit
  if (now(state.game.fruitActive)) {
    state.game.activeFruit = levelspec(state.game.round).bonusFruit;
  } else if (afterOnce(state.game.fruitActive, FRUITACTIVE_TICKS)) {
    state.game.activeFruit = Fruit.FRUIT_NONE;
  }

  // stop frightened sound and restart the weeooh sound
  if (afterOnce(state.game.pillEaten, levelspec(state.game.round).frightTicks)) {
    sndStart(1, sndWeeooh);
  }

  // unfreeze after Pacman ate a ghost
  if (state.game.freeze.has(FreezeType.FREEZETYPE_EAT_GHOST)) {
    if (afterOnce(state.game.ghostEaten, GHOST_EATEN_FREEZE_TICKS)) {
      state.game.freeze.delete(FreezeType.FREEZETYPE_EAT_GHOST);
    }
  }

  // play the pacman-death sound
  if (afterOnce(state.game.pacmanEaten, PACMAN_EATEN_TICKS)) {
    sndStart(2, sndDead);
  }

  if (state.game.freeze.size === 0) {
    gameUpdateActors();
  }
  gameUpdateTiles();
  gameUpdateSprites();

  if (state.game.score > state.game.hiscore) {
    state.game.hiscore = state.game.score;
  }

  // check for end-of-round conditions
  if (now(state.game.roundWon)) {
    state.game.freeze.add(FreezeType.FREEZETYPE_WON);
    startAfter(state.game.readyStarted, ROUNDWON_TICKS);
  }
  if (now(state.game.gameOver)) {
    vidColorText(i2(9, 20), 0x01, 'GAME  OVER');
    inputDisable();
    startAfter(state.gfx.fadeout, GAMEOVER_TICKS);
    startAfter(state.intro.started, GAMEOVER_TICKS + FADE_TICKS);
  }
}

// the intro screen tick function
export function introTick(): void {
  if (now(state.intro.started)) {
    sndClear();
    sprClear();
    start(state.gfx.fadein);
    inputEnable();
    vidClear(TILE_SPACE, COLOR_DEFAULT);
    vidText(i2(3, 0), '1UP   HIGH SCORE   2UP');
    vidColorScore(i2(6, 1), COLOR_DEFAULT, 0);
    if (state.game.hiscore > 0) {
      vidColorScore(i2(16, 1), COLOR_DEFAULT, state.game.hiscore);
    }
    vidText(i2(7, 5), 'CHARACTER / NICKNAME');
    vidText(i2(3, 35), 'CREDIT  0');
  }

  let delay = 30;
  const names = ['-SHADOW', '-SPEEDY', '-BASHFUL', '-POKEY'];
  const nicknames = ['BLINKY', 'PINKY', 'INKY', 'CLYDE'];
  for (let i = 0; i < 4; i++) {
    const color = 2 * i + 1;
    const y = 3 * i + 6;
    delay += 30;
    if (afterOnce(state.intro.started, delay)) {
      vidColorTile(i2(4, y + 0), color, TILE_GHOST + 0);
      vidColorTile(i2(5, y + 0), color, TILE_GHOST + 1);
      vidColorTile(i2(4, y + 1), color, TILE_GHOST + 2);
      vidColorTile(i2(5, y + 1), color, TILE_GHOST + 3);
      vidColorTile(i2(4, y + 2), color, TILE_GHOST + 4);
      vidColorTile(i2(5, y + 2), color, TILE_GHOST + 5);
    }
    delay += 60;
    if (afterOnce(state.intro.started, delay)) {
      vidColorText(i2(7, y + 1), color, names[i]!);
    }
    delay += 30;
    if (afterOnce(state.intro.started, delay)) {
      vidColorText(i2(17, y + 1), color, nicknames[i]!);
    }
  }

  delay += 60;
  if (afterOnce(state.intro.started, delay)) {
    vidColorTile(i2(10, 24), COLOR_DOT, TILE_DOT);
    vidText(i2(12, 24), '10 \x5D\x5E\x5F');
    vidColorTile(i2(10, 26), COLOR_DOT, TILE_PILL);
    vidText(i2(12, 26), '50 \x5D\x5E\x5F');
  }

  delay += 60;
  if (after(state.intro.started, delay)) {
    if ((since(state.intro.started) & 0x20) !== 0) {
      vidColorText(i2(3, 31), 3, '                       ');
    } else {
      vidColorText(i2(3, 31), 3, 'PRESS ANY KEY TO START!');
    }
  }

  if (state.input.anykey) {
    inputDisable();
    start(state.gfx.fadeout);
    startAfter(state.game.started, FADE_TICKS);
  }
}

// startup initialization, mirroring pacman.nim's init(): decode the
// graphics data and start the intro. (The Nim sndInit has no counterpart
// in the sound state layer; the AudioContext setup belongs to the
// browser layer, SPEC T3/T4.)
export function initGame(): void {
  gfxInit();
  start(state.intro.started);
}

// perform exactly one game tick: the tick part of pacman.nim's frame().
export function runTick(): void {
  state.timing.tick += 1;
  sndTick();
  if (now(state.intro.started)) {
    state.gamestate = GameState.GAMESTATE_INTRO;
  }
  if (now(state.game.started)) {
    state.gamestate = GameState.GAMESTATE_GAME;
  }
  if (state.gamestate === GameState.GAMESTATE_INTRO) {
    introTick();
  } else {
    gameTick();
  }
}
