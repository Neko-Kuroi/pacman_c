// sound.ts -- the Namco sound-board register layer and sound effects.
// Corresponds to pacman.c lines 638-678 (descriptions) and 3125-3388
// (logic). The sample generation itself lives in synth.ts and runs in
// the AudioWorklet (SPEC T3); this module maintains the sound/voice
// register state on the game side, exactly like the original.

import {
  state,
  newVoice,
  newSound,
  NUM_VOICES,
  NUM_SOUNDS,
  SoundFlag,
  SOUNDFLAG_ALL_VOICES,
  NO_SOUND_FUNC,
  type SoundDesc,
} from './state.js';
import { sndDumpPrelude, sndDumpDead } from './romdata.js';

// clear all active sound effects and start outputting silence
export function sndClear(): void {
  for (let i = 0; i < NUM_VOICES; i++) {
    state.audio.voice[i] = newVoice();
  }
  for (let i = 0; i < NUM_SOUNDS; i++) {
    state.audio.sound[i] = newSound();
  }
}

// stop a sound effect
export function sndStop(slot: number): void {
  if (!(slot >= 0 && slot < NUM_SOUNDS)) throw new Error('sndStop: bad slot');
  for (let i = 0; i < NUM_VOICES; i++) {
    if (state.audio.sound[slot]!.flags.has(i as SoundFlag)) {
      state.audio.voice[i] = newVoice();
    }
  }
  state.audio.sound[slot] = newSound();
}

// start a sound effect
export function sndStart(slot: number, desc: SoundDesc): void {
  if (!(slot >= 0 && slot < NUM_SOUNDS)) throw new Error('sndStart: bad slot');
  if (!((desc.data !== null && desc.size !== 0) || desc.fn !== NO_SOUND_FUNC))
    throw new Error('sndStart: empty desc');
  const snd = newSound();
  state.audio.sound[slot] = snd;
  let numVoices = 0;
  for (let i = 0; i < NUM_VOICES; i++) {
    if (desc.voice[i]) {
      snd.flags.add(i as SoundFlag);
      numVoices += 1;
    }
  }
  if (desc.fn !== NO_SOUND_FUNC) {
    snd.fn = desc.fn;
  } else {
    if (!(numVoices > 0)) throw new Error('sndStart: dump needs voices');
    if (desc.size % (numVoices * 4) !== 0) throw new Error('sndStart: bad dump size');
    snd.stride = numVoices;
    snd.numTicks = Math.trunc(desc.size / (snd.stride * 4));
    snd.data = desc.data;
  }
}

// --- procedural sound effects (pacman.c 3281-3388) ---
// Identified by index into soundGenerators (see state.ts SoundFuncId).

function sndFuncEatdot1(slot: number): void {
  const snd = state.audio.sound[slot]!;
  const voice = state.audio.voice[2]!;
  if (snd.curTick === 0) {
    voice.volume = 12;
    voice.waveform = 2;
    voice.frequency = 0x1500;
  } else if (snd.curTick === 5) {
    sndStop(slot);
  } else {
    voice.frequency -= 0x0300;
  }
}

function sndFuncEatdot2(slot: number): void {
  const snd = state.audio.sound[slot]!;
  const voice = state.audio.voice[2]!;
  if (snd.curTick === 0) {
    voice.volume = 12;
    voice.waveform = 2;
    voice.frequency = 0x0700;
  } else if (snd.curTick === 5) {
    sndStop(slot);
  } else {
    voice.frequency += 0x300;
  }
}

function sndFuncEatghost(slot: number): void {
  const snd = state.audio.sound[slot]!;
  const voice = state.audio.voice[2]!;
  if (snd.curTick === 0) {
    voice.volume = 12;
    voice.waveform = 5;
    voice.frequency = 0;
  } else if (snd.curTick === 32) {
    sndStop(slot);
  } else {
    voice.frequency += 0x20;
  }
}

function sndFuncEatfruit(slot: number): void {
  const snd = state.audio.sound[slot]!;
  const voice = state.audio.voice[2]!;
  if (snd.curTick === 0) {
    voice.volume = 15;
    voice.waveform = 6;
    voice.frequency = 0x1600;
  } else if (snd.curTick === 23) {
    sndStop(slot);
  } else if (snd.curTick < 11) {
    voice.frequency -= 0x200;
  } else {
    voice.frequency += 0x0200;
  }
}

function sndFuncWeeooh(slot: number): void {
  const snd = state.audio.sound[slot]!;
  const voice = state.audio.voice[1]!;
  if (snd.curTick === 0) {
    voice.volume = 6;
    voice.waveform = 6;
    voice.frequency = 0x1000;
  } else if (snd.curTick % 24 < 12) {
    voice.frequency += 0x0200;
  } else {
    voice.frequency -= 0x0200;
  }
}

function sndFuncFrightened(slot: number): void {
  const snd = state.audio.sound[slot]!;
  const voice = state.audio.voice[1]!;
  if (snd.curTick === 0) {
    voice.volume = 10;
    voice.waveform = 4;
    voice.frequency = 0x0180;
  } else if (snd.curTick % 8 === 0) {
    voice.frequency = 0x0180;
  } else {
    voice.frequency += 0x180;
  }
}

export const GEN_EATDOT1 = 0;
export const GEN_EATDOT2 = 1;
export const GEN_EATGHOST = 2;
export const GEN_EATFRUIT = 3;
export const GEN_WEEOOH = 4;
export const GEN_FRIGHTENED = 5;

export const soundGenerators: ((slot: number) => void)[] = [
  sndFuncEatdot1,
  sndFuncEatdot2,
  sndFuncEatghost,
  sndFuncEatfruit,
  sndFuncWeeooh,
  sndFuncFrightened,
];

// --- sound effect descriptions (pacman.c 638-678) ---
export const sndPrelude: SoundDesc = {
  fn: NO_SOUND_FUNC,
  data: sndDumpPrelude,
  size: sndDumpPrelude.byteLength,
  voice: [true, true, false],
};
export const sndDead: SoundDesc = {
  fn: NO_SOUND_FUNC,
  data: sndDumpDead,
  size: sndDumpDead.byteLength,
  voice: [false, false, true],
};
export const sndEatdot1: SoundDesc = { fn: GEN_EATDOT1, data: null, size: 0, voice: [false, false, true] };
export const sndEatdot2: SoundDesc = { fn: GEN_EATDOT2, data: null, size: 0, voice: [false, false, true] };
export const sndEatghost: SoundDesc = { fn: GEN_EATGHOST, data: null, size: 0, voice: [false, false, true] };
export const sndEatfruit: SoundDesc = { fn: GEN_EATFRUIT, data: null, size: 0, voice: [false, false, true] };
export const sndWeeooh: SoundDesc = { fn: GEN_WEEOOH, data: null, size: 0, voice: [false, true, false] };
export const sndFrightened: SoundDesc = { fn: GEN_FRIGHTENED, data: null, size: 0, voice: [false, true, false] };

// the sound system's 60 Hz tick function (called from the game tick)
export function sndTick(): void {
  for (let slot = 0; slot < NUM_SOUNDS; slot++) {
    let snd = state.audio.sound[slot]!;
    let skipIncrement = false;
    if (snd.fn !== NO_SOUND_FUNC) {
      soundGenerators[snd.fn]!(slot);
      // a generator may stop its own sound, which replaces the slot
      // object (sndStop); the increment below must land on the
      // current object, as in Nim where the slot is reached through
      // a pointer after the call
      snd = state.audio.sound[slot]!;
    } else if (snd.flags.size > 0 && [...snd.flags].some((f) => SOUNDFLAG_ALL_VOICES.has(f))) {
      if (snd.data === null) throw new Error('sndTick: dump sound without data');
      if (snd.curTick === snd.numTicks) {
        sndStop(slot);
        skipIncrement = true;
      } else {
        let idx = snd.curTick * snd.stride;
        for (let i = 0; i < NUM_VOICES; i++) {
          if (snd.flags.has(i as SoundFlag)) {
            const voice = state.audio.voice[i]!;
            const val = snd.data[idx]!;
            idx += 1;
            voice.frequency = val & ((1 << 20) - 1);
            voice.waveform = (val >>> 24) & 7;
            voice.volume = (val >>> 28) & 0xf;
          }
        }
      }
    }
    if (!skipIncrement) {
      snd.curTick += 1;
    }
  }
}

// The current voice registers, for the AudioWorklet bridge (SPEC T3).
// The synth keeps its own phase counters; only the register values
// cross the boundary.
export interface VoiceRegs {
  frequency: number;
  waveform: number;
  volume: number;
}

export function voiceSnapshot(): VoiceRegs[] {
  return state.audio.voice.map((v) => ({
    frequency: v.frequency,
    waveform: v.waveform,
    volume: v.volume,
  }));
}
