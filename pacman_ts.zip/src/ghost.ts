// ghost.ts -- ghost speed, state machine, target selection and steering.
// Corresponds to pacman.c lines 1750-2087.
// Translation of the Nim port's ghost.nim.

import {
  state,
  i2,
  add,
  sub,
  scale,
  squaredDistance,
  nearEqual,
  levelspec,
  ghostScatterTargets,
  ghostHouseTargetPos,
  TILE_HEIGHT,
  DISPLAY_TILES_X,
  DISPLAY_TILES_Y,
  ANTEPORTAS_X,
  ANTEPORTAS_Y,
  Dir,
  GhostState,
  GhostType,
  type Ghost,
  type Int2,
} from './state.js';
import { since, before, afterOnce, start, disable, xorshift32 } from './timing.js';
import {
  idiv,
  pixelToTilePos,
  clampedTilePos,
  dirToVec,
  reverseDir,
  distToTileMid,
  isBlockingTile,
  isTunnel,
  isRedzone,
} from './geom.js';

export function ghostSpeed(ghost: Ghost): number {
  switch (ghost.state) {
    case GhostState.GHOSTSTATE_HOUSE:
    case GhostState.GHOSTSTATE_LEAVEHOUSE:
    case GhostState.GHOSTSTATE_FRIGHTENED:
      // inside house / frightened: half speed
      return state.timing.tick & 1;
    case GhostState.GHOSTSTATE_EYES:
    case GhostState.GHOSTSTATE_ENTERHOUSE:
      // estimated 1.5x in eye state
      return (state.timing.tick & 1) !== 0 ? 1 : 2;
    default:
      if (isTunnel(pixelToTilePos(ghost.actor.pos))) {
        return ((state.timing.tick * 2) % 4) !== 0 ? 1 : 0;
      }
      return state.timing.tick % 7 !== 0 ? 1 : 0;
  }
}

// return the current global scatter or chase phase
export function scatterChasePhase(): GhostState {
  const t = since(state.game.roundStarted);
  if (t < 7 * 60) return GhostState.GHOSTSTATE_SCATTER;
  if (t < 27 * 60) return GhostState.GHOSTSTATE_CHASE;
  if (t < 34 * 60) return GhostState.GHOSTSTATE_SCATTER;
  if (t < 54 * 60) return GhostState.GHOSTSTATE_CHASE;
  if (t < 59 * 60) return GhostState.GHOSTSTATE_SCATTER;
  if (t < 79 * 60) return GhostState.GHOSTSTATE_CHASE;
  if (t < 84 * 60) return GhostState.GHOSTSTATE_SCATTER;
  return GhostState.GHOSTSTATE_CHASE;
}

// takes care of switching a ghost into a new state
export function updateGhostState(ghost: Ghost): void {
  let newState = ghost.state;
  switch (ghost.state) {
    case GhostState.GHOSTSTATE_EYES:
      if (nearEqual(ghost.actor.pos, i2(ANTEPORTAS_X, ANTEPORTAS_Y), 1)) {
        newState = GhostState.GHOSTSTATE_ENTERHOUSE;
      }
      break;
    case GhostState.GHOSTSTATE_ENTERHOUSE:
      if (nearEqual(ghost.actor.pos, ghostHouseTargetPos[ghost.typ]!, 1)) {
        newState = GhostState.GHOSTSTATE_LEAVEHOUSE;
      }
      break;
    case GhostState.GHOSTSTATE_HOUSE:
      if (afterOnce(state.game.forceLeaveHouse, 4 * 60)) {
        newState = GhostState.GHOSTSTATE_LEAVEHOUSE;
        start(state.game.forceLeaveHouse);
      } else if (state.game.globalDotCounterActive) {
        if (ghost.typ === GhostType.GHOSTTYPE_PINKY && state.game.globalDotCounter === 7) {
          newState = GhostState.GHOSTSTATE_LEAVEHOUSE;
        } else if (ghost.typ === GhostType.GHOSTTYPE_INKY && state.game.globalDotCounter === 17) {
          newState = GhostState.GHOSTSTATE_LEAVEHOUSE;
        } else if (ghost.typ === GhostType.GHOSTTYPE_CLYDE && state.game.globalDotCounter === 32) {
          newState = GhostState.GHOSTSTATE_LEAVEHOUSE;
          // the global dot counter is deactivated when Clyde leaves at 32
          state.game.globalDotCounterActive = false;
        }
      } else if (ghost.dotCounter === ghost.dotLimit) {
        newState = GhostState.GHOSTSTATE_LEAVEHOUSE;
      }
      break;
    case GhostState.GHOSTSTATE_LEAVEHOUSE:
      if (ghost.actor.pos.y === ANTEPORTAS_Y) {
        newState = GhostState.GHOSTSTATE_SCATTER;
      }
      break;
    default:
      if (before(ghost.frightened, levelspec(state.game.round).frightTicks)) {
        newState = GhostState.GHOSTSTATE_FRIGHTENED;
      } else {
        newState = scatterChasePhase();
      }
      break;
  }
  // handle state transitions
  if (newState !== ghost.state) {
    switch (ghost.state) {
      case GhostState.GHOSTSTATE_LEAVEHOUSE:
        ghost.nextDir = Dir.DIR_LEFT;
        ghost.actor.dir = Dir.DIR_LEFT;
        break;
      case GhostState.GHOSTSTATE_ENTERHOUSE:
        // a ghost that was eaten is immune to frighten until the next pill
        disable(ghost.frightened);
        break;
      case GhostState.GHOSTSTATE_FRIGHTENED:
        break; // don't reverse direction when leaving frightened state
      case GhostState.GHOSTSTATE_SCATTER:
      case GhostState.GHOSTSTATE_CHASE:
        // any transition from scatter/chase causes a reversal of direction
        ghost.nextDir = reverseDir(ghost.actor.dir);
        break;
      default:
        break;
    }
    ghost.state = newState;
  }
}

// update the ghost's target position
export function updateGhostTarget(ghost: Ghost): void {
  let pos: Int2 = ghost.targetPos;
  switch (ghost.state) {
    case GhostState.GHOSTSTATE_SCATTER:
      pos = ghostScatterTargets[ghost.typ]!;
      break;
    case GhostState.GHOSTSTATE_CHASE: {
      const pm = state.game.pacman.actor;
      const pmPos = pixelToTilePos(pm.pos);
      const pmDir = dirToVec(pm.dir);
      switch (ghost.typ) {
        case GhostType.GHOSTTYPE_BLINKY:
          pos = pmPos;
          break;
        case GhostType.GHOSTTYPE_PINKY:
          // 4 tiles ahead of Pacman (without the arcade 'diagonal overflow')
          pos = add(pmPos, scale(pmDir, 4));
          break;
        case GhostType.GHOSTTYPE_INKY: {
          const blinkyPos = pixelToTilePos(
            state.game.ghost[GhostType.GHOSTTYPE_BLINKY]!.actor.pos,
          );
          const p = add(pmPos, scale(pmDir, 2));
          const d = sub(p, blinkyPos);
          pos = add(blinkyPos, scale(d, 2));
          break;
        }
        case GhostType.GHOSTTYPE_CLYDE:
          if (squaredDistance(pixelToTilePos(ghost.actor.pos), pmPos) > 64) {
            pos = pmPos;
          } else {
            pos = ghostScatterTargets[GhostType.GHOSTTYPE_CLYDE]!;
          }
          break;
        default:
          break;
      }
      break;
    }
    case GhostState.GHOSTSTATE_FRIGHTENED:
      // random target position (random direction at each intersection)
      pos = i2(xorshift32() % DISPLAY_TILES_X, xorshift32() % DISPLAY_TILES_Y);
      break;
    case GhostState.GHOSTSTATE_EYES:
      pos = i2(13, 14);
      break;
    default:
      break;
  }
  ghost.targetPos = pos;
}

// compute the next ghost direction; returns true if the resulting movement
// should always happen (movement inside the ghost house)
export function updateGhostDir(ghost: Ghost): boolean {
  if (ghost.state === GhostState.GHOSTSTATE_HOUSE) {
    if (ghost.actor.pos.y <= 17 * TILE_HEIGHT) {
      ghost.nextDir = Dir.DIR_DOWN;
    } else if (ghost.actor.pos.y >= 18 * TILE_HEIGHT) {
      ghost.nextDir = Dir.DIR_UP;
    }
    ghost.actor.dir = ghost.nextDir;
    return true;
  } else if (ghost.state === GhostState.GHOSTSTATE_LEAVEHOUSE) {
    const pos = ghost.actor.pos;
    if (pos.x === ANTEPORTAS_X) {
      if (pos.y > ANTEPORTAS_Y) {
        ghost.nextDir = Dir.DIR_UP;
      }
    } else {
      const midY = 17 * TILE_HEIGHT + idiv(TILE_HEIGHT, 2);
      if (pos.y > midY) {
        ghost.nextDir = Dir.DIR_UP;
      } else if (pos.y < midY) {
        ghost.nextDir = Dir.DIR_DOWN;
      } else {
        ghost.nextDir = pos.x > ANTEPORTAS_X ? Dir.DIR_LEFT : Dir.DIR_RIGHT;
      }
    }
    ghost.actor.dir = ghost.nextDir;
    return true;
  } else if (ghost.state === GhostState.GHOSTSTATE_ENTERHOUSE) {
    const pos = ghost.actor.pos;
    const tilePos = pixelToTilePos(pos);
    const tgtPos = ghostHouseTargetPos[ghost.typ]!;
    if (tilePos.y === 14) {
      if (pos.x !== ANTEPORTAS_X) {
        ghost.nextDir = pos.x < ANTEPORTAS_X ? Dir.DIR_RIGHT : Dir.DIR_LEFT;
      } else {
        ghost.nextDir = Dir.DIR_DOWN;
      }
    } else if (pos.y === tgtPos.y) {
      ghost.nextDir = pos.x < tgtPos.x ? Dir.DIR_RIGHT : Dir.DIR_LEFT;
    }
    ghost.actor.dir = ghost.nextDir;
    return true;
  } else {
    // scatter/chase/frightened: head towards the current target point
    const distToMid = distToTileMid(ghost.actor.pos);
    if (distToMid.x === 0 && distToMid.y === 0) {
      ghost.actor.dir = ghost.nextDir;
      const dirVec = dirToVec(ghost.actor.dir);
      const lookaheadPos = add(pixelToTilePos(ghost.actor.pos), dirVec);
      const dirs = [Dir.DIR_UP, Dir.DIR_LEFT, Dir.DIR_DOWN, Dir.DIR_RIGHT];
      let minDist = 100000;
      for (const dir of dirs) {
        // in the two 'red zones', upward movement is forbidden (except eyes)
        if (
          isRedzone(lookaheadPos) &&
          dir === Dir.DIR_UP &&
          ghost.state !== GhostState.GHOSTSTATE_EYES
        ) {
          continue;
        }
        const revdir = reverseDir(dir);
        const testPos = clampedTilePos(add(lookaheadPos, dirToVec(dir)));
        if (revdir !== ghost.actor.dir && !isBlockingTile(testPos)) {
          const dist = squaredDistance(testPos, ghost.targetPos);
          if (dist < minDist) {
            minDist = dist;
            ghost.nextDir = dir;
          }
        }
      }
    }
    return false;
  }
}

// update the dot counters used to decide whether ghosts must leave the house
// (called each time Pacman eats a dot)
export function updateGhosthouseDotCounters(): void {
  if (state.game.globalDotCounterActive) {
    state.game.globalDotCounter = (state.game.globalDotCounter + 1) & 0xff;
  } else {
    for (let i = 0; i < state.game.ghost.length; i++) {
      const g = state.game.ghost[i]!;
      if (g.dotCounter < g.dotLimit) {
        g.dotCounter += 1;
        break;
      }
    }
  }
}
