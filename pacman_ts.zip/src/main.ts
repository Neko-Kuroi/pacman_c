// main.ts -- application entry point.
// Corresponds to pacman.nim (pacman.c lines 716-825: the sokol-app
// init/frame callbacks), with sokol-app replaced by
// requestAnimationFrame and DOM events (SPEC T2/T8/T10) and
// sokol-audio replaced by an AudioWorklet bridge (SPEC T3/T4).

import {
  state,
  TICK_DURATION_NS,
  TICK_TOLERANCE_NS,
  DISPLAY_PIXELS_X,
  DISPLAY_PIXELS_Y,
} from './state.js';
import { runTick, initGame } from './rules.js';
import { initRenderer, drawFrame } from './render.js';
import { attachInput, pollInput } from './input.js';
import { voiceSnapshot } from './sound.js';

// --- audio bridge (SPEC T3/T4) ---
//
// The AudioContext is created lazily on the first user gesture
// (autoplay policy). If setup fails, the game simply runs silently.
//
// Two robustness points (external review): resume() is called
// synchronously inside the gesture, before any await -- after an
// await the call may fall outside the gesture window and the
// context stays suspended (notably on iOS). And the gesture
// listeners are not one-shot: a later gesture retries the resume
// if the first attempt did not start the sound.

let audioCtx: AudioContext | null = null;
let audioPort: MessagePort | null = null;
let audioSetupStarted = false;

function resumeAudio(): void {
  if (audioCtx === null) return;
  // 'interrupted' (iOS, after an interruption) needs a resume just
  // like 'suspended'; a closed context cannot be resumed
  if (audioCtx.state !== 'running' && audioCtx.state !== 'closed') {
    void audioCtx.resume();
  }
}

async function setupAudio(): Promise<void> {
  if (audioCtx !== null) {
    resumeAudio();
    return;
  }
  if (audioSetupStarted) return;
  audioSetupStarted = true;
  try {
    const ctx = new AudioContext();
    audioCtx = ctx;
    void ctx.resume();
    await ctx.audioWorklet.addModule(new URL('./worklet.js', import.meta.url));
    const node = new AudioWorkletNode(ctx, 'pacman-synth');
    node.connect(ctx.destination);
    audioPort = node.port;
  } catch {
    audioPort = null;
    // reset, so the next gesture retries the setup from the
    // beginning (a failed module load must not silence the game
    // for the whole session)
    const failed = audioCtx;
    audioCtx = null;
    audioSetupStarted = false;
    if (failed !== null) void failed.close();
  }
}

// While the tab is hidden, requestAnimationFrame stops and no new
// register snapshots reach the worklet, which would keep sounding
// the last state forever; suspend the context instead, and resume
// when the tab is visible again.
function onVisibilityChange(): void {
  if (audioCtx === null) return;
  if (document.hidden) {
    void audioCtx.suspend();
  } else {
    resumeAudio();
  }
}

// --- the frame loop: pacman.nim frame() ---
//
// Run the game at a fixed tick rate regardless of frame rate: real
// elapsed time is accumulated and converted into whole ticks, with
// the frame time clamped to 33,333,333 ns (the original's design,
// carried over unchanged -- SPEC section 1).

const FRAME_TIME_MAX_NS = 33_333_333;

function frame(): void {
  const nowMs = performance.now();
  let frameTimeNs = Math.trunc((nowMs - state.timing.laptimeStore) * 1_000_000);
  state.timing.laptimeStore = nowMs;
  if (frameTimeNs > FRAME_TIME_MAX_NS) frameTimeNs = FRAME_TIME_MAX_NS;
  if (frameTimeNs < 0) frameTimeNs = 0;
  state.timing.tickAccum += frameTimeNs;
  pollInput();
  let ticks = 0;
  while (state.timing.tickAccum > -TICK_TOLERANCE_NS) {
    state.timing.tickAccum -= TICK_DURATION_NS;
    runTick();
    ticks++;
  }
  drawFrame();
  if (audioPort !== null && ticks > 0) {
    audioPort.postMessage(voiceSnapshot());
  }
  requestAnimationFrame(frame);
}

// --- init: pacman.nim init() ---
//
// initGame() (rules.ts) performs the game-side init: gfxInit and the
// intro start; the xorshift seed is set by gameInit in rules.ts.
// initRenderer then creates the Canvas resources (it runs the
// idempotent gfxInit decode once more). sndInit's counterpart is the
// lazy AudioContext setup above.

// Scale the display to the window at an integer multiple of the
// logical 224x288 (SPEC T2), so the game fits phone screens
// instead of being clipped at a fixed 448x576. If even 1x does not
// fit, fall back to a fractional fit rather than clipping.
function fitCanvas(canvas: HTMLCanvasElement): void {
  const fit = Math.min(window.innerWidth / DISPLAY_PIXELS_X, window.innerHeight / DISPLAY_PIXELS_Y);
  const scale = Math.floor(fit);
  let w: number;
  let h: number;
  if (scale >= 1) {
    w = DISPLAY_PIXELS_X * scale;
    h = DISPLAY_PIXELS_Y * scale;
  } else {
    w = Math.max(1, Math.floor(DISPLAY_PIXELS_X * fit));
    h = Math.max(1, Math.floor(DISPLAY_PIXELS_Y * fit));
  }
  canvas.style.width = `${w}px`;
  canvas.style.height = `${h}px`;
}

function init(): void {
  const canvas = document.getElementById('game');
  if (!(canvas instanceof HTMLCanvasElement)) throw new Error('main: #game canvas not found');
  initGame();
  initRenderer(canvas);
  attachInput();
  fitCanvas(canvas);
  window.addEventListener('resize', () => fitCanvas(canvas));
  const kickAudio = (): void => {
    void setupAudio();
  };
  window.addEventListener('keydown', kickAudio);
  window.addEventListener('pointerdown', kickAudio);
  window.addEventListener('touchend', kickAudio);
  window.addEventListener('click', kickAudio);
  document.addEventListener('visibilitychange', onVisibilityChange);
  state.timing.laptimeStore = performance.now();
  requestAnimationFrame(frame);
}

init();
