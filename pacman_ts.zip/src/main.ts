// main.ts -- application entry point.
// Corresponds to pacman.nim (pacman.c lines 716-825: the sokol-app
// init/frame callbacks), with sokol-app replaced by
// requestAnimationFrame and DOM events (SPEC T2/T8/T10) and
// sokol-audio replaced by an AudioWorklet bridge (SPEC T3/T4).

import { state, TICK_DURATION_NS, TICK_TOLERANCE_NS } from './state.js';
import { runTick, initGame } from './rules.js';
import { initRenderer, drawFrame } from './render.js';
import { attachInput, pollInput } from './input.js';
import { voiceSnapshot } from './sound.js';

// --- audio bridge (SPEC T3/T4) ---
//
// The AudioContext is created lazily on the first user gesture
// (autoplay policy). If setup fails, the game simply runs silently.

let audioPort: MessagePort | null = null;
let audioSetupStarted = false;

async function setupAudio(): Promise<void> {
  if (audioSetupStarted) return;
  audioSetupStarted = true;
  try {
    const ctx = new AudioContext();
    await ctx.audioWorklet.addModule(new URL('./worklet.js', import.meta.url));
    const node = new AudioWorkletNode(ctx, 'pacman-synth');
    node.connect(ctx.destination);
    await ctx.resume();
    audioPort = node.port;
  } catch {
    audioPort = null;
  }
}

// --- the frame loop: pacman.nim frame() ---
//
// Run the game at a fixed tick rate regardless of frame rate: real
// elapsed time is accumulated and converted into whole ticks, with
// the frame time clamped to 33,333,333 ns (the original's design,
// carried over unchanged -- SPEC section 1).

const FRAME_TIME_MAX_NS = 33_333_333;

function frame(): void {
  const nowMs = performance.now();
  let frameTimeNs = Math.trunc((nowMs - state.timing.laptimeStore) * 1_000_000);
  state.timing.laptimeStore = nowMs;
  if (frameTimeNs > FRAME_TIME_MAX_NS) frameTimeNs = FRAME_TIME_MAX_NS;
  if (frameTimeNs < 0) frameTimeNs = 0;
  state.timing.tickAccum += frameTimeNs;
  pollInput();
  let ticks = 0;
  while (state.timing.tickAccum > -TICK_TOLERANCE_NS) {
    state.timing.tickAccum -= TICK_DURATION_NS;
    runTick();
    ticks++;
  }
  drawFrame();
  if (audioPort !== null && ticks > 0) {
    audioPort.postMessage(voiceSnapshot());
  }
  requestAnimationFrame(frame);
}

// --- init: pacman.nim init() ---
//
// initGame() (rules.ts) performs the game-side init: gfxInit and the
// intro start; the xorshift seed is set by gameInit in rules.ts.
// initRenderer then creates the Canvas resources (it runs the
// idempotent gfxInit decode once more). sndInit's counterpart is the
// lazy AudioContext setup above.

function init(): void {
  const canvas = document.getElementById('game');
  if (!(canvas instanceof HTMLCanvasElement)) throw new Error('main: #game canvas not found');
  initGame();
  initRenderer(canvas);
  attachInput();
  const kickAudio = (): void => {
    void setupAudio();
  };
  window.addEventListener('keydown', kickAudio, { once: true });
  window.addEventListener('pointerdown', kickAudio, { once: true });
  state.timing.laptimeStore = performance.now();
  requestAnimationFrame(frame);
}

init();
