// input.ts -- keyboard and touch input (SPEC T8).
// Corresponds to the input() callback in pacman.nim (pacman.c's
// sokol-app event callback): DOM key events are the closest browser
// equivalent for the keyboard. Touch follows the design decided for
// the Go port (SPEC H8 there): swipe with a latch, tap is "any key".
//
// This module is the single input merge point: the keyboard and touch
// listeners below resolve into the state.input fields, and nothing
// else in the game reads input devices. A future gamepad source
// would feed the same resolution. Like the original's event
// callback, nothing is written while input is disabled.
//
// Resolution (as in the Go port): held keyboard directions win;
// the latched touch direction applies only when nothing is held.
// timing.ts inputDir() then applies the original's priority
// (up, down, right, left) to the resolved flags.

import {
  state,
  Dir,
  DISPLAY_PIXELS_X,
  DISPLAY_PIXELS_Y,
} from './state.js';

// logical pixels a swipe must travel before it counts (about 3 tiles)
export const TOUCH_SWIPE_THRESHOLD = 24;

// The direction of a swipe delta, or null below the threshold.
// The larger axis wins; a tie goes vertical (as in the Go port).
export function swipeDirection(dx: number, dy: number): Dir | null {
  if (Math.max(Math.abs(dx), Math.abs(dy)) < TOUCH_SWIPE_THRESHOLD) return null;
  if (Math.abs(dx) > Math.abs(dy)) {
    return dx > 0 ? Dir.DIR_RIGHT : Dir.DIR_LEFT;
  }
  return dy > 0 ? Dir.DIR_DOWN : Dir.DIR_UP;
}

export interface HeldDirs {
  up: boolean;
  down: boolean;
  left: boolean;
  right: boolean;
}

// Resolve held keyboard directions and the touch latch into the
// direction flags the game sees: held first, then the latch.
export function resolveDirections(kb: HeldDirs, latch: Dir | null): HeldDirs {
  if (kb.up || kb.down || kb.left || kb.right) {
    return { up: kb.up, down: kb.down, left: kb.left, right: kb.right };
  }
  return {
    up: latch === Dir.DIR_UP,
    down: latch === Dir.DIR_DOWN,
    left: latch === Dir.DIR_LEFT,
    right: latch === Dir.DIR_RIGHT,
  };
}

// --- merged input state (this module only) ---
const kb: HeldDirs = { up: false, down: false, left: false, right: false };
let kbAny = false;
let touchLatch: Dir | null = null;
let tapActive = false;

function publishDirections(): void {
  const r = resolveDirections(kb, touchLatch);
  state.input.up = r.up;
  state.input.down = r.down;
  state.input.left = r.left;
  state.input.right = r.right;
}

function writeAnykey(): void {
  state.input.anykey = kbAny || tapActive;
}

let tapPending = false;
let tapClearArmed = false;

function pulseTap(): void {
  tapPending = true;
}

// Called once per frame from main.ts (the counterpart of the Go
// port's per-Update input read): a tap's "any key" is visible for
// exactly one frame's ticks, and a tap that lands while input is
// disabled is dropped -- nothing is written while disabled.
export function pollInput(): void {
  if (tapClearArmed) {
    tapClearArmed = false;
    tapActive = false;
    if (state.input.enabled) writeAnykey();
  }
  if (tapPending) {
    tapPending = false;
    if (state.input.enabled) {
      tapActive = true;
      writeAnykey();
      tapClearArmed = true;
    }
  }
}

// --- keyboard ---

function toggleFullscreen(): void {
  if (document.fullscreenElement) {
    void document.exitFullscreen();
  } else {
    void document.documentElement.requestFullscreen();
  }
}

function onKey(e: KeyboardEvent, btnDown: boolean): void {
  if (!state.input.enabled) return;
  switch (e.code) {
    case 'ArrowUp':
    case 'KeyW':
      kb.up = btnDown;
      kbAny = btnDown;
      publishDirections();
      writeAnykey();
      break;
    case 'ArrowDown':
    case 'KeyS':
      kb.down = btnDown;
      kbAny = btnDown;
      publishDirections();
      writeAnykey();
      break;
    case 'ArrowLeft':
    case 'KeyA':
      kb.left = btnDown;
      kbAny = btnDown;
      publishDirections();
      writeAnykey();
      break;
    case 'ArrowRight':
    case 'KeyD':
      kb.right = btnDown;
      kbAny = btnDown;
      publishDirections();
      writeAnykey();
      break;
    case 'Escape':
      state.input.esc = btnDown;
      kbAny = btnDown;
      writeAnykey();
      break;
    case 'KeyF':
      if (btnDown) toggleFullscreen();
      break;
    default:
      kbAny = btnDown;
      writeAnykey();
      break;
  }
}

// --- touch: swipe with a latch, tap is "any key" ---

interface TouchTrack {
  id: number;
  originX: number;
  originY: number;
  swiped: boolean;
}

let track: TouchTrack | null = null;

function toLogical(canvas: HTMLCanvasElement, clientX: number, clientY: number): { x: number; y: number } {
  const rect = canvas.getBoundingClientRect();
  return {
    x: ((clientX - rect.left) * DISPLAY_PIXELS_X) / rect.width,
    y: ((clientY - rect.top) * DISPLAY_PIXELS_Y) / rect.height,
  };
}

function attachTouch(canvas: HTMLCanvasElement): void {
  canvas.addEventListener(
    'touchstart',
    (e) => {
      if (!state.input.enabled) return;
      e.preventDefault();
      if (track === null) {
        const t = e.changedTouches[0]!;
        const p = toLogical(canvas, t.clientX, t.clientY);
        track = { id: t.identifier, originX: p.x, originY: p.y, swiped: false };
      }
    },
    { passive: false },
  );
  canvas.addEventListener(
    'touchmove',
    (e) => {
      if (!state.input.enabled) return;
      e.preventDefault();
      if (track === null) return;
      const tr = track;
      for (const t of Array.from(e.changedTouches)) {
        if (t.identifier !== tr.id) continue;
        const p = toLogical(canvas, t.clientX, t.clientY);
        const dir = swipeDirection(p.x - tr.originX, p.y - tr.originY);
        if (dir !== null) {
          touchLatch = dir;
          tr.swiped = true;
          // advance the origin so a long swipe keeps producing directions
          tr.originX = p.x;
          tr.originY = p.y;
          publishDirections();
        }
      }
    },
    { passive: false },
  );
  const end = (e: TouchEvent, allowTap: boolean): void => {
    if (track === null) return;
    const tr = track;
    for (const t of Array.from(e.changedTouches)) {
      if (t.identifier !== tr.id) continue;
      track = null;
      // a release counts as a tap; an OS interruption (touchcancel)
      // does not (as in the Go port, where a tap is judged from the
      // touch being released)
      if (allowTap && !tr.swiped && state.input.enabled) {
        pulseTap();
      }
    }
  };
  canvas.addEventListener('touchend', (e) => end(e, true));
  canvas.addEventListener('touchcancel', (e) => end(e, false));
}

export function attachInput(): void {
  window.addEventListener('keydown', (e) => onKey(e, true));
  window.addEventListener('keyup', (e) => onKey(e, false));
  const canvas = document.getElementById('game');
  if (canvas instanceof HTMLCanvasElement) {
    attachTouch(canvas);
  }
}
