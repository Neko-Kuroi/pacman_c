// worklet.d.ts -- minimal ambient declarations for the AudioWorklet
// global scope, which the DOM lib does not describe. Kept in a
// separate declaration file so worklet.ts can be type-checked in the
// same program as the DOM-based game code without conflicts.

declare class AudioWorkletProcessor {
  readonly port: MessagePort;
  constructor();
}

declare const sampleRate: number;

declare function registerProcessor(
  name: string,
  processorCtor: new () => AudioWorkletProcessor,
): void;
