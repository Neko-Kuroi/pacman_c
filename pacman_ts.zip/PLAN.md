# pacman.c TypeScript 移植 ― 計画書

作成: 2026-11-20
状態: 完了（2026-11-20、報告書は REPORT.md。
ブラウザでの実画面・実音のみ手元確認待ち）
仕様: ~/workspace/pacman_ts/SPEC.md（決定 T1〜T10）
設計: ~/workspace/pacman_ts/DESIGN_SKETCH.md

## 進め方

- 構造の手本は Nim 版（~/workspace/pacman_nim/src/）、
  仕様の正本は pacman.c、決定は SPEC の T1〜T10
- 土台（state / timing / geom / romdata）を先に
  固めて契約とし、残りのモジュールをその上に作る
- 検証は SPEC §4（Node ヘッドレスで 350/66 照合）

## Phase 0 ― 土台の確認

- Node と TypeScript の導入（バージョン固定）
- tsc でコンパイルが通り、Node でテストが
  動くことを確認する
- ブラウザ実行はこの環境では確認できない
  （ランタイムブラウザから VM のローカル
  サーバーへ到達できない。Go 版 WASM と同じ
  事情）。Phase 0 の合格は「ビルド + Node 側の
  検証が通ること」とし、実画面は手元確認とする

## Phase 1 ― 土台の移植

- tools/extract: pacman.c から romdata.ts を生成。
  個数と合計値が SPEC §1 と一致し、再生成が
  バイト一致すること
- state.ts、timing.ts、geom.ts を Nim 版から移植
- 数値意味論の確認: xorshift の列が C と完全一致、
  青点滅のキャストが再現できること

## Phase 2 ― ルールの移植とヘッドレス検証

- ghost.ts、rules.ts を移植
- ヘッドレス検証（Node）: 60,000 ティックの
  自動プレイでスコア 350・ドット 66、決定性、
  面クリア、挙動プローブ全件（SPEC §4）

## Phase 3 ― 描画と入り口

- render.ts（状態層 + Canvas の事前画像化と
  盤面差分更新）、input.ts（キーボード + 合流点）、
  main.ts、index.html
- tsc ビルドが通ること。実画面は手元確認

## Phase 4 ― 音

- sound.ts（レジスタ層）と AudioWorklet
  プロセッサ（合成コア）
- 合成コアは Worklet と Node テストで共有し、
  無音・プレリュード・決定性を Node で確認する
- 実音は手元確認

## Phase 5 ― 納品

- README.md、REPORT.md、Makefile 相当
  （npm scripts）、zip 化と zip 単体での
  再ビルド・再検証
