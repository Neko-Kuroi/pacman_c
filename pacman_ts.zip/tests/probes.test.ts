// probes.test.ts -- targeted behavioural probes: speeds, phase timing,
// house dot counters, frightened duration, ghost-eaten scores and event
// timing, all against the C original's rules. Translation of the Nim
// port's tests/audit_probes.nim (17 probes).
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  state,
  newState,
  i2,
  add,
  ghostStartingPos,
  DISPLAY_TILES_X,
  DISPLAY_TILES_Y,
  DISPLAY_PIXELS_X,
  TILE_DOT,
  TILE_SPACE,
  DISABLED_TICKS,
  GameState,
  Dir,
  GhostState,
  GhostType,
  FreezeType,
  type Int2,
} from '../src/state.js';
import { start, before } from '../src/timing.js';
import {
  pixelToTilePos,
  dirToVec,
  isDot,
  isPill,
  isBlockingTile,
  isTunnel,
} from '../src/geom.js';
import { runTick } from '../src/rules.js';

function resetAll(): void {
  Object.assign(state, newState());
  start(state.intro.started);
}

function pressAnyKey(): void {
  state.input.anykey = true;
  runTick();
  state.input.anykey = false;
}

// BFS over non-blocking tiles to the nearest dot/pill; returns first step dir
function steerDir(): Dir {
  const startT = pixelToTilePos(state.game.pacman.actor.pos);
  const visited: boolean[][] = Array.from({ length: DISPLAY_TILES_Y }, () =>
    new Array<boolean>(DISPLAY_TILES_X).fill(false),
  );
  const firstStep: Dir[][] = Array.from({ length: DISPLAY_TILES_Y }, () =>
    new Array<Dir>(DISPLAY_TILES_X).fill(Dir.DIR_RIGHT),
  );
  const queue: Int2[] = [startT];
  let head = 0;
  visited[startT.y]![startT.x] = true;
  const dirs = [Dir.DIR_UP, Dir.DIR_LEFT, Dir.DIR_DOWN, Dir.DIR_RIGHT];
  while (head < queue.length) {
    const cur = queue[head++]!;
    if ((cur.x !== startT.x || cur.y !== startT.y) && (isDot(cur) || isPill(cur))) {
      return firstStep[cur.y]![cur.x]!;
    }
    for (const d of dirs) {
      const n = add(cur, dirToVec(d));
      if (
        n.x >= 0 && n.x < DISPLAY_TILES_X &&
        n.y >= 0 && n.y < DISPLAY_TILES_Y &&
        !visited[n.y]![n.x] &&
        !isBlockingTile(n)
      ) {
        visited[n.y]![n.x] = true;
        firstStep[n.y]![n.x] =
          cur.x === startT.x && cur.y === startT.y ? d : firstStep[cur.y]![cur.x]!;
        queue.push(n);
      }
    }
  }
  return state.game.pacman.actor.dir;
}

function setInput(d: Dir): void {
  state.input.up = d === Dir.DIR_UP;
  state.input.down = d === Dir.DIR_DOWN;
  state.input.left = d === Dir.DIR_LEFT;
  state.input.right = d === Dir.DIR_RIGHT;
}

function toGameplay(): void {
  resetAll();
  for (let i = 0; i < 100; i++) runTick();
  pressAnyKey();
  for (let i = 0; i < 2000; i++) {
    runTick();
    if (state.gamestate === GameState.GAMESTATE_GAME && state.game.freeze.size === 0) {
      return;
    }
  }
  assert.fail('never reached gameplay');
}

test('event timing: prelude 120, ready->round 130, scatter->chase +420', () => {
  toGameplay();
  const dtReady = state.game.readyStarted.tick - state.game.started.tick;
  const dtRound = state.game.roundStarted.tick - state.game.readyStarted.tick;
  assert.equal(dtReady, 120, 'started->readyStarted');
  assert.equal(dtRound, 130, 'readyStarted->roundStarted');

  // scatter -> chase switch at +420 ticks from round start
  const base = state.game.roundStarted.tick;
  while (state.timing.tick < base + 419) runTick();
  const s419 = state.game.ghost[GhostType.GHOSTTYPE_BLINKY]!.state;
  runTick();
  const s420 = state.game.ghost[GhostType.GHOSTTYPE_BLINKY]!.state;
  assert.equal(s419, GhostState.GHOSTSTATE_SCATTER, 'scatter@419');
  assert.equal(s420, GhostState.GHOSTSTATE_CHASE, 'chase@420');
});

test('pacman speed on a clear corridor: 7/8 px per tick', () => {
  // empty corridor (row 17, wraps through the tunnel)
  toGameplay();
  for (let x = 0; x < DISPLAY_TILES_X; x++) {
    if (state.gfx.videoRam[17]![x] === TILE_DOT) {
      state.gfx.videoRam[17]![x] = TILE_SPACE; // row 17 has dots at tiles 6 and 21
    }
  }
  state.game.pacman.actor.pos = i2(60, 17 * 8 + 4);
  state.game.pacman.actor.dir = Dir.DIR_LEFT;
  setInput(Dir.DIR_LEFT);
  let movedClear = 0;
  let prevX = state.game.pacman.actor.pos.x;
  for (let i = 0; i < 112; i++) {
    runTick();
    const x = state.game.pacman.actor.pos.x;
    let d = prevX - x;
    if (d < -100) d += DISPLAY_PIXELS_X; // wrapped
    movedClear += d;
    prevX = x;
  }
  assert.equal(movedClear, 98, '112 ticks * 7/8');
});

test('pacman speed while eating: about 0.80 px per tick', () => {
  // row 23 left segment, 11 dots
  toGameplay();
  state.game.pacman.actor.pos = i2(12 * 8 + 4, 23 * 8 + 4);
  state.game.pacman.actor.dir = Dir.DIR_LEFT;
  setInput(Dir.DIR_LEFT);
  let ticksEat = 0;
  while (state.game.pacman.actor.pos.x > 12 && ticksEat < 300) {
    runTick();
    ticksEat += 1;
  }
  const ratio = 88 / ticksEat;
  assert.ok(ratio > 0.77 && ratio < 0.83, `ticks for 88px=${ticksEat} ratio=${ratio}`);
});

test('ghost normal speed: 6/7 px per tick', () => {
  // Blinky, scatter/chase, outside tunnel
  toGameplay();
  let gTicks = 0;
  let gMoved = 0;
  let prevPos = i2(
    state.game.ghost[0]!.actor.pos.x,
    state.game.ghost[0]!.actor.pos.y,
  );
  for (let i = 0; i < 3000; i++) {
    runTick();
    const g = state.game.ghost[0]!;
    const d = Math.abs(g.actor.pos.x - prevPos.x) + Math.abs(g.actor.pos.y - prevPos.y);
    if (
      (g.state === GhostState.GHOSTSTATE_SCATTER || g.state === GhostState.GHOSTSTATE_CHASE) &&
      !isTunnel(pixelToTilePos(g.actor.pos)) &&
      state.game.freeze.size === 0
    ) {
      gTicks += 1;
      gMoved += d;
    }
    prevPos = i2(g.actor.pos.x, g.actor.pos.y);
  }
  const gRatio = gMoved / gTicks;
  assert.ok(gRatio > 0.83 && gRatio < 0.88, `ratio=${gRatio} over ${gTicks} ticks`);
});

test('house dot counters: Inky leaves at 30 dots, Clyde at 90 (+pills)', () => {
  toGameplay();
  let inkyAt = -1;
  let clydeAt = -1;
  let pills = 0;
  let lastPillTick = DISABLED_TICKS;
  const lives0 = state.game.numLives;
  while (state.game.numDotsEaten < 120 && state.game.numLives === lives0) {
    runTick();
    if (
      state.game.pillEaten.tick !== DISABLED_TICKS &&
      state.game.pillEaten.tick !== lastPillTick
    ) {
      lastPillTick = state.game.pillEaten.tick;
      pills += 1;
    }
    // pin the two roaming ghosts so Pacman survives long enough; this does
    // not touch the dot-counter mechanism under test
    state.game.ghost[0]!.actor.pos = i2(ghostStartingPos[0]!.x, ghostStartingPos[0]!.y);
    if (state.game.ghost[1]!.state !== GhostState.GHOSTSTATE_HOUSE) {
      state.game.ghost[1]!.actor.pos = i2(ghostStartingPos[1]!.x, ghostStartingPos[1]!.y);
    }
    if (state.game.freeze.size === 0) {
      setInput(steerDir());
    }
    if (inkyAt < 0 && state.game.ghost[GhostType.GHOSTTYPE_INKY]!.state !== GhostState.GHOSTSTATE_HOUSE) {
      inkyAt = state.game.numDotsEaten;
    }
    if (clydeAt < 0 && state.game.ghost[GhostType.GHOSTTYPE_CLYDE]!.state !== GhostState.GHOSTSTATE_HOUSE) {
      clydeAt = state.game.numDotsEaten;
    }
  }
  assert.equal(inkyAt, 30, 'inky leaves at 30 dots');
  if (clydeAt >= 0) {
    // pills raise numDotsEaten but do not advance the house counters
    // (the C pill branch never calls the counter update), so Clyde's
    // exit shifts by the number of pills eaten
    assert.equal(clydeAt, 90 + pills, `clydeAt=${clydeAt} pills=${pills}`);
  }
});

test('global dot counter after a death: Pinky 7, Inky 17, Clyde 32', () => {
  toGameplay();
  // stage a death: put Blinky (chase) onto Pacman's tile
  state.game.ghost[0]!.state = GhostState.GHOSTSTATE_CHASE;
  state.game.ghost[0]!.actor.pos = i2(
    state.game.pacman.actor.pos.x,
    state.game.pacman.actor.pos.y,
  );
  runTick();
  assert.notEqual(state.game.pacmanEaten.tick, DISABLED_TICKS, 'death sets pacmanEaten');
  // start() stores tick+1 while startAfter() stores tick+N, so the stored
  // trigger values differ by 209 even though the delay is 210 ticks (the C
  // code has the same arithmetic)
  const dtDeath = state.game.readyStarted.tick - state.game.pacmanEaten.tick;
  assert.equal(dtDeath, 209, 'death->ready timing');
  // wait for the new round to run, then eat dots and watch the global counter
  for (let i = 0; i < 2000; i++) {
    runTick();
    if (state.game.freeze.size === 0 && state.game.globalDotCounterActive) {
      break;
    }
  }
  let gPinky = -1;
  let gInky = -1;
  let gClyde = -1;
  let guard = 0;
  while (gClyde < 0 && guard < 30000) {
    runTick();
    guard += 1;
    if (state.game.freeze.size === 0) {
      setInput(steerDir());
    }
    if (gPinky < 0 && state.game.ghost[GhostType.GHOSTTYPE_PINKY]!.state !== GhostState.GHOSTSTATE_HOUSE) {
      gPinky = state.game.globalDotCounter;
    }
    if (gInky < 0 && state.game.ghost[GhostType.GHOSTTYPE_INKY]!.state !== GhostState.GHOSTSTATE_HOUSE) {
      gInky = state.game.globalDotCounter;
    }
    if (gClyde < 0 && state.game.ghost[GhostType.GHOSTTYPE_CLYDE]!.state !== GhostState.GHOSTSTATE_HOUSE) {
      gClyde = state.game.globalDotCounter;
    }
  }
  assert.equal(gPinky, 7, 'global pinky@7');
  assert.equal(gInky, 17, 'global inky@17');
  assert.equal(gClyde, 32, 'global clyde@32');
});

test('frightened duration: 360 ticks on round 1', () => {
  toGameplay();
  state.game.pacman.actor.pos = i2(1 * 8 + 4, 6 * 8 + 4); // on the pill tile
  setInput(Dir.DIR_LEFT);
  let frightStart = -1;
  for (let i = 0; i < 60; i++) {
    runTick();
    if (state.game.ghost[0]!.state === GhostState.GHOSTSTATE_FRIGHTENED) {
      frightStart = state.timing.tick;
      break;
    }
  }
  assert.ok(frightStart > 0, 'pill frightens blinky');
  // park Pacman far away in the bottom right corner area
  state.game.pacman.actor.pos = i2(26 * 8 + 4, 32 * 8 + 4);
  let leftAt = -1;
  for (let i = 0; i < 500; i++) {
    runTick();
    const st = state.game.ghost[0]!.state;
    if (st !== GhostState.GHOSTSTATE_FRIGHTENED) {
      leftAt = state.timing.tick - frightStart;
      break;
    }
  }
  assert.equal(leftAt, 360, 'frightened lasts 360');
});

test('ghost-eaten scores: 20, 40, 80, 160 (10-point units)', () => {
  toGameplay();
  state.game.pacman.actor.pos = i2(1 * 8 + 4, 6 * 8 + 4);
  setInput(Dir.DIR_LEFT);
  for (let i = 0; i < 60; i++) {
    runTick();
    if (
      state.game.ghost[0]!.frightened.tick !== DISABLED_TICKS &&
      before(state.game.ghost[0]!.frightened, 10)
    ) {
      break;
    }
  }
  const deltas: number[] = [];
  for (let gi = 0; gi < 4; gi++) {
    const g = state.game.ghost[gi]!;
    if (g.state === GhostState.GHOSTSTATE_EYES || g.state === GhostState.GHOSTSTATE_ENTERHOUSE) {
      continue;
    }
    g.state = GhostState.GHOSTSTATE_FRIGHTENED;
    start(g.frightened);
    g.actor.pos = i2(state.game.pacman.actor.pos.x, state.game.pacman.actor.pos.y);
    const s0 = state.game.score;
    for (let i = 0; i < 30; i++) {
      runTick();
      if (state.game.freeze.has(FreezeType.FREEZETYPE_EAT_GHOST)) {
        break;
      }
    }
    deltas.push(state.game.score - s0);
    // wait out the eat-ghost freeze
    for (let i = 0; i < 80; i++) {
      runTick();
      if (!state.game.freeze.has(FreezeType.FREEZETYPE_EAT_GHOST)) {
        break;
      }
    }
  }
  assert.deepEqual(deltas, [20, 40, 80, 160]);
});
