// input.test.ts -- touch swipe resolution (SPEC T8, following the
// Go port's H8 design). Only the DOM-free parts are tested here:
// the swipe direction function and the held/latch resolution.
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Dir } from '../src/state.js';
import { swipeDirection, resolveDirections, TOUCH_SWIPE_THRESHOLD } from '../src/input.js';

test('swipe threshold is 24 logical pixels', () => {
  assert.equal(TOUCH_SWIPE_THRESHOLD, 24);
  assert.equal(swipeDirection(23, 0), null);
  assert.equal(swipeDirection(0, 0), null);
  assert.equal(swipeDirection(24, 0), Dir.DIR_RIGHT);
});

test('swipe direction: larger axis wins, tie goes vertical', () => {
  assert.equal(swipeDirection(30, 10), Dir.DIR_RIGHT);
  assert.equal(swipeDirection(-30, 10), Dir.DIR_LEFT);
  assert.equal(swipeDirection(10, 30), Dir.DIR_DOWN);
  assert.equal(swipeDirection(10, -30), Dir.DIR_UP);
  assert.equal(swipeDirection(24, 24), Dir.DIR_DOWN);
  assert.equal(swipeDirection(-24, -24), Dir.DIR_UP);
});

test('resolution: held keyboard directions win over the latch', () => {
  const kb = { up: false, down: false, left: true, right: false };
  const r = resolveDirections(kb, Dir.DIR_UP);
  assert.deepEqual(r, { up: false, down: false, left: true, right: false });
});

test('resolution: latch applies only when nothing is held', () => {
  const none = { up: false, down: false, left: false, right: false };
  assert.deepEqual(resolveDirections(none, Dir.DIR_DOWN), {
    up: false,
    down: true,
    left: false,
    right: false,
  });
  assert.deepEqual(resolveDirections(none, null), none);
});
