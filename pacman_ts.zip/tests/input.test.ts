// input.test.ts -- touch swipe resolution (SPEC T8, following the
// Go port's H8 design). Only the DOM-free parts are tested here:
// the swipe direction function and the held/latch resolution.
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { state, Dir } from '../src/state.js';
import {
  swipeDirection,
  resolveDirections,
  TOUCH_SWIPE_THRESHOLD,
  attachInput,
} from '../src/input.js';
import { inputDisable, inputEnable, inputDir } from '../src/timing.js';

test('swipe threshold is 24 logical pixels', () => {
  assert.equal(TOUCH_SWIPE_THRESHOLD, 24);
  assert.equal(swipeDirection(23, 0), null);
  assert.equal(swipeDirection(0, 0), null);
  assert.equal(swipeDirection(24, 0), Dir.DIR_RIGHT);
});

test('swipe direction: larger axis wins, tie goes vertical', () => {
  assert.equal(swipeDirection(30, 10), Dir.DIR_RIGHT);
  assert.equal(swipeDirection(-30, 10), Dir.DIR_LEFT);
  assert.equal(swipeDirection(10, 30), Dir.DIR_DOWN);
  assert.equal(swipeDirection(10, -30), Dir.DIR_UP);
  assert.equal(swipeDirection(24, 24), Dir.DIR_DOWN);
  assert.equal(swipeDirection(-24, -24), Dir.DIR_UP);
});

test('resolution: held keyboard directions win over the latch', () => {
  const kb = { up: false, down: false, left: true, right: false };
  const r = resolveDirections(kb, Dir.DIR_UP);
  assert.deepEqual(r, { up: false, down: false, left: true, right: false });
});

test('resolution: latch applies only when nothing is held', () => {
  const none = { up: false, down: false, left: false, right: false };
  assert.deepEqual(resolveDirections(none, Dir.DIR_DOWN), {
    up: false,
    down: true,
    left: false,
    right: false,
  });
  assert.deepEqual(resolveDirections(none, null), none);
});

// Regression (external review): a key released while input is
// disabled must still be forgotten. Otherwise the held mirror in
// input.ts survives inputDisable()'s reset, and the released
// direction resurrects at the next key event -- start the game with
// Up, release it during the dark interval, and the game would steer
// Up forever. The other tests write state.input directly and never
// exercised this path, so this one drives the real listeners
// through a minimal DOM stub.
test('a key released while input is disabled does not stick', () => {
  const listeners = new Map<string, ((e: KeyboardEvent) => void)[]>();
  const g = globalThis as unknown as Record<string, unknown>;
  g.window = {
    addEventListener: (t: string, f: (e: KeyboardEvent) => void) => {
      const arr = listeners.get(t) ?? [];
      arr.push(f);
      listeners.set(t, arr);
    },
  };
  g.HTMLCanvasElement = class {};
  g.document = { getElementById: () => null, fullscreenElement: null };
  attachInput();
  const key = (type: string, code: string): void => {
    for (const f of listeners.get(type) ?? []) {
      f({ code, preventDefault: () => undefined } as KeyboardEvent);
    }
  };

  inputEnable();
  key('keydown', 'ArrowUp'); // start the game with Up
  assert.equal(state.input.up, true);
  inputDisable(); // the intro tick disables input (dark interval)
  key('keyup', 'ArrowUp'); // released while disabled
  inputEnable(); // the game enables input again
  key('keydown', 'ArrowLeft'); // the player now holds only Left
  assert.equal(inputDir(Dir.DIR_RIGHT), Dir.DIR_LEFT, 'must steer Left, not the stuck Up');
  key('keyup', 'ArrowLeft');
  assert.equal(state.input.up, false, 'Up must not be stuck');
});
