// audio.test.ts -- Phase 4 checks: the Synth sample generation,
// driven by the real register layer (sound.ts) in Node (SPEC T3).
// The global `state` is shared across the tests in this file; each
// test resets the audio state with sndClear() first and builds a
// fresh Synth, so they can run in file order.
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { state, NO_SOUND_FUNC } from '../src/state.js';
import {
  sndClear,
  sndStart,
  sndTick,
  sndPrelude,
  sndEatdot1,
  voiceSnapshot,
} from '../src/sound.js';
import { Synth } from '../src/synth.js';

const SAMPLE_RATE = 44100;
const SAMPLES_PER_TICK = 735; // 44100 / 60, one game tick of samples

test('silence: zeroed registers render all-zero samples', () => {
  sndClear();
  const synth = new Synth(SAMPLE_RATE);
  synth.setVoices(voiceSnapshot());
  const out = new Float32Array(SAMPLES_PER_TICK);
  synth.render(out);
  assert.ok(out.every((v) => v === 0));
});

test('prelude: audible, bounded, and the slot stops after the dump', () => {
  sndClear();
  const synth = new Synth(SAMPLE_RATE);
  sndStart(0, sndPrelude);
  let anyNonZero = false;
  let maxAbs = 0;
  for (let t = 0; t < 60; t++) {
    sndTick();
    synth.setVoices(voiceSnapshot());
    const out = new Float32Array(SAMPLES_PER_TICK);
    synth.render(out);
    for (const v of out) {
      if (v !== 0) anyNonZero = true;
      const a = Math.abs(v);
      if (a > maxAbs) maxAbs = a;
    }
  }
  assert.ok(anyNonZero, 'prelude rendered only silence');
  // Bound derived from the original math: one voice's averaged
  // sample is at most (8 * 15) / 128 (waveform value -8, volume 15),
  // the prelude uses 2 voices, and the output scales by
  // 0.333333 * AUDIO_VOLUME (0.5) -- so 0.3125 is the hard ceiling.
  // The actual prelude data peaks at about 0.302 (both voices near
  // full volume in the first tick), so a tighter bound would fail
  // a faithful implementation.
  assert.ok(maxAbs <= 0.3125, `max |sample| was ${maxAbs}`);

  // The dump is 245 ticks (490 values, stride 2). sndTick loads the
  // last entry on tick 245; one further tick sees curTick ===
  // numTicks and stops the slot, zeroing its voices.
  for (let t = 60; t <= 245; t++) {
    sndTick();
  }
  const snap = voiceSnapshot();
  assert.equal(snap[0]!.frequency, 0);
  assert.equal(snap[0]!.volume, 0);
  assert.equal(snap[1]!.frequency, 0);
  assert.equal(snap[1]!.volume, 0);
});

test('eatdot1: the sound stops itself after 6 ticks', () => {
  sndClear();
  sndStart(2, sndEatdot1);
  for (let t = 0; t < 6; t++) {
    sndTick();
  }
  const snd = state.audio.sound[2]!;
  assert.equal(snd.fn, NO_SOUND_FUNC);
  assert.equal(snd.flags.size, 0);
});

test('determinism: two identical prelude runs are byte-identical', () => {
  const run = (): Float32Array => {
    sndClear();
    const synth = new Synth(SAMPLE_RATE);
    sndStart(0, sndPrelude);
    const all = new Float32Array(60 * SAMPLES_PER_TICK);
    for (let t = 0; t < 60; t++) {
      sndTick();
      synth.setVoices(voiceSnapshot());
      const chunk = new Float32Array(SAMPLES_PER_TICK);
      synth.render(chunk);
      all.set(chunk, t * SAMPLES_PER_TICK);
    }
    return all;
  };
  const a = run();
  const b = run();
  const aBytes = Buffer.from(a.buffer, a.byteOffset, a.byteLength);
  const bBytes = Buffer.from(b.buffer, b.byteOffset, b.byteLength);
  assert.ok(aBytes.equals(bBytes));
});
