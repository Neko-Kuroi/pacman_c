// race.test.ts -- the last-life win/death race: on the final life,
// Pacman eats the last dot on the same tick a ghost catches him.
// The original's structure then runs both sequences at once: the win
// freeze starts the next tick, GAME OVER fires at +210, yet the new
// round still begins (win branch) at +241 during the GAME OVER
// display, and the intro returns at +420. Measured on the Nim port
// as well; the values are identical. This test pins the behavior so
// it cannot silently change.
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  state,
  newState,
  i2,
  DISPLAY_TILES_X,
  DISPLAY_TILES_Y,
  TILE_DOT,
  TILE_PILL,
  TILE_SPACE,
  GameState,
  Dir,
  GhostState,
  FreezeType,
} from '../src/state.js';
import { start, now } from '../src/timing.js';
import { runTick } from '../src/rules.js';

function resetAll(): void {
  Object.assign(state, newState());
  start(state.intro.started); // what init() does
}

// read through a call so TypeScript does not narrow the scene to a
// single enum member across runTick() calls
function scene(): GameState {
  return state.gamestate;
}

test('last life: last dot and death on the same tick', () => {
  resetAll();
  for (let i = 0; i < 100; i++) runTick();
  state.input.anykey = true;
  runTick();
  state.input.anykey = false;
  // advance until the round is running
  for (let i = 0; i < 1000; i++) {
    runTick();
    if (
      state.gamestate === GameState.GAMESTATE_GAME &&
      !state.game.freeze.has(FreezeType.FREEZETYPE_READY) &&
      !state.game.freeze.has(FreezeType.FREEZETYPE_PRELUDE)
    ) {
      break;
    }
  }
  assert.ok(state.gamestate === GameState.GAMESTATE_GAME, 'round never started');

  // one dot left at (1,4), 243 eaten, no lives left
  for (let y = 0; y < DISPLAY_TILES_Y; y++) {
    for (let x = 0; x < DISPLAY_TILES_X; x++) {
      const c = state.gfx.videoRam[y]![x]!;
      if (c === TILE_DOT || c === TILE_PILL) {
        state.gfx.videoRam[y]![x] = TILE_SPACE;
      }
    }
  }
  state.gfx.videoRam[4]![1] = TILE_DOT;
  state.game.numDotsEaten = 243;
  state.game.numLives = 0;
  // Pacman just right of the dot, heading left; Blinky is pinned
  // onto the dot tile until the eating tick, so the collision lands
  // on the same tick
  state.game.pacman.actor.pos = i2(2 * 8 + 4, 4 * 8 + 4);
  state.game.pacman.actor.dir = Dir.DIR_LEFT;
  state.input.left = true;

  const seen: Record<string, number> = {};
  for (let i = 0; i < 700; i++) {
    if (seen.eat === undefined) {
      const b = state.game.ghost[0]!;
      b.actor.pos = i2(1 * 8 + 4, 4 * 8 + 4);
      b.state = GhostState.GHOSTSTATE_SCATTER;
    }
    runTick();
    const t = state.timing.tick;
    if (seen.eat === undefined && state.game.numDotsEaten === 244) seen.eat = t;
    if (seen.eat !== undefined) {
      if (seen.won === undefined && state.game.freeze.has(FreezeType.FREEZETYPE_WON)) seen.won = t;
      if (seen.over === undefined && now(state.game.gameOver)) seen.over = t;
      if (seen.round === undefined && state.game.round === 1) seen.round = t;
      if (seen.intro === undefined && scene() === GameState.GAMESTATE_INTRO) {
        seen.intro = t;
        break;
      }
    }
  }

  assert.notEqual(seen.eat, undefined, 'the last dot was never eaten');
  assert.equal(seen.won! - seen.eat!, 1, 'win freeze starts the next tick');
  assert.equal(seen.over! - seen.eat!, 210, 'GAME OVER fires at +210');
  assert.equal(seen.round! - seen.eat!, 241, 'the new round begins at +241, during GAME OVER');
  assert.equal(seen.intro! - seen.eat!, 420, 'back to the intro at +420');
  assert.equal(state.game.numLives, 0, 'lives must not go negative');
});
