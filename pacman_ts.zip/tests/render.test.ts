// render.test.ts -- the fade values (gfxFade). The original computes
// in float32, and the port reproduces that rounding with Math.fround;
// these tables are the float32 results for every step, checked
// against the C computation. In float64, six fadein steps would be
// one unit brighter (e.g. step 10: 170 instead of 169).
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { state, newState, DISABLED_TICKS } from '../src/state.js';
import { gfxFade } from '../src/render.js';

const FADEIN: number[] = [
  255, 246, 238, 229, 221, 212, 204, 195, 187, 178, 169, 161, 153, 144, 135,
  127, 118, 110, 101, 93, 84, 76, 67, 59, 50, 42, 33, 25, 16, 8, 0,
];
const FADEOUT: number[] = [
  0, 8, 17, 25, 34, 42, 51, 59, 68, 76, 85, 93, 102, 110, 119, 127, 136, 144,
  153, 161, 170, 178, 187, 195, 204, 212, 221, 229, 238, 246, 255,
];

function fadeAt(which: 'fadein' | 'fadeout', sinceTicks: number): number {
  Object.assign(state, newState());
  state.timing.tick = 1000;
  state.gfx.fadein.tick = DISABLED_TICKS;
  state.gfx.fadeout.tick = DISABLED_TICKS;
  state.gfx[which].tick = 1000 - sinceTicks;
  gfxFade();
  return state.gfx.fade;
}

test('fadein values match the float32 computation at every step', () => {
  for (let s = 0; s <= 30; s++) {
    assert.equal(fadeAt('fadein', s), FADEIN[s], `fadein at ${s} ticks`);
  }
});

test('fadeout values match the float32 computation at every step', () => {
  for (let s = 0; s <= 30; s++) {
    assert.equal(fadeAt('fadeout', s), FADEOUT[s], `fadeout at ${s} ticks`);
  }
});
