// headless.test.ts -- drives the game logic tick by tick without graphics
// or audio output. Translation of the Nim port's tests/headless.nim
// (the tick driver is rules.runTick, the frame loop's tick part).
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  state,
  newState,
  i2,
  add,
  DISPLAY_TILES_X,
  DISPLAY_TILES_Y,
  TILE_DOT,
  TILE_PILL,
  TILE_SPACE,
  GameState,
  Dir,
  GhostState,
  GhostType,
  FreezeType,
  type Int2,
} from '../src/state.js';
import { start } from '../src/timing.js';
import { pixelToTilePos, dirToVec, isDot, isPill, isBlockingTile } from '../src/geom.js';
import { runTick } from '../src/rules.js';

function resetAll(): void {
  Object.assign(state, newState());
  start(state.intro.started); // what init() does
}

function pressAnyKey(): void {
  state.input.anykey = true;
  runTick();
  state.input.anykey = false;
}

function countDots(): number {
  let n = 0;
  for (let y = 0; y < DISPLAY_TILES_Y; y++) {
    for (let x = 0; x < DISPLAY_TILES_X; x++) {
      const c = state.gfx.videoRam[y]![x]!;
      if (c === TILE_DOT || c === TILE_PILL) n += 1;
    }
  }
  return n;
}

// BFS over non-blocking tiles to the nearest dot/pill; returns first step dir
function steerDir(): Dir {
  const startT = pixelToTilePos(state.game.pacman.actor.pos);
  const visited: boolean[][] = Array.from({ length: DISPLAY_TILES_Y }, () =>
    new Array<boolean>(DISPLAY_TILES_X).fill(false),
  );
  const firstStep: Dir[][] = Array.from({ length: DISPLAY_TILES_Y }, () =>
    new Array<Dir>(DISPLAY_TILES_X).fill(Dir.DIR_RIGHT),
  );
  const queue: Int2[] = [startT];
  let head = 0;
  visited[startT.y]![startT.x] = true;
  const dirs = [Dir.DIR_UP, Dir.DIR_LEFT, Dir.DIR_DOWN, Dir.DIR_RIGHT];
  while (head < queue.length) {
    const cur = queue[head++]!;
    if ((cur.x !== startT.x || cur.y !== startT.y) && (isDot(cur) || isPill(cur))) {
      return firstStep[cur.y]![cur.x]!;
    }
    for (const d of dirs) {
      const n = add(cur, dirToVec(d));
      if (
        n.x >= 0 && n.x < DISPLAY_TILES_X &&
        n.y >= 0 && n.y < DISPLAY_TILES_Y &&
        !visited[n.y]![n.x] &&
        !isBlockingTile(n)
      ) {
        visited[n.y]![n.x] = true;
        firstStep[n.y]![n.x] =
          cur.x === startT.x && cur.y === startT.y ? d : firstStep[cur.y]![cur.x]!;
        queue.push(n);
      }
    }
  }
  return state.game.pacman.actor.dir;
}

function setInput(d: Dir): void {
  state.input.up = d === Dir.DIR_UP;
  state.input.down = d === Dir.DIR_DOWN;
  state.input.left = d === Dir.DIR_LEFT;
  state.input.right = d === Dir.DIR_RIGHT;
}

test('headless play: boot, start a game, play autonomously for 60000 ticks', () => {
  resetAll();
  for (let i = 0; i < 100; i++) runTick();
  const bootState: GameState = state.gamestate;
  assert.equal(bootState, GameState.GAMESTATE_INTRO);
  pressAnyKey();
  let sawGame = false;
  let inkyLeftHouse = false;
  let maxGhostsOut = 0;
  for (let i = 0; i < 60000; i++) {
    runTick();
    if (state.gamestate === GameState.GAMESTATE_GAME) {
      if (!sawGame) {
        sawGame = true;
        assert.equal(countDots(), 244, 'playfield must start with 244 dots/pills');
      }
      if (state.game.freeze.size === 0) {
        setInput(steerDir());
      }
      let outCount = 0;
      for (const g of state.game.ghost) {
        if (g.state !== GhostState.GHOSTSTATE_HOUSE) outCount += 1;
      }
      maxGhostsOut = Math.max(maxGhostsOut, outCount);
      if (state.game.ghost[GhostType.GHOSTTYPE_INKY]!.state !== GhostState.GHOSTSTATE_HOUSE) {
        inkyLeftHouse = true;
      }
    }
  }
  assert.ok(sawGame, 'never entered the game scene');
  // the same end state as the Nim and Go ports' identical scenario
  assert.equal(state.game.score, 350);
  assert.equal(state.game.numDotsEaten, 66);
  assert.equal(maxGhostsOut, 4, 'all 4 ghosts must leave the house');
  assert.ok(inkyLeftHouse);
  // all lives lost: death -> game over -> back to the intro
  assert.equal(state.game.numLives, 0);
  assert.equal(state.gamestate, GameState.GAMESTATE_INTRO);
});

test('determinism: same seed and inputs, same outcome', () => {
  const runShort = (): number[] => {
    resetAll();
    for (let i = 0; i < 100; i++) runTick();
    pressAnyKey();
    for (let i = 0; i < 20000; i++) {
      runTick();
      if (state.gamestate === GameState.GAMESTATE_GAME && state.game.freeze.size === 0) {
        setInput(steerDir());
      }
    }
    return [
      state.game.score,
      state.game.numDotsEaten,
      state.game.pacman.actor.pos.x,
      state.game.pacman.actor.pos.y,
      state.game.ghost[0]!.actor.pos.x,
      state.game.ghost[0]!.actor.pos.y,
    ];
  };
  const r1 = runShort();
  const r2 = runShort();
  assert.deepEqual(r1, r2);
});

test('win scenario: eating the last dot wins the round', () => {
  resetAll();
  for (let i = 0; i < 100; i++) runTick();
  pressAnyKey();
  // advance until the round is running
  for (let i = 0; i < 1000; i++) {
    runTick();
    if (
      state.gamestate === GameState.GAMESTATE_GAME &&
      !state.game.freeze.has(FreezeType.FREEZETYPE_READY) &&
      !state.game.freeze.has(FreezeType.FREEZETYPE_PRELUDE)
    ) {
      break;
    }
  }
  // remove all dots except the one at (1,4) and pretend 243 were eaten
  for (let y = 0; y < DISPLAY_TILES_Y; y++) {
    for (let x = 0; x < DISPLAY_TILES_X; x++) {
      const c = state.gfx.videoRam[y]![x]!;
      if (c === TILE_DOT || c === TILE_PILL) {
        state.gfx.videoRam[y]![x] = TILE_SPACE;
      }
    }
  }
  state.gfx.videoRam[4]![1] = TILE_DOT;
  state.game.numDotsEaten = 243;
  // place Pacman just right of the dot, heading left
  state.game.pacman.actor.pos = i2(2 * 8 + 4, 4 * 8 + 4);
  state.game.pacman.actor.dir = Dir.DIR_LEFT;
  setInput(Dir.DIR_LEFT);
  let won = false;
  for (let i = 0; i < 2000; i++) {
    runTick();
    if (state.game.freeze.has(FreezeType.FREEZETYPE_WON)) {
      won = true;
    }
    if (won && state.game.round === 1 && countDots() === 244) {
      break;
    }
  }
  assert.ok(won, 'round was not won');
  assert.equal(state.game.round, 1);
  assert.equal(countDots(), 244);
  assert.equal(state.game.globalDotCounterActive, false);
});
