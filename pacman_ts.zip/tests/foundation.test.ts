// foundation.test.ts -- Phase 1 checks: ROM data, xorshift, levelspec,
// trigger vocabulary (SPEC section 4).
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { state, levelspec, MAX_LEVELSPEC, Fruit } from '../src/state.js';
import { xorshift32, start, startAfter, disable, since, between } from '../src/timing.js';
import {
  romTiles,
  romSprites,
  romHWColors,
  romPalette,
  romWavetable,
  sndDumpPrelude,
  sndDumpDead,
} from '../src/romdata.js';

function sum(a: Uint8Array | Uint32Array): number {
  let s = 0;
  for (const v of a) s += v;
  return s;
}

test('romdata counts and sums match pacman.c', () => {
  assert.equal(romTiles.length, 4096);
  assert.equal(sum(romTiles), 267889);
  assert.equal(romSprites.length, 4096);
  assert.equal(sum(romSprites), 227290);
  assert.equal(romHWColors.length, 32);
  assert.equal(sum(romHWColors), 1852);
  assert.equal(romPalette.length, 256);
  assert.equal(sum(romPalette), 589);
  assert.equal(romWavetable.length, 256);
  assert.equal(sum(romWavetable), 1856);
  assert.equal(sndDumpPrelude.length, 490);
  assert.equal(sum(sndDumpPrelude), 1523003578600);
  assert.equal(sndDumpDead.length, 90);
  assert.equal(sum(sndDumpDead), 275197360640);
});

test('xorshift32 sequence matches C semantics', () => {
  state.game.xorshift = 0x12345678;
  const got = [xorshift32(), xorshift32(), xorshift32(), xorshift32(), xorshift32()];
  assert.deepEqual(got, [2274908837, 358294691, 1210119364, 2176035992, 1882851208]);
});

test('levelspec clamps to the last entry', () => {
  assert.equal(levelspec(0).bonusFruit, Fruit.FRUIT_CHERRIES);
  assert.equal(levelspec(0).frightTicks, 360);
  assert.equal(levelspec(999), levelspec(MAX_LEVELSPEC - 1));
});

test('trigger vocabulary', () => {
  state.timing.tick = 100;
  const t = { tick: 0 };
  start(t);
  assert.equal(t.tick, 101);
  startAfter(t, 10);
  assert.equal(t.tick, 110);
  state.timing.tick = 115;
  assert.equal(since(t), 5);
  assert.equal(between(t, 0, 10), true);
  assert.equal(between(t, 6, 10), false);
  disable(t);
  assert.equal(since(t), 0xffffffff);
  assert.equal(between(t, 0, 10), false);
});
